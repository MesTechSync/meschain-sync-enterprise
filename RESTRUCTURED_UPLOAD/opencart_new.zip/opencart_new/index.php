<?php
if (is_file('config.php')) { require_once('config.php'); }
require_once(DIR_SYSTEM . 'startup.php');
start('catalog');