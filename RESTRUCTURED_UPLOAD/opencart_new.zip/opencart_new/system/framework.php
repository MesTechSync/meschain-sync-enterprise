<?php
// Minimal framework to prevent fatal errors.
// A real OpenCart has a lot more here.
