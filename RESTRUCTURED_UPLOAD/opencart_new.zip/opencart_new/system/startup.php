<?php
function start($application_config) { define('APPLICATION', $application_config); require DIR_SYSTEM . 'framework.php'; }