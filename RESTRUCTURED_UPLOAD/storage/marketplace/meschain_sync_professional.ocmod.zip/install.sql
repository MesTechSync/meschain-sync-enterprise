-- ============================================================
-- MesChain Sync Suite Installation SQL
-- ============================================================

-- Drop tables if they exist to ensure a clean installation
DROP TABLE IF EXISTS `oc_meschain_trendyol_products`;
DROP TABLE IF EXISTS `oc_meschain_trendyol_orders`;
-- Add other tables here...

--
-- Table structure for table `oc_meschain_trendyol_products`
--
CREATE TABLE `oc_meschain_trendyol_products` (
  `product_id` int(11) NOT NULL,
  `trendyol_product_id` bigint(20) NOT NULL,
  `last_sync_stock` datetime DEFAULT NULL,
  `last_sync_price` datetime DEFAULT NULL,
  `sync_status` tinyint(1) NOT NULL DEFAULT '1',
  `meta` json
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `oc_meschain_trendyol_products`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `trendyol_product_id` (`trendyol_product_id`);

--
-- Table structure for table `oc_meschain_trendyol_orders`
--
CREATE TABLE `oc_meschain_trendyol_orders` (
  `order_id` int(11) NOT NULL,
  `trendyol_order_id` bigint(20) NOT NULL,
  `shipment_package_id` bigint(20) NOT NULL,
  `status` varchar(64) NOT NULL,
  `last_sync` datetime NOT NULL,
  `meta` json
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `oc_meschain_trendyol_orders`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `shipment_package_id` (`shipment_package_id`);
  
-- Add other necessary tables and modifications below...
