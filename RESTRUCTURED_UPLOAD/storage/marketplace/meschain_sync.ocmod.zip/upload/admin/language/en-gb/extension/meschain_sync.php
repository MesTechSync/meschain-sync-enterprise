<?php
// Heading
$_['heading_title'] = 'MesChain SYNC';

// Text
$_['text_meschain_sync'] = 'MesChain SYNC';
$_['text_extension'] = 'Extensions'; 