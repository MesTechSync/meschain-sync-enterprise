<?php
// Heading
$_["heading_title"] = "MesChain Trendyol Entegrasyonu";

// Text
$_["text_extension"] = "Eklentiler";
$_["text_success"] = "Başarılı: MesChain Trendyol modülü güncellendi!";
$_["text_edit"] = "MesChain Trendyol Modülünü Düzenle";
$_["text_enabled"] = "Etkin";
$_["text_disabled"] = "Pasif";

// Entry
$_["entry_status"] = "Durum";

// Error
$_["error_permission"] = "Uyarı: MesChain Trendyol modülünü değiştirme yetkiniz yok!";
?>