<?php
// Heading
$_["heading_title"] = "MesChain Trendyol Integration";

// Text
$_["text_extension"] = "Extensions";
$_["text_success"] = "Success: You have modified MesChain Trendyol module!";
$_["text_edit"] = "Edit MesChain Trendyol Module";
$_["text_enabled"] = "Enabled";
$_["text_disabled"] = "Disabled";

// Entry
$_["entry_status"] = "Status";

// Error
$_["error_permission"] = "Warning: You do not have permission to modify MesChain Trendyol module!";
?>