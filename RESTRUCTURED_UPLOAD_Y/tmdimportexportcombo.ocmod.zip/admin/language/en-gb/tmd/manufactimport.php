<?php
// Heading
$_['heading_title']          = 'TMD Manufacturer Export/Import';
$_['heading_title1']         = '<span style="color:#1E91DF;font-weight:bold;">TMD Manufacturer Export/Import</span>';


// Text
$_['text_success']           = 'Success: You have modified categories!';
$_['text_default']           = 'Default';
$_['text_browse']            = 'Browse';
$_['text_clear']             = 'Clear';
$_['text_manufacturer']      = 'Manufacturer Export/Import ';
$_['text_end']       		 = 'End ';
$_['text_start']      		 = 'Start ';

//help
$_['help_storeurl']         = 'Please put url where new version opencart present';


// Entry
$_['entry_type']           = 'Format:';
$_['entry_imageurl']        = 'Image url: <span data-toggle="tooltip" data-original-title="selet yes if you want image automaic upload "> </span>';
$_['entry_status']           = 'Status:';
$_['entry_store']            = 'Store:';
$_['entry_limit']            = 'Limit:';
$_['entry_importby']         = 'Import By';
$_['entry_language']         = 'Language';
$_['entry_productid']        = 'Product ID';
$_['entry_model']        	 = 'Model';
$_['entry_import_stores']    = 'For other information like category,manufature,etc';
$_['entry_import']    		 = 'Import xls File <span data-toggle="tooltip" data-original-title="Please Import Same format if you have not format please download"> </span><br/><a style="font-size:12px ;line-height:20px;" href="'.HTTP_CATALOG.'extension/tmdimportexportcombo/image/catalog/xls/Manufacture.xls" download>Example From here</a>';

//tabs
$_['tab_manufacturer']       = 'Manufacturers';
$_['tab_export']      		 = 'Export';
$_['tab_import']       		 = 'Import';
$_['tab_product']       	 = 'Product';
$_['tab_category']       	 = 'Category';
//button
$_['button_export']       	 = 'Export';
$_['button_import']    = 'Import file  ';
$_['success_import']    = 'Import was successfully completed! Total Manufacturer  updated %s, new Manufacturer  inserted %s .';

// Error 
$_['error_import1'] = 'Warning: You do not have permission to modify Manufacturer !';
$_['error_wrongformat']     = 'Warning: Please check file format !';
$_['error_import']      = 'Warning: The file you uploaded was empty!';
?>