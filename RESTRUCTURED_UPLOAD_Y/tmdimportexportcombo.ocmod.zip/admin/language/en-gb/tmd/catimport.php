<?php
// Heading
$_['heading_title']     = 'TMD Category Import/Export';
$_['heading_title1']     = '<span style="color:#1E91DF;font-weight:bold;"> TMD Category Import/Export</span>';

// Text
$_['text_success']     = 'Success: You have modified TMD Category Import/Export!';
$_['text_upload']      = 'Your file was successfully uploaded!';

$_['success_category_import']      = 'Import was successfully completed! Total categories updated %s, new categories inserted %s .';

// Column
$_['column_name']      = 'Download Name';
$_['column_remaining'] = 'Total Downloads Allowed';
$_['column_action']    = 'Action';

// Entry
$_['entry_export']       = 'Export';
$_['entry_import']    = 'Import xls File Please Import Same format if you have not format please download <a style="margin-top:10px;" class="btn btn-primary col-sm-12" href="'.HTTP_CATALOG.'extension/tmdimportexportcombo/image/catalog/xls/csv_category_import.xls">Download Example File From here</a>';

$_['tab_import']       = 'Import';
$_['tab_export']       = 'Export';
$_['button_import']       = 'Import';
$_['button_import']       = 'Import';
$_['button_export']       = 'Export';
$_['entry_store']       = 'Store';
$_['entry_category']       = 'Category';
$_['entry_limit']       = 'Limit';
$_['entry_status']       = 'Status';
$_['entry_language']       = 'Language';
$_['entry_imports']       = 'Import';
$_['import_language']       = 'Language';
$_['text_all_status']       = 'All Status';
$_['entry_format']       = 'Please select format';
$_['entry_product_url']       = 'Image url <span class="help">if you want full url please select yes</span>';
$_['import_store']       = 'Store';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify TMD Category Import/Export!';
$_['error_name']       = 'Name must be between 3 and 64 characters!';
$_['error_empty']      = ' Warning: The file you uploaded was empty!';
$_['error_upload']     = 'Upload required!';
$_['error_filename']   = 'Filename must be between 3 and 128 characters!';
$_['error_exists']     = 'File does not exist!';
$_['error_mask']       = 'Mask must be between 3 and 128 characters!';
$_['error_filetype']   = 'Invalid file type!';
$_['error_category_import']    = 'Warning: File Empty';
$_['error_product']    = 'Warning: This download cannot be deleted as it is currently assigned to %s products!';
?>