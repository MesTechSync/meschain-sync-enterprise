<?php
// Heading
$_['heading_title']    = 'TMD Import Product';
$_['heading_title1']         = '<span style="color:#1E91DF;font-weight:bold;">TMD Import Product</span>';

$_['button_import']    = 'Import file  ';
$_['entry_import']    = 'Import xls File <span class="help">Please Import Same format if you have not format please download <a href="'.HTTP_CATALOG.'extension/tmdimportexportcombo/image/catalog/xls/csv template.xls">From here</a> </span>';
$_['entry_stores']  = 'Stores <span class="help"> For other information like category,manufature,etc</span>';
$_['entry_importby']  = 'Import By';
$_['entry_productid']  = 'Product ID';
$_['entry_model']  = 'Model';
$_['entry_language']  = 'Language';
$_['text_all_stores']  = 'Default';
$_['text_import_by']  = 'Default';
$_['entry_type']    = 'Select Format:';
$_['entry_extrafiled']    = 'Custom Extra  Filed (please make extra filed in your product table):';
// Text

$_['text_success']     = 'Success: You have successfully imported your database!';

// Entry
$_['entry_backup']     = 'Backup:';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify backups!';
$_['error_wrongformat']     = 'Warning: Please check file format !';
$_['error_empty']      = 'Warning: The file you uploaded was empty!';
?>