<?php
// Heading
$_['heading_title1']    = 'TMD Import Export Combo';
$_['heading_title']    = '<span style="color:#23A8DA;font-weight:bold;">TMD Import Export Combo</span>';
// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Import export Combo!';
$_['text_edit']        = 'Edit Import export Combo';
$_['text_importexportcombo']        = 'TMD IMPORT EXPORT COMBO';
$_['text_import']           = 'Import Product';
$_['text_export1']   		= 'Export Product';
$_['text_catimport'] 		= 'Import/Export Category';
$_['text_manufact_import']  = 'Import/Export Manufacturer';

// Entry
$_['entry_admin']      = 'Admin Users Only';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Import export Combo!';