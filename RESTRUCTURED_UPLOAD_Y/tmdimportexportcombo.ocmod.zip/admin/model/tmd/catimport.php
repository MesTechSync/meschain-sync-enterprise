<?php
namespace Opencart\Admin\Model\Extension\Tmdimportexportcombo\Tmd;
class catimport extends \Opencart\System\Engine\Model {	

	public function addCategory($data) {
		$this->db->query("INSERT INTO " . DB_PREFIX . "category SET parent_id = '" . (int)$data['parent_id'] . "', `top` = '" . (isset($data['top']) ? (int)$data['top'] : 0) . "', `column` = '" . (int)$data['column'] . "', sort_order = '" . (int)$data['sort_order'] . "', status = '" . (int)$data['status'] . "', date_modified = NOW(), date_added = NOW()");

		$category_id = $this->db->getLastId();

		if (isset($data['image'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "category SET image = '" . $this->db->escape(html_entity_decode($data['image'], ENT_QUOTES, 'UTF-8')) . "' WHERE category_id = '" . (int)$category_id . "'");
		}
				
		
		foreach ($data['category_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "category_description SET category_id = '" . (int)$category_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape((string)$value['name']) . "', meta_keyword = '" . $this->db->escape((string)$value['meta_keyword']) . "',meta_title='".$this->db->escape((string)$value['meta_title'])."', meta_description = '" . $this->db->escape((string)$value['meta_description']) . "', description = '" . $this->db->escape((string)$value['description']) . "'");
		}

		// MySQL Hierarchical Data Closure Table Pattern
		$level = 0;

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$data['parent_id'] . "' ORDER BY `level` ASC");

		foreach ($query->rows as $result) {
			$this->db->query("INSERT INTO `" . DB_PREFIX . "category_path` SET `category_id` = '" . (int)$category_id . "', `path_id` = '" . (int)$result['path_id'] . "', `level` = '" . (int)$level . "'");

			$level++;
		}

		$this->db->query("INSERT INTO `" . DB_PREFIX . "category_path` SET `category_id` = '" . (int)$category_id . "', `path_id` = '" . (int)$category_id . "', `level` = '" . (int)$level . "'");

		if (isset($data['category_filter'])) {
			foreach ($data['category_filter'] as $filter_id) {
				$this->db->query("DELETE FROM " . DB_PREFIX . "category_filter WHERE category_id = '" . (int)$category_id . "'");
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_filter SET category_id = '" . (int)$category_id . "', filter_id = '" . (int)$filter_id . "'");
			}
		}

		if (isset($data['category_store'])) {
			foreach ($data['category_store'] as $store_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_to_store SET category_id = '" . (int)$category_id . "', store_id = '" . (int)$store_id . "'");
			}
		}

		// Set which layout to use with this category
		if (isset($data['category_layout'])) {
			foreach ($data['category_layout'] as $store_id => $layout) {
				if ($layout['layout_id']) {
					$this->db->query("INSERT INTO " . DB_PREFIX . "category_to_layout SET category_id = '" . (int)$category_id . "', store_id = '" . (int)$store_id . "', layout_id = '" . (int)$layout['layout_id'] . "'");
				}
			}
		}		

		// Seo urls on categories need to be done differently to they include the full keyword path
		$parent_path = $this->getPath($data['parent_id']);

		if (!$parent_path) {
			$path = $category_id;
		} else {
			$path = $parent_path . '_' . $category_id;
		}

		$this->load->model('design/seo_url');

		foreach ($data['category_seo_url'] as $store_id => $language) {
			foreach ($language as $language_id => $keyword) {
				$seo_url_info = $this->model_design_seo_url->getSeoUrlByKeyValue('path', $parent_path, $store_id, $language_id);

				if ($seo_url_info) {
					$keyword = $seo_url_info['keyword'] . '/' . $keyword;
				}

				$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `store_id` = '" . (int)$store_id . "', `language_id` = '" . (int)$language_id . "', `key` = 'path', `value`= '" . $this->db->escape($path) . "', `keyword` = '" . $keyword . "'");
			}
		}

		$this->cache->delete('category');
		return $category_id;
	}

	public function getPath(int $category_id): string {
		return implode('_', array_column($this->getPaths($category_id), 'path_id'));
	}

	public function getPaths(int $category_id): array {
		$query = $this->db->query("SELECT `category_id`, `path_id`, `level` FROM `" . DB_PREFIX . "category_path` WHERE `category_id` = '" . (int)$category_id . "' ORDER BY `level` ASC");

		return $query->rows;
	}

	public function getSeoUrls(int $category_id): array {
		$category_seo_url_data = [];

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "seo_url` WHERE `key` = 'path' AND `value` = '" . $this->db->escape($this->getPath($category_id)) . "'");

		foreach ($query->rows as $result) {
			$category_seo_url_data[$result['store_id']][$result['language_id']] = $result['keyword'];
		}

		return $category_seo_url_data;
	}

	public function editCategory($category_id, $data,$language_id) {
		$query = $this->db->query("SELECT category_id FROM " . DB_PREFIX . "category where category_id='".$category_id."'");

		if(isset($query->row['category_id'])){
		$this->db->query("UPDATE " . DB_PREFIX . "category SET parent_id = '" . (int)$data['parent_id'] . "', `top` = '" . (isset($data['top']) ? (int)$data['top'] : 0) . "', `column` = '" . (int)$data['column'] . "', sort_order = '" . (int)$data['sort_order'] . "', status = '" . (int)$data['status'] . "', date_modified = NOW() WHERE category_id = '" . (int)$category_id . "'");
		}
		else
		{
			
		$this->db->query("insert " . DB_PREFIX . "category SET  parent_id = '" . (int)$data['parent_id'] . "', `top` = '" . (isset($data['top']) ? (int)$data['top'] : 0) . "', `column` = '" . (int)$data['column'] . "', sort_order = '" . (int)$data['sort_order'] . "', status = '" . (int)$data['status'] . "', date_modified = NOW() , category_id = '" . (int)$category_id . "'");

		}
		if (isset($data['image'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "category SET image = '" . $this->db->escape(html_entity_decode($data['image'], ENT_QUOTES, 'UTF-8')) . "' WHERE category_id = '" . (int)$category_id . "'");
		}

		$this->db->query("DELETE FROM " . DB_PREFIX . "category_description WHERE category_id = '" . (int)$category_id . "' and language_id='".$language_id."'");

		foreach ($data['category_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "category_description SET category_id = '" . (int)$category_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape((string)$value['name']) . "', meta_keyword = '" . $this->db->escape((string)$value['meta_keyword']) . "',meta_title='".$this->db->escape((string)$value['meta_title'])."', meta_description = '" . $this->db->escape((string)$value['meta_description']) . "', description = '" . $this->db->escape((string)$value['description']) . "'");
		}

		// Old path
		$path_old = $this->getPath((int)$category_id);

		// MySQL Hierarchical Data Closure Table Pattern
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "category_path` WHERE path_id = '" . (int)$category_id . "' ORDER BY level ASC");

		if ($query->rows) {
			foreach ($query->rows as $category_path) {
				// Delete the path below the current one
				$this->db->query("DELETE FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$category_path['category_id'] . "' AND level < '" . (int)$category_path['level'] . "'");

				$path = array();

				// Get the nodes new parents
				$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$data['parent_id'] . "' ORDER BY level ASC");

				foreach ($query->rows as $result) {
					$path[] = $result['path_id'];
				}

				// Get whats left of the nodes current path
				$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$category_path['category_id'] . "' ORDER BY level ASC");

				foreach ($query->rows as $result) {
					$path[] = $result['path_id'];
				}

				// Combine the paths with a new level
				$level = 0;

				foreach ($path as $path_id) {
					$this->db->query("REPLACE INTO `" . DB_PREFIX . "category_path` SET category_id = '" . (int)$category_path['category_id'] . "', `path_id` = '" . (int)$path_id . "', level = '" . (int)$level . "'");

					$level++;
				}
			}
		} else {
			// Delete the path below the current one
			$this->db->query("DELETE FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$category_id . "'");

			// Fix for records with no paths
			$level = 0;

			$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$data['parent_id'] . "' ORDER BY level ASC");

			foreach ($query->rows as $result) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "category_path` SET category_id = '" . (int)$category_id . "', `path_id` = '" . (int)$result['path_id'] . "', level = '" . (int)$level . "'");

				$level++;
			}

			$this->db->query("REPLACE INTO `" . DB_PREFIX . "category_path` SET category_id = '" . (int)$category_id . "', `path_id` = '" . (int)$category_id . "', level = '" . (int)$level . "'");
		}

		
		if (isset($data['category_filter'])) {
			foreach ($data['category_filter'] as $filter_id) {
				$this->db->query("DELETE FROM " . DB_PREFIX . "category_filter WHERE category_id = '" . (int)$category_id . "'");
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_filter SET category_id = '" . (int)$category_id . "', filter_id = '" . (int)$filter_id . "'");
			}		
		}

		$this->db->query("DELETE FROM " . DB_PREFIX . "category_to_store WHERE category_id = '" . (int)$category_id . "'");

		if (isset($data['category_store'])) {		
			foreach ($data['category_store'] as $store_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_to_store SET category_id = '" . (int)$category_id . "', store_id = '" . (int)$store_id . "'");
			}
		}

		$this->db->query("DELETE FROM " . DB_PREFIX . "category_to_layout WHERE category_id = '" . (int)$category_id . "'");

		if (isset($data['category_layout'])) {
			foreach ($data['category_layout'] as $store_id => $layout) {
				if ($layout['layout_id']) {
					$this->db->query("INSERT INTO " . DB_PREFIX . "category_to_layout SET category_id = '" . (int)$category_id . "', store_id = '" . (int)$store_id . "', layout_id = '" . (int)$layout['layout_id'] . "'");
				}
			}
		}

		// Seo urls on categories need to be done differently to they include the full keyword path
		$path_parent = $this->getPath($data['parent_id']);

		if (!$path_parent) {
			$path_new = $category_id;
		} else {
			$path_new = $path_parent . '_' . $category_id;
		}

		// Get old data to so we know what to replace
		$seo_url_data = $this->getSeoUrls((int)$category_id);

		// Delete the old path
		$this->db->query("DELETE FROM `" . DB_PREFIX . "seo_url` WHERE `key` = 'path' AND `value` = '" . $this->db->escape($path_old) . "'");

		$this->load->model('design/seo_url');
          if(isset($data['category_seo_url'])){
		foreach ($data['category_seo_url'] as $store_id => $language) {
			foreach ($language as $language_id => $keyword) {
				$parent_info = $this->model_design_seo_url->getSeoUrlByKeyValue('path', $path_parent, $store_id, $language_id);

				if ($parent_info) {
					$keyword = $parent_info['keyword'] . '/' . $keyword;
				}

				$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `store_id` = '" . (int)$store_id . "', `language_id` = '" . (int)$language_id . "', `key` = 'path', `value` = '" . $path_new . "', `keyword` = '" . $keyword . "'");

				// Update sub category seo urls
				if (isset($seo_url_data[$store_id][$language_id])) {
					$this->db->query("UPDATE `" . DB_PREFIX . "seo_url` SET `value` = CONCAT('" . $this->db->escape($path_new . '_') . "', SUBSTRING(`value`, " . (strlen($path_old . '_') + 1) . ")), `keyword` = CONCAT('" . $keyword . "', SUBSTRING(`keyword`, " . (oc_strlen($seo_url_data[$store_id][$language_id]) + 1) . ")) WHERE `store_id` = '" . (int)$store_id . "' AND `language_id` = '" . (int)$language_id . "' AND `key` = 'path' AND `value` LIKE '" . $this->db->escape($path_old . '\_%') . "'");
				}
			}
		}
	}

		$this->cache->delete('category');
	}
	
	public function checkCategoryExist($category_name,$language_id) {
		$category_id=0;
		$query = $this->db->query("SELECT cd.category_id FROM " . DB_PREFIX . "category_description cd  WHERE cd.language_id = '" . (int)$language_id . "' AND cd.name='". $this->db->escape((string)$category_name) ."'");
		
		if($query->row){
				$category_id=$query->row['category_id'];
		}
		return $category_id;
	} 
	public function getTotalCategories() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "category");

		return $query->row['total'];
	}
	public function getCategories($data) {
		if (isset($data['status'])) {
        if ($data['status'] == '1') {
            $statusValue = "AND c.status = '1'";
        } else if ($data['status'] == '0') {
             $statusValue = "AND c.status = '0'";
        }else if ($data['status'] == '2') {
             $statusValue ='';
        }
    }

		$sql = "SELECT cp.category_id AS category_id, GROUP_CONCAT(cd1.name ORDER BY cp.level SEPARATOR ' &gt; ') AS name, c.parent_id, c.sort_order FROM " . DB_PREFIX . "category_path cp LEFT JOIN " . DB_PREFIX . "category c ON (cp.path_id = c.category_id) LEFT JOIN " . DB_PREFIX . "category_to_store cts ON (cts.category_id = c.category_id)  LEFT JOIN " . DB_PREFIX . "category_description cd1 ON (c.category_id = cd1.category_id) LEFT JOIN " . DB_PREFIX . "category_description cd2 ON (cp.category_id = cd2.category_id) WHERE cd1.language_id = '" . $data['language_id'] . "' AND cd2.language_id = '" . $data['language_id'] . "'$statusValue";

			if(!empty($this->request->post['start'])){
				$start =$this->request->post['start'];
			}else{
				$start = 0;
			}
			if(!empty($this->request->post['end'])){
				$end = $this->request->post['end']; 
			}else{
				$end = 0;
			}

			if (!empty($data['filter_name'])) {
			$sql .= " AND cd2.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
			}

			if (!empty($data['store_id'])) {
			$sql .= " AND cts.store_id='" . (int)$data['store_id'] . "'"; // Cast to int to prevent SQL injection
			}


		$sql .= " GROUP BY cp.category_id ORDER BY name";
	    $sql .= " LIMIT " . $start . ", " . $end;
     	$query = $this->db->query($sql);

		return $query->rows;
	}	
	public function getCategory($category_id,$language_id) {
		$status = $this->request->post['status'];

    if (isset($status)) {
        if ($status == '1') {
            $statusValue = "AND c.status = '1'";
        } else if ($status == '0') {
             $statusValue = "AND c.status = '0'";
        }else if ($status == '2') {
             $statusValue ='';
        }
    }
		$query = $this->db->query("SELECT DISTINCT *, (SELECT GROUP_CONCAT(cd1.name ORDER BY level SEPARATOR ' &gt; ') FROM " . DB_PREFIX . "category_path cp LEFT JOIN " . DB_PREFIX . "category_description cd1 ON (cp.path_id = cd1.category_id AND cp.category_id != cp.path_id) WHERE cp.category_id = c.category_id AND cd1.language_id = '" . (int)$this->config->get('config_language_id') . "' GROUP BY cp.category_id) AS path, (SELECT keyword FROM " . DB_PREFIX . "seo_url WHERE `key` = 'category_id=" . (int)$category_id . "' limit 0,1) AS keyword FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd2 ON (c.category_id = cd2.category_id) WHERE c.category_id = '" . (int)$category_id . "' AND cd2.language_id = '" . (int)$language_id . "'$statusValue");

		return $query->row;
	} 
	public function getCategoryname($category,$language_id) {
		$query = $this->db->query("SELECT DISTINCT *, (SELECT GROUP_CONCAT(cd1.name ORDER BY level SEPARATOR ' &gt; ') FROM " . DB_PREFIX . "category_path cp LEFT JOIN " . DB_PREFIX . "category_description cd1 ON (cp.path_id = cd1.category_id AND cp.category_id != cp.path_id) WHERE cp.category_id = c.category_id AND cd1.language_id = '" . (int)$this->config->get('config_language_id') . "' GROUP BY cp.category_id) AS path, (SELECT keyword FROM " . DB_PREFIX . "seo_url WHERE `key` = 'category_id=" . (int)$category_id . "' limit 0,1) AS keyword FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd2 ON (c.category_id = cd2.category_id) WHERE cd2.name = '" . (int)$category . "' AND cd2.language_id = '" . (int)$language_id . "'");
		if(isset($query->row['category_id'])){
		return $query->row['category_id'];}
	} 
	public function getCategoryStores($category_id) {
		$category_store_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_to_store WHERE category_id = '" . (int)$category_id . "'");

		foreach ($query->rows as $result) {
			$category_store_data[] = $result['store_id'];
		}

		return $category_store_data;
	}
	public function gettotalproduct($category_id)
	{
			$query=$this->db->query("select count(*) as total from " . DB_PREFIX . "product_to_category WHERE category_id = '" . (int)$category_id . "'");
			return $query->row['total'];
	}
	public function imagesave($image)
	{
					
				$pos = strpos($image, '=');
				if ($pos === false) {
				
				$path='catalog/productimage/';
				
				if (!file_exists(DIR_IMAGE . $path)) {
					@mkdir(DIR_IMAGE . $path, 0777);
				}
				}
				else
				{
				$image=explode('=',$image);
				$path='data/'.$image[0].'/';
				
				if (!file_exists(DIR_IMAGE . $path)) {
					@mkdir(DIR_IMAGE . $path, 0777);
				}
				$image=$image[1];
				}
				
				
				$pos = strpos($image, 'http://');
				if ($pos === false) {
				$imagepath=$image;
				} else {
				$handlerr = curl_init($image);
				curl_setopt($handlerr,  CURLOPT_RETURNTRANSFER, TRUE);
				$resp = curl_exec($handlerr);
				$ht = curl_getinfo($handlerr, CURLINFO_HTTP_CODE);
				$imagename=explode('/',$image);
				$count=count($imagename);
				$image=str_replace(';','',$imagename[$count-1]);
				$imagepath=$path.$image;
				$imagepath1=DIR_IMAGE.$path.$image;
				// Write the contents back to the file
				@file_put_contents($imagepath1, $resp);
				}
				return $imagepath;
				
				
	}
	public function getCategoryFilters($category_id,$language_id) {
		$category_filter_data2 = '';
		$category_filter_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_filter WHERE category_id = '" . (int)$category_id . "'");

		foreach ($query->rows as $result) {
			$category_filter_data[] = $result['filter_id'];
		}
		
		$this->load->model('catalog/filter');
		
		
		foreach ($category_filter_data as $filter_id) {
			$filter_info = $this->getFilter($filter_id,$language_id);

			if ($filter_info) {
				$category_filter_data2 .= $filter_info['group'] . '::' . $filter_info['name'].';';
			}
		}
		
		return $category_filter_data2;
	}
	public function getFilter($filter_id,$language_id) {
		$query = $this->db->query("SELECT *, (SELECT name FROM " . DB_PREFIX . "filter_group_description fgd WHERE f.filter_group_id = fgd.filter_group_id AND fgd.language_id = '" . $language_id. "') AS `group` FROM " . DB_PREFIX . "filter f LEFT JOIN " . DB_PREFIX . "filter_description fd ON (f.filter_id = fd.filter_id) WHERE f.filter_id = '" . (int)$filter_id . "' AND fd.language_id = '" . $language_id . "'");

		return $query->row;
	}
	public function checkfillter($fillterinfo,$language_id) {
		$fillterinfo=explode('::',$fillterinfo);
		if(isset($fillterinfo[0]) && isset($fillterinfo[1]))
		{
		$query = $this->db->query("SELECT *, (SELECT name FROM " . DB_PREFIX . "filter_group_description fgd WHERE f.filter_group_id = fgd.filter_group_id AND fgd.name = '" . $this->db->escape($fillterinfo[0]). "' and  fgd.language_id = '" . $language_id. "') AS `group` FROM " . DB_PREFIX . "filter f LEFT JOIN " . DB_PREFIX . "filter_description fd ON (f.filter_id = fd.filter_id) WHERE   fd.name='".$this->db->escape($fillterinfo[1])."' and  fd.language_id = '" . $language_id . "'");
		
		if(isset($query->row['filter_id']))
		{
		return $query->row['filter_id'];
		}
		}
	}
	
	
}
?>