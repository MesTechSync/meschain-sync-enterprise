<?php 
namespace Opencart\Admin\Controller\Extension\Tmdimportexportcombo\Tmd;
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/Psr/autoloader.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/myclabs/Enum.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/ZipStream/autoloader.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/ZipStream/ZipStream.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/PhpSpreadsheet/autoloader.php');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Csv;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Xls;


class manufactimport extends \Opencart\System\Engine\Controller {
public function index(): void {
	   $data['VERSION'] = VERSION;
		$this->language->load('extension/tmdimportexportcombo/tmd/manufactimport');
		
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('extension/tmdimportexportcombo/tmd/manufactimport');
		
		$data['heading_title'] = $this->language->get('heading_title1');

	
		$data['otherstoresetting'] = '/index.php?route=extension/tmdimportexportcombo/tmd/manufactimport';
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->session->data['warning'])) {
			$data['error_warning'] = $this->session->data['warning'];
		
			unset($this->session->data['warning']);
		} else {
			$data['error_warning'] = '';
		}
		
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
		
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('extension/tmdimportexportcombo/tmd/manufactimport', 'user_token=' . $this->session->data['user_token'])
		];
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($category_info)) {
			$data['status'] = $category_info['status'];
		} else {
			$data['status'] = 1;
		}
		if(VERSION>='4.0.2.0'){
		$data['export'] = $this->url->link('extension/tmdimportexportcombo/tmd/manufactimport.export', 'user_token=' . $this->session->data['user_token']);

		$data['import'] = $this->url->link('extension/tmdimportexportcombo/tmd/manufactimport.import', 'user_token=' . $this->session->data['user_token']);
		}else {
		$data['export'] = $this->url->link('extension/tmdimportexportcombo/tmd/manufactimport|export', 'user_token=' . $this->session->data['user_token']);

		$data['import'] = $this->url->link('extension/tmdimportexportcombo/tmd/manufactimport|import', 'user_token=' . $this->session->data['user_token']);

		}
		
		$data['user_token'] = $this->session->data['user_token'];


		$this->load->model('localisation/language');

        $this->load->model('setting/store');
		$data['stores'] = $this->model_setting_store->getStores();
		$data['languages'] = $this->model_localisation_language->getLanguages();
		$data['totalmanufacturer']=$this->model_extension_tmdimportexportcombo_tmd_manufactimport->getTotalManufacturer(array());

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/tmdimportexportcombo/tmd/manufactimport', $data));
	}
	public function export() {
		
		$this->language->load('extension/tmdimportexportcombo/tmd/manufactimport');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('extension/tmdimportexportcombo/tmd/manufactimport');
		$this->load->model('localisation/language');
		
		if(isset($this->request->post['format']) && ($this->request->post['format']=='xls' || $this->request->post['format']=='xlsx') )
		{
		$spreadsheet = new Spreadsheet();
		$sheet_numbers = 0;
		$sheet = $spreadsheet->getActiveSheet($sheet_numbers);
		$spreadsheet->setActiveSheetIndex($sheet_numbers);
		// Set properties
		
		$i=1;
		$spreadsheet->getActiveSheet()->SetCellValue('A'.$i, 'Manufacture ID');
		$spreadsheet->getActiveSheet()->SetCellValue('B'.$i, 'Manufacturer Name');
		$spreadsheet->getActiveSheet()->SetCellValue('C'.$i, 'Stores');
		$spreadsheet->getActiveSheet()->SetCellValue('D'.$i, 'SEO Keyword');
		$spreadsheet->getActiveSheet()->SetCellValue('E'.$i, 'Image');
		$spreadsheet->getActiveSheet()->SetCellValue('F'.$i, 'Sort Order');
		
		if(isset($this->request->post['store_id']))
		{
			$store_id=$this->request->post['store_id'];
		}
		else{
			$store_id=false;
		}
		
		if(isset($this->request->post['start']))
		{
			$start=$this->request->post['start'];
		}
		else{
			$start=false;
		}
		
		if(isset($this->request->post['end']))
		{
			$end=$this->request->post['end'];
		}
		else{
			$end=false;
		}
		
		$fillter=array(
				'start'=>$start,
				'limit'=>$end,
				
				
		);

		
		$manufactures = $this->model_extension_tmdimportexportcombo_tmd_manufactimport->getmanufactimport($fillter,$store_id);

		
		
		$total_exports = 0;
		$language_id						= $this->request->post['language_id'];

		
		foreach($manufactures as $manufacture) {			
			
			$stores='';
	
			$keyword =	$this->model_extension_tmdimportexportcombo_tmd_manufactimport->getkeyword($manufacture['manufacturer_id'],$language_id);
			$category_stores =	$this->model_extension_tmdimportexportcombo_tmd_manufactimport->getManufacturerStores($manufacture['manufacturer_id']);
				if($category_stores){
					$stores = implode(',',$category_stores);
				}
			

			$image=$manufacture['image'];
			if(!empty($this->request->post['imageurl']) && !empty($image))
			{
				$image=HTTP_CATALOG.'image/'.$manufacture['image'];
			}
			
			$i++;
			$total_exports++;
			$spreadsheet->getActiveSheet()->SetCellValue('A'.$i, $manufacture['manufacturer_id']);
			$spreadsheet->getActiveSheet()->SetCellValue('B'.$i, str_replace('&amp;','&',$manufacture['name']));
			$spreadsheet->getActiveSheet()->SetCellValue('C'.$i, $stores);
			$spreadsheet->getActiveSheet()->SetCellValue('D'.$i, $keyword);
			$spreadsheet->getActiveSheet()->SetCellValue('E'.$i, $image);
			$spreadsheet->getActiveSheet()->SetCellValue('F'.$i, $manufacture['sort_order']);
			
		}
		
		/* color setup */
				for($col = 'A'; $col != 'F'; $col++) {
			   $spreadsheet->getActiveSheet()->getColumnDimension($col)->setWidth(20);
			 	}
				
				$spreadsheet->getActiveSheet()->getRowDimension(1)->setRowHeight(25);
				
				$spreadsheet->getActiveSheet()
				->getStyle('A1:P1')
				->getFill()
				->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
				->getStartColor()
				->setARGB('FF4F81BD');
				
				$styleArray = array(
					'font'  => array(
					'bold'  => true,
					'color' => array('rgb' => 'FFFFFF'),
					'size'  => 9,
					'name'  => 'Verdana'
				));
				
				$spreadsheet->getActiveSheet()->getStyle('A1:F1')->applyFromArray($styleArray);
				$spreadsheet->getActiveSheet()->setTitle('Manufacture');
				/* color setup */
				
		if($this->request->post['format']=='xls')
		{			
			$filename = 'Manufacture.xls';
			$writer =new \PhpOffice\PhpSpreadsheet\Writer\Xls($spreadsheet);
		}
		if($this->request->post['format']=='xlsx')
		{	
			$filename = 'Manufacture.xlsx';
			$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
			}
		
			header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
			header('Content-Disposition: attachment; filename="'. urlencode($filename).'"');
			$writer->save('php://output');
	}
	else
	{	
				$filename = 'Manufacture.csv';
				$fp = fopen('php://output', 'w');		
				header('Content-type: application/csv');
				header('Content-Disposition: attachment; filename='.$filename);
				
			
		
		
				$data=array("Manufacture ID","Manufacturer Name","Stores(0,1)","Keyword","Image","Sort Order","Status (0=Disable,1=Enable)");
				fputcsv($fp, $data);
				
		if(isset($this->request->post['store_id'])){
			$store_id=$this->request->post['store_id'];
		}
		else{
			$store_id=false;
		}
		
		
		if(isset($this->request->post['start']))
		{
			$start=$this->request->post['start'];
		}
		else{
			$start=false;
		}
		
		if(isset($this->request->post['end']))
		{
			$end=$this->request->post['end'];
		}
		else{
			$end=false;
		}
		
		
		$fillter=array(
				'start'=>$start,
				'limit'=>$end,
				
		);
		
		$manufactures = $this->model_extension_tmdimportexportcombo_tmd_manufactimport->getmanufactimport($fillter,$store_id);
		
		$total_exports = 0;
		
				$language_id						= $this->request->post['language_id'];

		foreach($manufactures as $manufacture) {			
			
			
			$stores='';
	
			$keyword =	$this->model_extension_tmdimportexportcombo_tmd_manufactimport->getkeyword($manufacture['manufacturer_id'],$language_id);
			$category_stores =	$this->model_extension_tmdimportexportcombo_tmd_manufactimport->getManufacturerStores($manufacture['manufacturer_id']);
				if($category_stores){
					$stores = implode(',',$category_stores);
				}
			
			
			
			$image=$manufacture['image'];
			if(!empty($this->request->post['imageurl']) && !empty($image))
			{
				$image=HTTP_CATALOG.'image/'.$manufacture['image'];
			}
			
			
		
			
			$fileds=array($manufacture['manufacturer_id'],str_replace('&amp;','&',$manufacture['name']),$stores,$keyword,$image,$manufacture['sort_order']);
				fputcsv($fp,$fileds);
			
			}
		}
		 fclose($fp);
		
	}
	
	public function import()
	{
		
		$this->language->load('extension/tmdimportexportcombo/tmd/manufactimport');
		$this->load->model('extension/tmdimportexportcombo/tmd/manufactimport');
		
		
		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->user->hasPermission('modify', 'extension/tmdimportexportcombo/tmd/manufactimport')) {
		
			if (is_uploaded_file($this->request->files['import']['tmp_name'])) {
				$content = file_get_contents($this->request->files['import']['tmp_name']);
			} else {
				$content = false;
			}

			$path_parts = pathinfo($this->request->files['import']['name']);
			$extension = $path_parts['extension'];
			
			if ('csv' == $extension && $content && $this->request->post['format']=='csv')
			{
			
				$arrResult = array();
				$handle = fopen($this->request->files['import']['tmp_name'], "r");

				if( $handle ) {
					$i=0;
					$total_insert=0;
					$total_update=0;
					while (($importdata = fgetcsv($handle, 1000, ",")) !== FALSE) {
				
					if($i!=0)
					{
					
				////////////// work here 
				
				$manufacturer_id 					= $importdata['0'];
				$manuftaure_name 					= $importdata['1'];
				$stores 							= $importdata['2']; // 
				$keyword 							= $importdata['3'];
				$image 								= $importdata['4']; 
				$sort_Order 						= $importdata['5']; 
				$language_id						= ($this->request->post['language_id']);
				$store_id						    = ($this->request->post['store_id']);
				
				$manufacturer_store = explode(',',$stores) ;

				
				if(empty($image)){
					$image = '';
				}
				else
				{
					$image=$this->model_extension_tmdimportexportcombo_tmd_manufactimport->imagesave($image);
				}
				

				$manufacturer_seo_url=array();				
				$manufacturer_seo_url[$language_id] =array(
					'keyword' => $keyword,
				);
				
				
				// collect information into array
				$data=array(
					'name'				 		=> $manuftaure_name,
					'sort_order'				=> $sort_Order,
					'image' 					=> $image,
					'manufacturer_store' 		=> $manufacturer_store,
					'manufacturer_seo_url' 		=> $manufacturer_seo_url,
					
				);
				
				// Check if category exist	
				$manufacturer=$this->model_extension_tmdimportexportcombo_tmd_manufactimport->getManufacturer($manufacturer_id,$store_id);
				if(empty($manufacturer)){
					$total_insert++;
					$this->model_extension_tmdimportexportcombo_tmd_manufactimport->addManufacturer($data);
					
				}else{
					$total_update++;
					$this->model_extension_tmdimportexportcombo_tmd_manufactimport->editManufacturer($manufacturer_id,$data);
				}
					}
				$i++;
				
				}
				
				fclose($handle);
				
				}
				$this->session->data['success'] = sprintf( $this->language->get('success_import') , $total_update, $total_insert);
			
				$this->response->redirect($this->url->link('extension/tmdimportexportcombo/tmd/manufactimport','user_token='.$this->session->data['user_token'],''));
				
			}
				
			
			if ($content && ($this->request->post['format']=='xls' || $this->request->post['format']=='xlsx') ) {
				////////////////////////// Started Import work  //////////////
				if($this->request->post['format']=='xls'){
					$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
				}
				else{
					$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
				}
				$spreadsheet = $reader->load($_FILES['import']['tmp_name']);
				$spreadsheet->setActiveSheetIndex(0);
				$sheetDatas = $spreadsheet->getActiveSheet()->toArray(null,true,true,true);
				$i=0;
				/*
				@ arranging the data according to our need
				*/
				$total_insert=0;
				$total_update=0;
				foreach($sheetDatas as $sheetData){
				if($i!=0)
				{
				
				
				$manufacturer_id 					= (string)$sheetData['A'];
				$manuftaure_name 					= (string)$sheetData['B'];
				$stores 							= (string)$sheetData['C']; // 
				$keyword 							= (string)$sheetData['D'];
				$image 								= (string)$sheetData['E']; 
				$sort_Order 						= (string)$sheetData['F']; 
				$language_id						= ($this->request->post['language_id']);
			    $store_id						    = ($this->request->post['store_id']);
				
				$manufacturer_store = explode(',',(string)$stores) ;

				
				if(empty($image)){
					$image = '';
				}
				else
				{
					$image=$this->model_extension_tmdimportexportcombo_tmd_manufactimport->imagesave($image);
				}
				
				$manufacturer_seo_url=array();				
				$manufacturer_seo_url[$language_id] =array(
					'keyword' => $keyword,
				);
				
				
				// collect information into array
				$data=array(
					'name'				 		=> $manuftaure_name,
					'sort_order'				=> $sort_Order,
					'image' 					=> $image,
					'manufacturer_store' 		=> $manufacturer_store,
					'manufacturer_seo_url' 		=> $manufacturer_seo_url,
					'store_id' 		            => $store_id,
				);
				
				
				// Check if category exist	
				$manufacturer=$this->model_extension_tmdimportexportcombo_tmd_manufactimport->getManufacturer($manufacturer_id,$store_id);

				if(empty($manufacturer)){
					$total_insert++;
					$this->model_extension_tmdimportexportcombo_tmd_manufactimport->addManufacturer($data,$manufacturer_id);
					
				}
				else
				{
					$total_update++;
					$this->model_extension_tmdimportexportcombo_tmd_manufactimport->editManufacturer($manufacturer_id,$data);
				}
				
				}
				
				$i++;
				}
				$this->session->data['success'] = sprintf( $this->language->get('success_import') , $total_update, $total_insert);
				$this->response->redirect($this->url->link('extension/tmdimportexportcombo/tmd/manufactimport','user_token='.$this->session->data['user_token'],''));
			}
				
						
			
			$this->session->data['warning']=$this->language->get('error_import'); 
				$this->response->redirect($this->url->link('extension/tmdimportexportcombo/tmd/manufactimport','user_token='.$this->session->data['user_token'],''));
			
		
		
			
				
		}
		else{
			$this->session->data['warning']=$this->language->get('error_import1'); 
				$this->response->redirect($this->url->link('extension/tmdimportexportcombo/tmd/manufactimport','user_token='.$this->session->data['user_token'],''));	
		}
			
	}
}
?>