<?php 
namespace Opencart\Admin\Controller\Extension\Tmdimportexportcombo\Tmd;
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/Psr/autoloader.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/myclabs/Enum.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/ZipStream/autoloader.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/ZipStream/ZipStream.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/PhpSpreadsheet/autoloader.php');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Csv;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Xls;


class catimport extends \Opencart\System\Engine\Controller {
public function index(): void {	
		$data['VERSION'] = VERSION;
		$this->language->load('extension/tmdimportexportcombo/tmd/catimport');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('extension/tmdimportexportcombo/tmd/catimport');
		
		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->user->hasPermission('modify', 'extension/tmdimportexportcombo/tmd/catimport')) {
		
			if (is_uploaded_file($this->request->files['catfile']['tmp_name'])) {
				$content = file_get_contents($this->request->files['catfile']['tmp_name']);
			} else {
				$content = false;
			}
			$path_parts = pathinfo($this->request->files['catfile']['name']);

			if(isset($path_parts['extension'])){
				$extension = $path_parts['extension'];
			}else{
				$extension = '';
			}
			if ('csv' == $extension && $content && $this->request->post['format']=='csv'){
			
				$arrResult = array();
				$handle = fopen($this->request->files['catfile']['tmp_name'], "r");
				if( $handle ) {
					$i=0;
				while (($importdata = fgetcsv($handle, 1000, ",")) !== FALSE) {
				
					if($i!=0)
					{
							
				
				$Category_Id 							= $importdata['0']; // Category Name
				$Stores 								= $importdata['2']; // Stores(0,1)
				$Category_Name 							= $importdata['3']; // Category Name
				$Meta_Tag_Description 					= $importdata['4']; // Meta Tag Description
				$Meta_Tag_Keywords 						= $importdata['5']; // Meta Tag Keywords
				$Description 							= $importdata['6']; // Description
				$Parent 								= $importdata['7']; // Parent
				$SEO_Keyword 							= $importdata['8']; // SEO Keyword
				$Image 									= $importdata['9']; // Image
				$Top 									= $importdata['10']; // Top(0=no,1=yes)
				$Columns 								= $importdata['11']; // Columns
				$Sort_Order 						    = $importdata['12']; // Sort Order
				$Status 								= $importdata['13'];  // Status(0=Disable;1=enable)
				$fillter 						= $importdata['14'];  // Status(0=Disable;1=enable)
				if(!isset($sheetData['O']))
				{
					$sheetData['O']='';
				}
				$metatitle 								= $sheetData['O'];  // Status(0=Disable;1=enable)
				$Language_id										= $this->request->post['language_id']; // Language ids of store 0
				
				if(!empty($Category_Name)){
				$category_description=array();				
				$category_description[$Language_id] = array(
					'name' => $Category_Name,
					'meta_keyword' => $Meta_Tag_Keywords,
					'meta_description' => $Meta_Tag_Description,
					'description' => $Description,
					'meta_title' => $metatitle,
				);
				
				$category_filter=array();
				if(!empty($fillter))
				{
					$fillter=explode(';',$fillter);
					if(!empty($fillter))
					{
						foreach($fillter as $fillterinfo)
						{
							$filter_id=$this->model_extension_tmdimportexportcombo_tmd_catimport->checkfillter($fillterinfo,$Language_id);
							if(isset($filter_id))
							{
								$category_filter[]=$filter_id;
							}
						}
					}
				}
				
				if(empty($Stores)){
					$Stores=0;
				}
				$category_store = explode(',',$Stores) ; 

				$category_layout = array();
				$layout_id = false;
				if($layout_id){
					foreach($category_store as $store_id){
						$category_layout[$store_id] = array( 'layout_id' => $layout_id );
					}				
				}
				
				if(empty($Image)){
					$Image = 'no_image.jpg';
				}
				else
				{
					$Image=$this->model_extension_tmdimportexportcombo_tmd_catimport->imagesave($Image);
				}
				
				// get parent_id if parent name				
				$parent_id = $this->model_extension_tmdimportexportcombo_tmd_catimport->checkCategoryExist($Parent,$Language_id);
				
				//Seo Keywords
				$lang_keyword[$Language_id]=$SEO_Keyword;
				$category_seourl[$Stores]=$lang_keyword;

				// collect information into array
				$data=array(
					'parent_id' 						=> $parent_id,
					'top' 									=> $Top,
					'column' 								=> $Columns,
					'sort_order'				 		=> $Sort_Order,
					'status' 								=> $Status,
					'image' 								=> $Image,
					'category_description' 	=> $category_description,
					'category_filter' 			=> $category_filter, 
					'category_store' 				=> $category_store,
					'category_layout' 			=> $category_layout,
					'keyword' 							=> $SEO_Keyword,
					'category_seo_url' 							=> $category_seourl,
				);
				
				// Check if category exist	
				
				
				// category present in database, update it
				if($Category_Id!=0){
					$this->model_extension_tmdimportexportcombo_tmd_catimport->editCategory($Category_Id,$data,$Language_id);
					$total_update++;
				}else{
					$category_id = $this->model_extension_tmdimportexportcombo_tmd_catimport->addCategory($data);
					$total_insert++;
				}
				}
					}
					$i++;
				}
				fclose($handle);
				}
				
				
				
				
				 $this->session->data['success'] = sprintf( $this->language->get('success_category_import') , $total_update, $total_insert);
		
			$this->response->redirect($this->url->link('extension/tmdimportexportcombo/tmd/catimport','user_token='.$this->session->data['user_token'],''));
				

			}
			
			if ($content && ($this->request->post['format']=='xls' || $this->request->post['format']=='xlsx') ) {
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
				if($this->request->post['format']=='xls'){
					$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
				}
				$spreadsheet = $reader->load($_FILES['catfile']['tmp_name']);
				$spreadsheet->setActiveSheetIndex(0);
				$sheetDatas = $spreadsheet->getActiveSheet()->toArray(null,true,true,true);
				$i=0;
			
				$total_insert=0;
				$total_update=0;
				foreach($sheetDatas as $sheetData){
				if($i!=0)
				{

				
				$Category_Id 							= $sheetData['A']; // Category Name
				$Stores 								= $sheetData['C']; // Stores(0,1)
				$Category_Name 							= $sheetData['D']; // Category Name
				$Meta_Tag_Description 					= $sheetData['E']; // Meta Tag Description
				$Meta_Tag_Keywords 						= $sheetData['F']; // Meta Tag Keywords
				$Description 							= $sheetData['G']; // Description
				$Parent 								= $sheetData['H']; // Parent
				$SEO_Keyword 							= $sheetData['I']; // SEO Keyword
				$Image 									= $sheetData['J']; // Image
				$Top 									= $sheetData['K']; // Top(0=no,1=yes)
				$Columns 								= $sheetData['L']; // Columns
				$Sort_Order 						    = $sheetData['M']; // Sort Order
				$Status 								= $sheetData['N'];  // Status(0=Disable;1=enable)
				$metatitle 								= $sheetData['O'];  // Status(0=Disable;1=enable)
				$fillter 								= $sheetData['P'];  // Status(0=Disable;1=enable)
				$Language_id										= $this->request->post['language_id']; // Language ids of store 0
				
				$category_filter=array();
				if(!empty($fillter))
				{
					$fillter=explode(';',$fillter);
					if(!empty($fillter))
					{
						foreach($fillter as $fillterinfo)
						{
							$filter_id=$this->model_extension_tmdimportexportcombo_tmd_catimport->checkfillter($fillterinfo,$Language_id);
							if(isset($filter_id))
							{
								$category_filter[]=$filter_id;
							}
						}
					}
				}
				
				
				if(!empty($Category_Name)){
				$category_description=array();				
				$category_description[$Language_id] = array(
					'name' => $Category_Name,
					'meta_keyword' => $Meta_Tag_Keywords,
					'meta_description' => $Meta_Tag_Description,
					'description' => $Description,
					'meta_title' => $metatitle,
				);
				
				if(empty($Stores)){
					$Stores=0;
				}
				$category_store = explode(',',$Stores) ; ;

				$category_layout = array();
				$layout_id = false;
				if($layout_id){
					foreach($category_store as $store_id){
						$category_layout[$store_id] = array( 'layout_id' => $layout_id );
					}				
				}
				
				if(empty($Image)){
					$Image = 'no_image.jpg';
				}
				else
				{
					$Image=$this->model_extension_tmdimportexportcombo_tmd_catimport->imagesave($Image);
				}
				
				// get parent_id if parent name				
				$parent_id = $this->model_extension_tmdimportexportcombo_tmd_catimport->checkCategoryExist($Parent,$Language_id);
				
				//Seo Keywords
				$lang_keyword[$Language_id]=$SEO_Keyword;
				$category_seourl[$Stores]=$lang_keyword;
				
				$data=array(
					'parent_id' 						=> $parent_id,
					'top' 									=> $Top,
					'column' 								=> $Columns,
					'sort_order'				 		=> $Sort_Order,
					'status' 								=> $Status,
					'image' 								=> $Image,
					'category_description' 	=> $category_description,
					'category_filter' 			=> $category_filter, 
					'category_store' 				=> $category_store,
					'category_layout' 			=> $category_layout,
					'keyword' 							=> $SEO_Keyword,
					'category_seo_url' 							=> $category_seourl,
				);
				
				// Check if category exist	
				
				
				// category present in database, update it
				if($Category_Id!=0){
					$this->model_extension_tmdimportexportcombo_tmd_catimport->editCategory($Category_Id,$data,$Language_id);
					$total_update++;
				}else{
					$category_id = $this->model_extension_tmdimportexportcombo_tmd_catimport->addCategory($data);
					$total_insert++;
				}
				}
				}
				$i++;
				
			}	
			
			$this->session->data['success'] = sprintf( $this->language->get('success_category_import') , $total_update, $total_insert);
			
			$this->response->redirect($this->url->link('extension/tmdimportexportcombo/tmd/catimport','user_token='.$this->session->data['user_token'],''));
			}
			else
			{
				$this->session->data['warning'] = $this->language->get('error_empty'); 
			}
		}
			
		$this->tpl_render();
	}
	
	public function tpl_render(){
		
		$data['heading_title'] = $this->language->get('heading_title');


		if (isset($this->session->data['warning'])) {
			$data['error_warning'] = $this->session->data['warning'];
		
			unset($this->session->data['warning']);
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
		
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		$data['user_token'] = $this->session->data['user_token'];
		
		$data['breadcrumbs'] = [];
		$data['breadcrumbs'][] = [
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'])
		];
		
		$data['breadcrumbs'][] = [
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('extension/tmdimportexportcombo/tmd/catimport', 'user_token=' . $this->session->data['user_token'])
			];
		
			
		$data['import'] = $this->url->link('extension/tmdimportexportcombo/tmd/catimport', 'user_token=' . $this->session->data['user_token']);
		if(VERSION>='4.0.2.0'){
		$data['export'] = $this->url->link('extension/tmdimportexportcombo/tmd/catimport.export', 'user_token=' . $this->session->data['user_token']);
     	}else {
			$data['export'] = $this->url->link('extension/tmdimportexportcombo/tmd/catimport|export', 'user_token=' . $this->session->data['user_token']);

		}
			
	
		$data['totalcategory']=$this->model_extension_tmdimportexportcombo_tmd_catimport->getTotalCategories(array());
	
		$this->load->model('setting/store');
		$data['stores'] = $this->model_setting_store->getStores();

		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();
		
	
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/tmdimportexportcombo/tmd/catimport', $data));
		
		
		
	}

	
	public function export() {
		
		
		$this->language->load('extension/tmdimportexportcombo/tmd/catimport');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('extension/tmdimportexportcombo/tmd/catimport');
	
		$this->load->model('localisation/language');
		
		if(isset($this->request->post['format']) && ($this->request->post['format']=='xls' || $this->request->post['format']=='xlsx') ){
		$spreadsheet = new Spreadsheet();

		
		$i=1;
		$spreadsheet->getActiveSheet()->SetCellValue('A'.$i, 'Category ID');
		$spreadsheet->getActiveSheet()->SetCellValue('B'.$i, 'Language');
		$spreadsheet->getActiveSheet()->SetCellValue('C'.$i, 'Stores(0,1)');
		$spreadsheet->getActiveSheet()->SetCellValue('D'.$i, 'Category Name');
		$spreadsheet->getActiveSheet()->SetCellValue('E'.$i, 'Meta Tag Description');
		$spreadsheet->getActiveSheet()->SetCellValue('F'.$i, 'Meta Tag Keywords');
		$spreadsheet->getActiveSheet()->SetCellValue('G'.$i, 'Description');
		$spreadsheet->getActiveSheet()->SetCellValue('H'.$i, 'Parent');
		$spreadsheet->getActiveSheet()->SetCellValue('I'.$i, 'SEO Keyword');
		$spreadsheet->getActiveSheet()->SetCellValue('J'.$i, 'Image');
		$spreadsheet->getActiveSheet()->SetCellValue('K'.$i, 'Top(0=no,1=yes)');
		$spreadsheet->getActiveSheet()->SetCellValue('L'.$i, 'Columns');
		$spreadsheet->getActiveSheet()->SetCellValue('M'.$i, 'Sort Order');
		$spreadsheet->getActiveSheet()->SetCellValue('N'.$i, 'Status(0=Disable;1=enable)');
		$spreadsheet->getActiveSheet()->SetCellValue('O'.$i, 'Meta Title');
		$spreadsheet->getActiveSheet()->SetCellValue('P'.$i, 'Fillter (filltergroup::name;)');
		$spreadsheet->getActiveSheet()->SetCellValue('Q'.$i, 'Total Product');
		
		if(isset($this->request->post['store_id']))
		{
			$store_id=$this->request->post['store_id'];
		}
		else{
			$store_id=false;
		}
		
		if(isset($this->request->post['language_id']))
		{
			$language_id=$this->request->post['language_id'];
		}
		else{
			$language_id=false;
		}
		
		if(isset($this->request->post['start']))
		{
			$start=$this->request->post['start'];
		}
		else{
			$start=false;
		}
		
		if(isset($this->request->post['end']))
		{
			$end=$this->request->post['end'];
		}
		else{
			$end=false;
		}
		

		if(isset($this->request->post['status']))
		{
			$status=$this->request->post['status'];
		}
		else{
			$status=false;
		}
		
		$fillter=array(
				'store_id'=>$store_id,
				'language_id'=>$language_id,
				'start'=>$start,
				'limit'=>$end,
				'status'=>$status,
				
		);
		
		$categories = $this->model_extension_tmdimportexportcombo_tmd_catimport->getCategories($fillter);
		
		$total_exports = 0;
		
		foreach($categories as $category) {			
			
			$parent='';
			$stores='';
			$language='';
			$totalproduct='';
			$filters='';
			
			$category_info = $this->model_extension_tmdimportexportcombo_tmd_catimport->getCategory($category['category_id'],$language_id);
						
			if(isset($category_info['language_id']))
			{
			$language = $this->model_localisation_language->getLanguage($category_info['language_id']);
			}
			else
			{
					$language = $this->model_localisation_language->getLanguage($this->request->post['language_id']);
			}
			if($category_info){
				if($category_info['parent_id']!=$category_info['category_id']){
				$category_parent_info = $this->model_extension_tmdimportexportcombo_tmd_catimport->getCategory($category_info['parent_id'],$language_id);			
				if($category_parent_info){
						$parent=$category_parent_info['name'];
				}
				}
				$category_stores =	$this->model_extension_tmdimportexportcombo_tmd_catimport->getCategoryStores($category['category_id']);
				if($category_stores){
					$stores = implode(',',$category_stores);
			}
			
			$totalproduct=$this->model_extension_tmdimportexportcombo_tmd_catimport->gettotalproduct($category['category_id']);
			
			$image=$category_info['image'];
			if(!empty($this->request->post['imageurl']) && !empty($image))
			{
				$image=HTTP_CATALOG.'image/'.$category_info['image'];
			}
			
			$filters=$this->model_extension_tmdimportexportcombo_tmd_catimport->getCategoryFilters($category['category_id'],$language_id);
			
			//Seo Keyword
			$seoquery_info = $this->db->query("SELECT * FROM `" . DB_PREFIX . "seo_url` WHERE `key` ='path' AND `value` ='".(int)$category['category_id']."' AND language_id = '" . (int)$language_id . "' AND store_id = '" . (int)$store_id . "'")->row;
			$seo_keyword = !empty($seoquery_info['keyword'])?$seoquery_info['keyword']:'';
						
			$i++;
			$total_exports++;

			$spreadsheet->getActiveSheet()->SetCellValue('A'.$i, $category['category_id']);
			$spreadsheet->getActiveSheet()->SetCellValue('B'.$i, $language['code']);
			$spreadsheet->getActiveSheet()->SetCellValue('C'.$i, $stores);
			$spreadsheet->getActiveSheet()->SetCellValue('D'.$i, str_replace('&amp;','&',$category_info['name']));
			$spreadsheet->getActiveSheet()->SetCellValue('E'.$i,  html_entity_decode($category_info['meta_description'], ENT_QUOTES, 'UTF-8'));
			$spreadsheet->getActiveSheet()->SetCellValue('F'.$i, html_entity_decode($category_info['meta_keyword'], ENT_QUOTES, 'UTF-8'));
			$spreadsheet->getActiveSheet()->SetCellValue('G'.$i,  html_entity_decode($category_info['description'], ENT_QUOTES, 'UTF-8'));
			$spreadsheet->getActiveSheet()->SetCellValue('H'.$i, str_replace('&amp;','&',$parent));
			$spreadsheet->getActiveSheet()->SetCellValue('I'.$i, $seo_keyword);
			$spreadsheet->getActiveSheet()->SetCellValue('J'.$i, $image);
			$spreadsheet->getActiveSheet()->SetCellValue('K'.$i, $category_info['top']);
			$spreadsheet->getActiveSheet()->SetCellValue('L'.$i, $category_info['column']);
			$spreadsheet->getActiveSheet()->SetCellValue('M'.$i, $category_info['sort_order']);
			$spreadsheet->getActiveSheet()->SetCellValue('N'.$i, $category_info['status']);
			$spreadsheet->getActiveSheet()->SetCellValue('O'.$i, $category_info['meta_title']);
			$spreadsheet->getActiveSheet()->SetCellValue('P'.$i, $filters);
			$spreadsheet->getActiveSheet()->SetCellValue('Q'.$i, $totalproduct);
		
		
			
			}
		}
		
				for($col = 'A'; $col != 'Q'; $col++) {
			   $spreadsheet->getActiveSheet()->getColumnDimension($col)->setWidth(20);
			 	}
				
				$spreadsheet->getActiveSheet()->getRowDimension(1)->setRowHeight(25);
				
				$spreadsheet->getActiveSheet()
				->getStyle('A1:Q1')
				->getFill()
				->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
				->getStartColor()
				->setARGB('FF4F81BD');
				
				$styleArray = array(
					'font'  => array(
					'bold'  => true,
					'color' => array('rgb' => 'FFFFFF'),
					'size'  => 9,
					'name'  => 'Verdana'
				));
				
				$spreadsheet->getActiveSheet()->getStyle('A1:Q1')->applyFromArray($styleArray);
				$spreadsheet->getActiveSheet()->setTitle('Category');
				if($this->request->post['format']=='xls')
		{			
			$filename = 'Category.xls';
			$writer =new \PhpOffice\PhpSpreadsheet\Writer\Xls($spreadsheet);
			
		}
		if($this->request->post['format']=='xlsx')
		{	
			$filename = 'Category.xlsx';
			$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
			
		}
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename="'. urlencode($filename).'"');
		$writer->save('php://output');
		
		
	}else{	
				$filename = 'category.csv';
				$fp = fopen('php://output', 'w');		
				header('Content-type: application/csv');
				header('Content-Disposition: attachment; filename='.$filename);

				
				$data=array("Category ID","Language","Stores(0,1)","Category Name","Meta Tag Description","Meta Tag Keywords","Description","Parent","SEO Keyword","Image","Top(0=no,1=yes)","Columns","Sort Order","Status(0=Disable;1=enable)","Meta Title","Fillter (filltergroup::name;)","Total Product");
				fputcsv($fp, $data);
				
		if(isset($this->request->post['store_id'])){
			$store_id=$this->request->post['store_id'];
		}else{
			$store_id=false;
		}
		
		if(isset($this->request->post['language_id'])){
			$language_id=$this->request->post['language_id'];
		}else{
			$language_id=false;
		}
		
		if(isset($this->request->post['start'])){
			$start=$this->request->post['start'];
		}else{
			$start=false;
		}
		
		if(isset($this->request->post['end'])){
			$end=$this->request->post['end'];
		}else{
			$end=false;
		}
		
		if(isset($this->request->post['status'])){
			$status=$this->request->post['status'];
		}else{
			$status=false;
		}
		
		$fillter=array(
				'store_id'=>$store_id,
				'language_id'=>$language_id,
				'start'=>$start,
				'limit'=>$end,
				'status'=>$status,
				
		);
		
		$categories = $this->model_extension_tmdimportexportcombo_tmd_catimport->getCategories($fillter);
		
		$total_exports = 0;
		
		foreach($categories as $category) {			
			
			$parent='';
			$stores='';
			$language='';
			$totalproduct='';
			
			$category_info = $this->model_extension_tmdimportexportcombo_tmd_catimport->getCategory($category['category_id'],$language_id);	
			
			if(isset($category_info['language_id']))
			{
			$language = $this->model_localisation_language->getLanguage($category_info['language_id']);
			}
			else
			{
					$language = $this->model_localisation_language->getLanguage($this->request->post['language_id']);
			}
			if($category_info){
				if($category_info['parent_id']!=$category_info['category_id']){
				$category_parent_info = $this->model_extension_tmdimportexportcombo_tmd_catimport->getCategory($category_info['parent_id'],$language_id);				
				if($category_parent_info){
						$parent=$category_parent_info['name'];
				}
				}
				$category_stores =	$this->model_extension_tmdimportexportcombo_tmd_catimport->getCategoryStores($category['category_id']);
				if($category_stores){
					$stores = implode(',',$category_stores);
			}
			
			$totalproduct=$this->model_extension_tmdimportexportcombo_tmd_catimport->gettotalproduct($category['category_id']);
			
			$image=$category_info['image'];
			if(!empty($this->request->post['imageurl']) && !empty($image))
			{
				$image=HTTP_CATALOG.'image/'.$category_info['image'];
			}
			
			$filters=$this->model_extension_tmdimportexportcombo_tmd_catimport->getCategoryFilters($category['category_id'],$language_id);
			
			//Seo Keyword
			$seoquery_info = $this->db->query("SELECT * FROM `" . DB_PREFIX . "seo_url` WHERE `key` ='path' AND `value` ='".(int)$category['category_id']."' AND language_id = '" . (int)$language_id . "' AND store_id = '" . (int)$store_id . "'")->row;
			$seo_keyword = !empty($seoquery_info['keyword'])?$seoquery_info['keyword']:'';
			
						
			$fileds=array($category['category_id'],$language['code'],$stores,str_replace('&amp;','&',$category_info['name']),html_entity_decode($category_info['meta_description'], ENT_QUOTES, 'UTF-8'),html_entity_decode($category_info['meta_keyword'], ENT_QUOTES, 'UTF-8'),html_entity_decode($category_info['description'], ENT_QUOTES, 'UTF-8'),str_replace('&amp;','&',$parent),$seo_keyword,$image,$category_info['top'],$category_info['column'],$category_info['sort_order'],$category_info['status'],$category_info['name'],$filters,$totalproduct);
				fputcsv($fp,$fileds);
			
			}
		}
		 fclose($fp);
		
				
				
		
	}
	}
	
}
?>