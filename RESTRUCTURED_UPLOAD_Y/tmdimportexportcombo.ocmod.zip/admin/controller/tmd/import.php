<?php 
namespace Opencart\Admin\Controller\Extension\Tmdimportexportcombo\Tmd;
// Lib Include 
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/Psr/autoloader.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/myclabs/Enum.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/ZipStream/autoloader.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/ZipStream/ZipStream.php');
require_once(DIR_EXTENSION.'/tmdimportexportcombo/system/library/tmd/PhpSpreadsheet/autoloader.php');
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Csv;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Xls;

class Import extends \Opencart\System\Engine\Controller {
public function index(): void {	
		$data['VERSION'] = VERSION;
		$totalnewproduct=0;
		$totalupdateproduct=0;
		$this->language->load('extension/tmdimportexportcombo/tmd/import');
	
		
		$defaultfild=array();
		$defaultfild[]='product_id';
		$defaultfild[]='model';
		$defaultfild[]='sku';
		$defaultfild[]='upc';
		$defaultfild[]='ean';
		$defaultfild[]='jan';
		$defaultfild[]='isbn';
		$defaultfild[]='mpn';
		$defaultfild[]='location';
		$defaultfild[]='quantity';
		$defaultfild[]='stock_status_id';
		$defaultfild[]='image';
		$defaultfild[]='manufacturer_id';
		$defaultfild[]='shipping';
		$defaultfild[]='price';
		$defaultfild[]='points';
		$defaultfild[]='tax_class_id';
		$defaultfild[]='date_available';
		$defaultfild[]='weight';
		$defaultfild[]='weight_class_id';
		$defaultfild[]='length';
		$defaultfild[]='width';
		$defaultfild[]='height';
		$defaultfild[]='length_class_id';
		$defaultfild[]='subtract';
		$defaultfild[]='minimum';
		$defaultfild[]='sort_order';
		$defaultfild[]='status';
		$defaultfild[]='date_added';
		$defaultfild[]='date_modified';
		$defaultfild[]='master_id';
		$defaultfild[]='variant';
		$defaultfild[]='override';
		

		$query=$this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "product");
		$data['cfiled']=array();
		foreach($query->rows as $row)
		{
			if(!in_array($row['Field'],$defaultfild))
			{
			$data['cfiled'][]=$row['Field'];
			}
		}
		$cfileds=$data['cfiled'];
		
		

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('extension/tmdimportexportcombo/tmd/import');
			
		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->user->hasPermission('modify', 'extension/tmdimportexportcombo/tmd/import')) {
		
			$language_id=$this->request->post['language_id'];
			$store_id=$this->request->post['store_id'];
			$importby=$this->request->post['importby'];
			
			if (is_uploaded_file($this->request->files['import']['tmp_name'])) {
				$content = file_get_contents($this->request->files['import']['tmp_name']);
			} else {
				$content = false;
			}

			$path_parts = pathinfo($this->request->files['import']['name']);
				if(isset($path_parts['extension'])){
				$extension = $path_parts['extension'];
				}else{
				$extension = '';
				}

			if ('xml' == $extension && $content && $this->request->post['format']=='xml')
			{
			$xml = simplexml_load_string($content);
			$i=0;
			foreach($xml->PRODUCT as $xmlData) {
			$model	=	$xmlData->MODEL;
				
				if(!empty($model))
				{
					
				/* stroers */
				$product_stores=array();
				$product_stores[]=0;
				
				$product_stornew = explode(';', $xmlData->Stores);
				
				if(isset($product_stornew))
				{
					foreach($product_stornew as $product_store)
					{
					if(!empty($product_store))
						{
							$product_stores[]=(int)($product_store);
						}
					}
				}
				$product_stores=array_unique($product_stores);
				
				/*  END Stores */
				
				/* Step Get category ids  */
				$catgoryname = $xmlData->Categories;
				$catgorynames=explode(';',$catgoryname);
				$category_id=array();
				if(isset($catgorynames))
				{
					foreach($catgorynames as $category)
					{
						$category=($category);
						if(!empty($category))
						{
							$category_id[]=$this->model_extension_tmdimportexportcombo_tmd_import->category($category,0,$store_id,$language_id);
						}
					}
				}
				/* Step Get category ids  */
				
				/* Step Get Barnd  ids  */
				$brandname=$xmlData->Manufacturer;
				$brandnames=explode(';',(string)$brandname);
				$brand_id='';
				if(isset($brandnames))
				{
					foreach($brandnames as $brand)
					{
						$brand=($brand);
						if(!empty($brand))
						{
							$brand_id=$this->model_extension_tmdimportexportcombo_tmd_import->barnd($brand,$store_id,$language_id);
						}
					}
				}
				
				/* Step Get Barnd  ids  */
				
				/* Step Get Options and value insert  */
				$options=$xmlData->OptionName;
				$options=explode(';',$options);
				
				if(isset($options))
				{
					foreach($options as $option)
					{
						$option=($option);
						if(!empty($option))
						{
							$this->model_extension_tmdimportexportcombo_tmd_import->option($option,$language_id);
						}
					}
				}
				
				$options=$xmlData->OptionValue;
				$options=explode(';',$options);
				$productoptions=array();
				if(!empty($options))
				{
					foreach($options as $option)
					{
						$option=($option);
						if(!empty($option))
						{
							$productoptions[]=$this->model_extension_tmdimportexportcombo_tmd_import->optionvalue($option,$language_id);
						}
					}
				}
				/* Step End Get Options and value insert  */
				
			
				/* Step Product Main Image  */
				$image=$xmlData->Image;
				if(!empty($image))
				{
				$mainimage=$this->model_extension_tmdimportexportcombo_tmd_import->imagesave($image);
				}
				else
				{
				$mainimage='';
				}
			
				/* Step End Product Main Image  */
				
				/* Step Start Product Filter Group  entry */
				
				if(isset($xmlData->FilterGroupName))
				{
					
				$filtergroup=$xmlData->FilterGroupName;
				if(!empty($filtergroup))
				{
					$filtergroups=explode(';',$filtergroup);
					if(!empty($filtergroups))
					{
						foreach($filtergroups as $filtergroup)
						{
							$filtergroup=($filtergroup);
							if(!empty($filtergroup))
							{
								$this->model_extension_tmdimportexportcombo_tmd_import->filtergroup($filtergroup,$language_id);
							}
						}
					}
				}
				}
				/* Step Start Product Filter name  entry */
				$fillterids=array();
				if(isset($xmlData->FilterNames))
				{
				$filternames=$xmlData->FilterNames;
				if(!empty($filternames))
				{
					$filternames=explode(';',$filternames);
					if(!empty($filternames))
					{
						
						foreach($filternames as $filtername)
						{
							$filtername=($filtername);
							if(!empty($filtername))
							{
							$fillterids[]=$this->model_extension_tmdimportexportcombo_tmd_import->filtername($filtername,$language_id);
							}
						}
					}
				}
				}
				
			
				
				/* Start Attribute work */
				$attributes=array();
				if(isset($xmlData->Attributes))
				{
				$attributesname=$xmlData->Attributes;
				if(!empty($attributesname))
				{
					$attributess=explode(';',$attributesname);
					if(!empty($attributess))
					{
						
						foreach($attributess as $attribute)
						{
							if(!empty($attribute))
							{
							$attinfo=$this->model_extension_tmdimportexportcombo_tmd_import->atributeallinfo($attribute,$language_id);
							$attributes[]=array(
							'attribute_id'=>$attinfo['attribute_id'],
							'text'=>$attinfo['text']
							);
							}
						}
					}
				}
				
				}
				
				/* End Attribute work */
				$discounts=array();
				if(isset($xmlData->Discount))
				{
					$discountinfo=$xmlData->Discount;
					$discountinfos=explode(';',$discountinfo);
					if(!empty($discountinfos))
					{
						foreach($discountinfos as $discount)
						{
							if(!empty($discount))
							{
							$info=explode(':',$discount);
							$discounts[]=array(
							'customer_group_id'=>$info[0],
							'quantity'=>$info[1],
							'priority'=>$info[2],
							'price'=>$info[3],
							'date_start'=>$info[4],
							'date_end'=>$info[5]
							);
							}
						}
						
					}
				}
		
				
				/* Reward point */
				$point='';
				if(!empty($xmlData->RewardPoints))
				{
				$point=$xmlData->RewardPoints;
				}
				
				/* Step Product Images  */
				$productimages=array();
				$images=$xmlData->additionalImages;
				$images=explode(';',$images);
				
				if(isset($images))
				{
					foreach($images as $image)
					{
					
						if(!empty($image))
						{
						$productimages[]=$this->model_extension_tmdimportexportcombo_tmd_import->imagesave($image);
						}
					}
				}
				
				/* Step End Product Images  */
				
				/* Step Product Speical price  */
				 $specialpricenew=$xmlData->SpeicalPrice;
				
				$specialprice=array();
				if(!empty($specialpricenew))
				{
				$specialpriceset=explode(';',$specialpricenew);
				
				foreach($specialpriceset as $set)
					{
					if(!empty($set))
						{
						list($customer_group_id,$startdate,$enddate,$price)=explode(':',$set);
						$specialprice[]=array(
								'price'=>$price,
								'priority'=>1,
								'customer_group_id'=>$customer_group_id,
								'date_start'=>$startdate,
								'date_end'=>$enddate
						);
					}
					}
				}
				
	
				
				/* Step related products */
				 $relatedprodctinfo=$xmlData->RelatedProduct;
				
				$product_related=array();
				if(!empty($relatedprodctinfo))
				{
				$relatedprodctinfos=explode(';',$relatedprodctinfo);
				
				foreach($relatedprodctinfos as $relatedprodctinfo)
					{
					if(!empty($relatedprodctinfo))
						{
						$product_related[]=$this->model_extension_tmdimportexportcombo_tmd_import->getproductbymodel($relatedprodctinfo);
					}
					}
				}
				
				/* Step End Product related  */
				
				
				/* Start Review  work */
				$reviews=array();
				$productreview=($xmlData->Reviews);
				if(!empty($productreview))
				{
						$productreviews=explode('|',$productreview);
						foreach($productreviews as $productreview)
						{
							$productreview=($productreview);
							if(!empty($productreview))
							{
								$productreview=explode('::',$productreview);
								$reviews[]=array(
								'customer_id'=>$productreview[0],
								'author'=>$productreview[1],
								'text'=>$productreview[2],
								'rating'=>$productreview[3],
								'status'=>$productreview[4],
								'date_added'=>$productreview[5],
								'date_modified'=>$productreview[6],
								);
							}
						}
				}
				
				
				/* END Review  work /
				
				
				/* Start Product Download */
				
				$productdownloads=array();
				$downloadids=($xmlData->Downloadid);
				if(!empty($downloadids))
				{
					$downloadids=explode(';',$downloadids);
					foreach($downloadids as $downloadid)
					{
						if(isset($downloadid))
						{
						$productdownloads[]=$downloadid;
						}
					}
				}
				
		
				/* end Product Download */
				
				/* Step Product other  info collect */
				$model=$xmlData->MODEL;
				$sku=$xmlData->SKU;
				$upc=$xmlData->UPC;
				$ean=$xmlData->EAN;
				$jan=$xmlData->JAN;
				$isbn=$xmlData->ISBN;
				$mpn=$xmlData->MPN;
				$location=$xmlData->Location;
				$productname=$xmlData->ProductName;
				$metadescription=$xmlData->MetaTagDescription;
				$metatag=$xmlData->MetaTagKeywords;
				$description=$xmlData->Description;
				$tags=$xmlData->ProductTags;
				$price=$xmlData->Price;
				$quantity=$xmlData->Quantity;
				$mquantity=$xmlData->MinimumQuantity;
				$subtractstock=$xmlData->SubtractStock;
				$stockstatus=$xmlData->OutOfStockStatus;
				$shipping=$xmlData->RequiresShipping;
				$keyword=$xmlData->SEOKeyword;
				$available=$xmlData->DateAvailable;
				$lengthclass=$xmlData->LengthClass;
				$length=$xmlData->Length;
				$width=$xmlData->Width;
				$height=$xmlData->height;
				$weight=$xmlData->Weight;
				$weightclass=$xmlData->WeightClass;
				$status=$xmlData->Status;
				$sort_order=$xmlData->SortOrder;
				$meta_title=$xmlData->MetaTitle;
				$reviews=$reviews;
				
				if(isset($xmlData->TaxClass))
				{
				$tax_class_id=$xmlData->TaxClass;
				}
				else
				{
				$tax_class_id='';
				}
				$data1=array(
				'product_category'=>$category_id,
				'manufacturer_id'=>$brand_id,
				'meta_title'=>$meta_title,
				'productoptions'=>$productoptions,
				'product_special'=>$specialprice,
				'image'=>$mainimage,
				'product_image'=>$productimages,
				'model'=>$model,
				'sku'=>$sku,
				'upc'=>$upc,
				'ean'=>$ean,
				'jan'=>$jan,
				'isbn'=>$isbn,
				'available'=>$available,
				'mpn'=>$mpn,
				'location'=>$location,
				'name'=>$productname,
				'meta_keyword'=>$metatag,
				'meta_description'=>$metadescription,
				'description'=>$description,
				'tag'=>$tags,
				'price'=>$price,
				'product_filter'=>$fillterids,
				'quantity'=>$quantity,
				'minimum'=>$mquantity,
				'subtract'=>$subtractstock,
				'tax_class_id'=>$tax_class_id,
				'stock_status_id'=>$stockstatus,
				'shipping'=>$shipping,
				'keyword'=>$keyword,
				'length_class_id'=>$lengthclass,
				'length'=>$length,
				'width'=>$width,
				'height'=>$height,
				'weight'=>$weight,
				'weight_class_id'=>$weightclass,
				'status'=>$status,
				'sort_order'=>$sort_order,
				'attributes'=>$attributes,
				'discounts'=>$discounts,
				'point'=>$point,
				'product_store'=>$product_stores,
				'product_related'=>$product_related,
				'reviews'=>$reviews,
				'productdownloads'=>$productdownloads,
				);
				$extra=array();
				if(isset($cfileds))
				{
					foreach($cfileds as $cfiled)
					{
						if(!in_array($cfiled,$this->request->post))
						{	if(!empty($this->request->post[$cfiled]))
							{
							$extra[$cfiled]=$this->request->post[$cfiled];
							}
						}
					}
				}
				

				$product_id=$this->model_extension_tmdimportexportcombo_tmd_import->getproductbymodel($model);
				if(empty($product_id))
				{
					$this->model_extension_tmdimportexportcombo_tmd_import->addproduct($data1,$language_id,$extra);
					$totalnewproduct++;
				}
				else
				{
					$this->model_extension_tmdimportexportcombo_tmd_import->editproduct($data1,$product_id,$language_id,$extra);
					$totalupdateproduct++;
				}
				/* Step Product other  info collect */
				
				}
				}
				$i++;
				
				 $this->session->data['success']=$totalupdateproduct .' :: Total product update ' .$totalnewproduct. ':: Total New product added';
				
				////////////////////////// Started Import work  //////////////
				$this->response->redirect($this->url->link('extension/tmdimportexportcombo/tmd/import', 'user_token=' . $this->session->data['user_token']));
			}

			if ('csv' == $extension && $content && $this->request->post['format']=='csv')
			{
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\csv();
				$spreadsheet = $reader->load($_FILES['import']['tmp_name']);
				$spreadsheet->setActiveSheetIndex(0);
				$sheetDatas = $spreadsheet->getActiveSheet()->toArray(null,true,true,true);
				$i=0;
				/*
				@ arranging the data according to our need
				*/
				foreach($sheetDatas as $sheetData){
				if($i!=0)
				{
					
					$product_id=$sheetData['A'];
					$model=$sheetData['E'];
					if($importby==1)
					{
						$product_id=(string)$sheetData['A'];
					}
					else
					{
						$model=(string)$sheetData['E'];
						$product_id=$this->model_extension_tmdimportexportcombo_tmd_import->getproductbymodel($model);
					}
				
				if(isset($product_id) || isset($model))
				{
				
				/* stroers */
				$product_stores=array();
				$product_stores[]=0;
				$product_stornew=explode(';',(string)$sheetData['D']);
				if(isset($product_stornew))
				{
					foreach($product_stornew as $product_store)
					{
					if(!empty($product_store))
						{
							$product_stores[]=$product_store;
						}
					}
				}
				
				$product_stornew=explode(';',(string)$sheetData['C']);
				if(isset($product_stornew))
				{
					foreach($product_stornew as $product_store)
					{
					if(!empty($product_store))
						{
							 $product_store=$this->model_extension_tmdimportexportcombo_tmd_import->getstorebyname($product_store);
							$product_stores[]=$product_store;
						}
					}
				}
				
				$product_stores=array_unique($product_stores);
			
				/*  END Stores */
				
				/* Step Get category ids  */
				$catgoryname=(string)$sheetData['AL'];
				$catgorynames=explode(';',$catgoryname);
				$category_id=array();
				if(isset($catgorynames))
				{
					foreach($catgorynames as $category){
						$category=((array)$category);
						if(!empty($category))
						{
							$category_id[]=$this->model_extension_tmdimportexportcombo_tmd_import->category($category,0,$store_id,$language_id);
						}
					}
				}
				
				$catgoryname=$sheetData['AK'];
				$catgorynames=explode(';',(string)$catgoryname);
				
				if(isset($catgorynames))
				{
					foreach($catgorynames as $category)
					{
						$category=($category);
						if(!empty($category))
						{
							$category_id[]=$category;
						}
					}
				}
				
				$category_id=array_unique($category_id);
				/* Step Get category ids  */
				
				/* Step Get Barnd  ids  */
				$brandname=$sheetData['AJ'];
				if(!empty($brandname)) {
					$brandnames=explode(';',(string)$brandname);
				} else {
					$brandnames=array();
				}
				$brand_id='';
				if(isset($brandnames))
				{
					foreach($brandnames as $brand)
					{
						$brand=($brand);
						if(!empty($brand))
						{
							$brand_id=$this->model_extension_tmdimportexportcombo_tmd_import->barnd($brand,$store_id,$language_id);
						}
					}
				}
				
				$brandname=$sheetData['AI'];
				if(isset($brandname))
				{
						$brand_id=(string)$brandname;
				}
				
				/* Step Get Barnd  ids  */
				
				/* Step Get Options and value insert  */
				$productoptions=array();
				$options=(string)$sheetData['AO'];
				if(isset($options))
				{
				$options=explode(';',$options);
				
				if(isset($options))
				{
					foreach($options as $option)
					{
						$option=($option);
						if(!empty($option))
						{
							$this->model_extension_tmdimportexportcombo_tmd_import->option($option,$language_id);
						}
					}
				}
				}
				
				$options=$sheetData['AP'];
				if(!empty($options))
				{
				$options=explode(';',(string)$options);
				
				if(!empty($options))
				{
					foreach($options as $option)
					{
						$option=($option);
						if(!empty($option))
						{
							$productoptions[]=$this->model_extension_tmdimportexportcombo_tmd_import->optionvalue($option,$language_id);
						}
					}
				}
				}
				/* Step End Get Options and value insert  */
				
			
				/* Step Product Main Image  */
				$image=(string)$sheetData['Y'];
				if(!empty($image))
				{
				$mainimage=$this->model_extension_tmdimportexportcombo_tmd_import->imagesave($image);
				}
				else
				{
				$mainimage='';
				}
				
				/* Step End Product Main Image  */
				
				/* Step Start Product Filter Group  entry */
				if(isset($sheetData['AT']))
				{
				$filtergroup=$sheetData['AT'];
				if(!empty($filtergroup))
				{
					$filtergroups=explode(';',(string)$filtergroup);
					if(!empty($filtergroups))
					{
						foreach($filtergroups as $filtergroup)
						{
							$filtergroup=($filtergroup);
							if(!empty($filtergroup))
							{
								$this->model_extension_tmdimportexportcombo_tmd_import->filtergroup($filtergroup,$language_id);
							}
						}
					}
				}
				}
				/* Step Start Product Filter name  entry */
				$fillterids=array();
				if(isset($sheetData['AU']))
				{
				$filternames=(string)$sheetData['AU'];
				if(!empty($filternames))
				{
					$filternames=explode(';',(string)$filternames);
					if(!empty($filternames))
					{
						
						foreach($filternames as $filtername)
						{
							$filtername=($filtername);
							if(!empty($filtername))
							{
							$fillterids[]=$this->model_extension_tmdimportexportcombo_tmd_import->filtername((string)$filtername,$language_id);
							}
						}
					}
				}
				}
				
			
				
				/* Start Attribute work */
				$attributes=array();
				if(isset($sheetData['AV']))
				{
				$attributesname=(string)$sheetData['AV'];
				if(!empty($attributesname))
				{
					$attributess=explode(';',(string)$attributesname);
					if(!empty($attributess))
					{
						
						foreach($attributess as $attribute)
						{
							if(!empty($attribute))
							{
							$attinfo=$this->model_extension_tmdimportexportcombo_tmd_import->atributeallinfo($attribute,$language_id);
							$attributes[]=array(
							'attribute_id'=>$attinfo['attribute_id'],
							'text'=>$attinfo['text']
							);
							}
						}
					}
				}
				
				}
				
				/* End Attribute work */
				$discounts=array();
				if(isset($sheetData['AW']))
				{
					$discountinfo=(string)$sheetData['AW'];
					$discountinfos=explode(';',(string)$discountinfo);
					if(!empty($discountinfos))
					{
						foreach($discountinfos as $discount)
						{
							if(!empty($discount))
							{
							$info=explode(':',(string)$discount);

							$discounts[]=array(
							'customer_group_id'=>$info[0],
							'quantity'=>$info[1],
							'priority'=>$info[2],
							'price'=>$info[3],
							'date_start'=>$info[4],
							'date_end'=>$info[5]
							);
							}
						}
						
					}
				}
				
				/* Start Discount work */
				
				/* END Discount work */
				
				/* Reward point */
				$point='';
				if(!empty($sheetData['AX']))
				{
				$point=$sheetData['AX'];
				}
				
				/* Step Product Images  */
				$productimages=array();
				$images=(string)$sheetData['AQ'];
				if(!empty($images)) {
					$images=explode(';',(string)$images);
				} else {
					$images = array();
				}
				
				if(isset($images))
				{
					foreach($images as $image)
					{
					
						if(!empty($image))
						{
						$productimages[]=$this->model_extension_tmdimportexportcombo_tmd_import->imagesave($image);
						}
					}
				}
				
				/* Step End Product Images  */
				
				/* Step Product Speical price  */
				 $specialpricenew=(string)$sheetData['AR'];
				
				$specialprice=array();
				if(!empty($specialpricenew))
				{
				$specialpriceset=explode(';',(string)$specialpricenew);
				
				foreach($specialpriceset as $set)
					{
					if(!empty($set))
						{
						list($customer_group_id,$startdate,$enddate,$price)=explode(':',(string)$set);
						$specialprice[]=array(
								'price'=>$price,
								'priority'=>1,
								'customer_group_id'=>$customer_group_id,
								'date_start'=>$startdate,
								'date_end'=>$enddate
						);
					}
					}
				}
				
				/* Step End Product Speical price  */
				
				/* Step related products */
				 $relatedprodctinfo=(string)$sheetData['AN'];
				
				$product_related=array();
				if(!empty($relatedprodctinfo))
				{
				$relatedprodctinfos=explode(';',(string)$relatedprodctinfo);
				
				foreach($relatedprodctinfos as $relatedprodctinfo)
					{
					if(!empty($relatedprodctinfo))
						{
						$product_related[]=$this->model_extension_tmdimportexportcombo_tmd_import->getproductbymodel($relatedprodctinfo);
					}
					}
				}
				$relatedprodctinfo=(string)$sheetData['AM'];
				if(!empty($relatedprodctinfo))
				{
				$relatedprodctinfos=explode(';',(string)$relatedprodctinfo);
				
				foreach($relatedprodctinfos as $relatedprodctinfo)
					{
					if(!empty($relatedprodctinfo))
						{
						$product_related[]=$relatedprodctinfo;
					}
					}
				}
				$product_related=array_unique($product_related);
				/* Step End Product related  */
				/* Start Review  work */
				if(!isset($sheetData['BB']))
				{
					
					$sheetData['BB']='';
				}
				
				$productreview=($sheetData['BB']);
				$reviews='';
				if(!empty($productreview))
				{
						$productreviews=explode('|',(string)$productreview);
						if($productreviews){
						foreach($productreviews as $productreview)
						{
							$productreview=($productreview);
							if(!empty($productreview))
							{
								$productreview=explode('::',(string)$productreview);
                                
								$reviews[]=array(
								'customer_id'=>$productreview[0],
								'author'=>$productreview[1],
								'text'=>$productreview[2],
								'rating'=>$productreview[3],
								'status'=>$productreview[4],
								'date_added'=>$productreview[5],
								'date_modified'=>$productreview[6],
								);
							}
						}
				}
			}
				
				/* END Review  work /
				
				/* Start Product Download */
				$productdownloads=array();
				$downloadids=((string)$sheetData['BA']);
				if(!empty($downloadids))
				{
					$downloadids=explode(';',(string)$downloadids);
					foreach($downloadids as $downloadid)
					{
						if(isset($downloadid))
						{
						$productdownloads[]=$downloadid;
						}
					}
				}
				/* end Product Download */
				
				/* Step Product other  info collect */
				$model=$sheetData['E'];
				$sku=$sheetData['F'];
				$upc=$sheetData['G'];
				$ean=$sheetData['H'];
				$jan=$sheetData['I'];
				$isbn=$sheetData['J'];
				$mpn=$sheetData['K'];
				$location=$sheetData['L'];
				$productname=$sheetData['M'];
				$metadescription=$sheetData['N'];
				$metatag=$sheetData['O'];
				$description=$sheetData['P'];
				$tags=$sheetData['Q'];
				$price=$sheetData['R'];
				$quantity=$sheetData['S'];
				$mquantity=$sheetData['T'];
				$subtractstock=$sheetData['U'];
				$stockstatus=$sheetData['V'];
				$shipping=$sheetData['W'];
				$keyword=$sheetData['X'];
				$available=$sheetData['Z'];
				$lengthclass=$sheetData['AA'];
				$length=$sheetData['AB'];
				$width=$sheetData['AC'];
				$height=$sheetData['AD'];
				$weight=$sheetData['AE'];
				$weightclass=$sheetData['AF'];
				$status=$sheetData['AG'];
				$sort_order=$sheetData['AH'];
				$reviews=$reviews;
				if(isset($sheetData['AY']))
				{
					$meta_title=$sheetData['AY'];
				}
				else
				{
					$meta_title=$sheetData['M'];
				}
				if(isset($sheetData['AS']))
				{
				$tax_class_id=$sheetData['AS'];
				}
				else
				{
				$tax_class_id='';
				}
				
				$extra=array();
				if(isset($cfileds))
				{
					foreach($cfileds as $cfiled)
					{
						if(!in_array($cfiled,$this->request->post))
						{	if(!empty($sheetData[$this->request->post[$cfiled]]))
							{
							$extra[$cfiled]=$sheetData[$this->request->post[$cfiled]];
							}
						}
					}
				}
				
				$data='';
				$data=array(
				'product_category'=>$category_id,
				'manufacturer_id'=>$brand_id,
				'productoptions'=>$productoptions,
				'product_special'=>$specialprice,
				'image'=>$mainimage,
				'product_image'=>$productimages,
				'model'=>$model,
				'sku'=>$sku,
				'upc'=>$upc,
				'ean'=>$ean,
				'jan'=>$jan,
				'isbn'=>$isbn,
				'available'=>$available,
				'mpn'=>$mpn,
				'location'=>$location,
				'name'=>$productname,
				'meta_keyword'=>$metatag,
				'meta_description'=>$metadescription,
				'description'=>$description,
				'tag'=>$tags,
				'price'=>$price,
				'product_filter'=>$fillterids,
				'quantity'=>$quantity,
				'minimum'=>$mquantity,
				'subtract'=>$subtractstock,
				'tax_class_id'=>$tax_class_id,
				'stock_status_id'=>$stockstatus,
				'shipping'=>$shipping,
				'keyword'=>$keyword,
				'length_class_id'=>$lengthclass,
				'length'=>$length,
				'width'=>$width,
				'height'=>$height,
				'weight'=>$weight,
				'weight_class_id'=>$weightclass,
				'status'=>$status,
				'sort_order'=>$sort_order,
				'attributes'=>$attributes,
				'discounts'=>$discounts,
				'point'=>$point,
				'product_store'=>$product_stores,
				'product_related'=>$product_related,
				'meta_title'=>$meta_title,
				'reviews'=>$reviews,
				'productdownloads'=>$productdownloads,
				);
				
				
				if(empty($product_id))
				{
				$this->model_extension_tmdimportexportcombo_tmd_import->addproduct($data,$language_id,$extra);
				$totalnewproduct++;
				}
				else
				{
				$this->model_extension_tmdimportexportcombo_tmd_import->editproduct($data,$product_id,$language_id,$extra);
				$totalupdateproduct++;
				}
				/* Step Product other  info collect */
				
				}
				}
				$i++;
				}
				 $this->session->data['success']='Total product update : ' .$totalupdateproduct. ' <br /> Total New product added :'.$totalnewproduct;
			
				////////////////////////// Started Import work  //////////////
				$this->response->redirect($this->url->link('extension/tmdimportexportcombo/tmd/import', 'user_token=' . $this->session->data['user_token']));
					
				
			}
			else if ($content)
			{
				
				////////////////////////// Started Import work  //////////////
				if('xls' == $extension && $this->request->post['format']=='xls'){
					$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
				}
				else{
					$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
				}
				
				$spreadsheet = $reader->load($_FILES['import']['tmp_name']);
				$spreadsheet->setActiveSheetIndex(0);
				$sheetDatas = $spreadsheet->getActiveSheet()->toArray(null,true,true,true);
				$i=0;
				/*
				@ arranging the data according to our need
				*/
				foreach($sheetDatas as $sheetData){
				if($i!=0)
				{
					
					$product_id=$sheetData['A'];
					$model=$sheetData['E'];
					if($importby==1)
					{
						$product_id=$sheetData['A'];
					}
					else
					{
						$model=$sheetData['E'];
						$product_id=$this->model_extension_tmdimportexportcombo_tmd_import->getproductbymodel($model);
					}
					
				
				if(isset($product_id) || isset($model))
				{
				
				/* stroers */
				$product_stores=array();
				$product_stores[]=0;
				$product_stornew=explode(';',$sheetData['D']);
				if(isset($product_stornew))
				{
					foreach($product_stornew as $product_store)
					{
					if(!empty($product_store))
						{
							$product_stores[]=$product_store;
						}
					}
				}
				
				$product_stornew=explode(';',$sheetData['C']);
				if(isset($product_stornew))
				{
					foreach($product_stornew as $product_store)
					{
					if(!empty($product_store))
						{
							 $product_store=$this->model_extension_tmdimportexportcombo_tmd_import->getstorebyname($product_store);
							$product_stores[]=$product_store;
						}
					} 
				}
				$product_stores=array_unique($product_stores);
			
				/*  END Stores */
				
				/* Step Get category ids  */
				$catgoryname=$sheetData['AL'];
				$catgorynames=explode(';',(string)$catgoryname);
				$category_id=array();
				if(isset($catgorynames))
				{
					foreach($catgorynames as $category)
					{
						$category=($category);
						if(!empty($category))
						{
							$category_id[]=$this->model_extension_tmdimportexportcombo_tmd_import->category($category,0,$store_id,$language_id);
						}
					}
				}
				
				$catgoryname=$sheetData['AK'];
				$catgorynames=explode(';',(string)$catgoryname);
				
				if(isset($catgorynames))
				{
					foreach($catgorynames as $category)
					{
						$category=($category);
						if(!empty($category))
						{
							$category_id[]=$category;
						}
					}
				}
				
				$category_id=array_unique($category_id);
			
				/* Step Get category ids  */
				
				/* Step Get Barnd  ids  */
				$brandname=$sheetData['AJ'];
				$brandnames=explode(';',(string)$brandname);
				$brand_id='';
				if(isset($brandnames))
				{
					foreach($brandnames as $brand)
					{
						$brand=($brand);
						if(!empty($brand))
						{
							$brand_id=$this->model_extension_tmdimportexportcombo_tmd_import->barnd($brand,$store_id,$language_id);
						}
					}
				}
				
				$brandname=$sheetData['AI'];
				if(isset($brandname))
				{
						$brand_id=$brandname;
				}
				
				/* Step Get Barnd  ids  */
				
				/* Step Get Options and value insert  */
				$productoptions=array();
				$options=$sheetData['AO'];
				if(!empty($options)){
				$options=explode(';',$options);
				
				if(isset($options))
				{
					foreach($options as $option)
					{
						$option=($option);
						if(!empty($option))
						{
							$this->model_extension_tmdimportexportcombo_tmd_import->option($option,$language_id);
						}
					}
				}
				}
				
				$options=$sheetData['AP'];
				if(!empty($options)){
				$options=explode(';',$options);
				
				if(!empty($options))
				{
					foreach($options as $option)
					{
						$option=($option);
						if(!empty($option))
						{
							$productoptions[]=$this->model_extension_tmdimportexportcombo_tmd_import->optionvalue($option,$language_id);
						}
					}
				}
				}
				/* Step End Get Options and value insert  */
				
			
				/* Step Product Main Image  */
				$image=$sheetData['Y'];
				if(!empty($image))
				{
				$mainimage=$this->model_extension_tmdimportexportcombo_tmd_import->imagesave($image);
				}
				else
				{
				$mainimage='';
				}
				
				/* Step End Product Main Image  */
				
				/* Step Start Product Filter Group  entry */
				if(isset($sheetData['AT']))
				{
				$filtergroup=$sheetData['AT'];
				if(!empty($filtergroup))
				{
					$filtergroups=explode(';',$filtergroup);
					if(!empty($filtergroups))
					{
						foreach($filtergroups as $filtergroup)
						{
							$filtergroup=($filtergroup);
							if(!empty($filtergroup))
							{
								$this->model_extension_tmdimportexportcombo_tmd_import->filtergroup($filtergroup,$language_id);
							}
						}
					}
				}
				}
				/* Step Start Product Filter name  entry */
				$fillterids=array();
				if(isset($sheetData['AU']))
				{
				$filternames=$sheetData['AU'];
				if(!empty($filternames))
				{
					$filternames=explode(';',$filternames);
					if(!empty($filternames))
					{
						
						foreach($filternames as $filtername)
						{
							$filtername=($filtername);
							if(!empty($filtername))
							{
							$fillterids[]=$this->model_extension_tmdimportexportcombo_tmd_import->filtername($filtername,$language_id);
							}
						}
					}
				}
				}
				
			
				
				/* Start Attribute work */
				$attributes=array();
				if(isset($sheetData['AV']))
				{
				$attributesname=$sheetData['AV'];
				if(!empty($attributesname))
				{
					$attributess=explode(';',$attributesname);
					if(!empty($attributess))
					{
						
						foreach($attributess as $attribute)
						{
							if(!empty($attribute))
							{
							$attinfo=$this->model_extension_tmdimportexportcombo_tmd_import->atributeallinfo($attribute,$language_id);
							$attributes[]=array(
							'attribute_id'=>$attinfo['attribute_id'],
							'text'=>$attinfo['text']
							);
							}
						}
					}
				}
				
				}
				
				/* End Attribute work */
				$discounts=array();
				if(isset($sheetData['AW']))
				{
					$discountinfo=$sheetData['AW'];
					$discountinfos=explode(';',$discountinfo);
					if(!empty($discountinfos))
					{
						foreach($discountinfos as $discount)
						{
							if(!empty($discount))
							{
							$info=explode(':',$discount);
							$discounts[]=array(
							'customer_group_id'=>$info[0],
							'quantity'=>$info[1],
							'priority'=>$info[2],
							'price'=>$info[3],
							'date_start'=>$info[4],
							'date_end'=>$info[5]
							);
							}
						}
						
					}
				}
	
				/* Reward point */
				$point='';
				if(!empty($sheetData['AX']))
				{
				$point=$sheetData['AX'];
				}
				
				/* Step Product Images  */
				$productimages=array();
				$images=(string)$sheetData['AQ'];
				$images=explode(';',$images);
				
				if(isset($images))
				{
					foreach($images as $image)
					{
					
						if(!empty($image))
						{
						$productimages[]=$this->model_extension_tmdimportexportcombo_tmd_import->imagesave($image);
						}
					}
				}
				
				/* Step End Product Images  */
				
				/* Step Product Speical price  */
				 $specialpricenew=$sheetData['AR'];
				
				$specialprice=array();
				if(!empty($specialpricenew))
				{
				$specialpriceset=explode(';',$specialpricenew);
				
				foreach($specialpriceset as $set)
					{
					if(!empty($set))
						{
						list($customer_group_id,$startdate,$enddate,$price)=explode(':',$set);
						$specialprice[]=array(
								'price'=>$price,
								'priority'=>1,
								'customer_group_id'=>$customer_group_id,
								'date_start'=>$startdate,
								'date_end'=>$enddate
						);
					}
					}
				}
				
				/* Step End Product Speical price  */
				
				/* Step related products */
				 $relatedprodctinfo=$sheetData['AN'];
				
				$product_related=array();
				if(!empty($relatedprodctinfo))
				{
				$relatedprodctinfos=explode(';',$relatedprodctinfo);
				
				foreach($relatedprodctinfos as $relatedprodctinfo)
					{
					if(!empty($relatedprodctinfo))
						{
						$product_related[]=$this->model_extension_tmdimportexportcombo_tmd_import->getproductbymodel($relatedprodctinfo);
					}
					}
				}
				$relatedprodctinfo=$sheetData['AM'];
				if(!empty($relatedprodctinfo))
				{
				$relatedprodctinfos=explode(';',$relatedprodctinfo);
				
				foreach($relatedprodctinfos as $relatedprodctinfo)
					{
					if(!empty($relatedprodctinfo))
						{
						$product_related[]=$relatedprodctinfo;
					}
					}
				}
				$product_related=array_unique($product_related);
				/* Step End Product related  */
				/* Start Review  work */
				$reviews=array();
				$productreview=$sheetData['BB'];
				if(!empty($productreview))
				{
						$productreviews=explode('|',$productreview);
						foreach($productreviews as $productreview)
						{
							$productreview=($productreview);
							if(!empty($productreview))
							{
								$productreview=explode('::',$productreview);
								$reviews[]=array(
								'customer_id'=>$productreview[0],
								'author'=>$productreview[1],
								'text'=>$productreview[2],
								'rating'=>$productreview[3],
								'status'=>$productreview[4],
								'date_added'=>$productreview[5],
								'date_modified'=>$productreview[6],
								);
							}
						}
				}
				
				
				/* END Review  work /
				
				/* Start Product Download */
				$productdownloads=array();
				$downloadids=$sheetData['BA'];
				if(!empty($downloadids))
				{
					$downloadids=explode(';',$downloadids);
					foreach($downloadids as $downloadid)
					{
						if(isset($downloadid))
						{
						$productdownloads[]=$downloadid;
						}
					}
				}
				/* end Product Download */
				
				/* Step Product other  info collect */
				$model=$sheetData['E'];
				$sku=$sheetData['F'];
				$upc=$sheetData['G'];
				$ean=$sheetData['H'];
				$jan=$sheetData['I'];
				$isbn=$sheetData['J'];
				$mpn=$sheetData['K'];
				$location=$sheetData['L'];
				$productname=$sheetData['M'];
				$metadescription=$sheetData['N'];
				$metatag=$sheetData['O'];
				$description=$sheetData['P'];
				$tags=$sheetData['Q'];
				$price=$sheetData['R'];
				$quantity=$sheetData['S'];
				$mquantity=$sheetData['T'];
				$subtractstock=$sheetData['U'];
				$stockstatus=$sheetData['V'];
				$shipping=$sheetData['W'];
				$keyword=$sheetData['X'];
				$available=$sheetData['Z'];
				$lengthclass=$sheetData['AA'];
				$length=$sheetData['AB'];
				$width=$sheetData['AC'];
				$height=$sheetData['AD'];
				$weight=$sheetData['AE'];
				$weightclass=$sheetData['AF'];
				$status=$sheetData['AG'];
				$sort_order=$sheetData['AH'];
				$reviews=$reviews;
				if(isset($sheetData['AY']))
				{
					$meta_title=$sheetData['AY'];
				}
				else
				{
					$meta_title=$sheetData['M'];
				}
				if(isset($sheetData['AS']))
				{
				$tax_class_id=$sheetData['AS'];
				}
				else
				{
				$tax_class_id='';
				}
				
				$extra=array();
				if(isset($cfileds))
				{
					foreach($cfileds as $cfiled)
					{
						if(!in_array($cfiled,$this->request->post))
						{	if(!empty($sheetData[$this->request->post[$cfiled]]))
							{
							$extra[$cfiled]=$sheetData[$this->request->post[$cfiled]];
							}
						}
					}
				}
				
				$data='';
				$data=array(
				'product_category'=>$category_id,
				'manufacturer_id'=>$brand_id,
				'productoptions'=>$productoptions,
				'product_special'=>$specialprice,
				'image'=>$mainimage,
				'product_image'=>$productimages,
				'model'=>$model,
				'sku'=>$sku,
				'upc'=>$upc,
				'ean'=>$ean,
				'jan'=>$jan,
				'isbn'=>$isbn,
				'available'=>$available,
				'mpn'=>$mpn,
				'location'=>$location,
				'name'=>$productname,
				'meta_keyword'=>$metatag,
				'meta_description'=>$metadescription,
				'description'=>$description,
				'tag'=>$tags,
				'price'=>$price,
				'product_filter'=>$fillterids,
				'quantity'=>$quantity,
				'minimum'=>$mquantity,
				'subtract'=>$subtractstock,
				'tax_class_id'=>$tax_class_id,
				'stock_status_id'=>$stockstatus,
				'shipping'=>$shipping,
				'keyword'=>$keyword,
				'length_class_id'=>$lengthclass,
				'length'=>$length,
				'width'=>$width,
				'height'=>$height,
				'weight'=>$weight,
				'weight_class_id'=>$weightclass,
				'status'=>$status,
				'sort_order'=>$sort_order,
				'attributes'=>$attributes,
				'discounts'=>$discounts,
				'point'=>$point,
				'product_store'=>$product_stores,
				'product_related'=>$product_related,
				'meta_title'=>$meta_title,
				'reviews'=>$reviews,
				'productdownloads'=>$productdownloads,
				);
				
				
				if(empty($product_id)){
				$this->model_extension_tmdimportexportcombo_tmd_import->addproduct($data,$language_id,$extra);
				$totalnewproduct++;
				}else{
				$this->model_extension_tmdimportexportcombo_tmd_import->editproduct($data,$product_id,$language_id,$extra);
				$totalupdateproduct++;
				  }
				/* Step Product other  info collect */
				
				 }
				}
				$i++;
				}
				 $this->session->data['success']='Total product update : ' .$totalupdateproduct. ' <br /> Total New product added :'.$totalnewproduct;
			
				////////////////////////// Started Import work  //////////////
				$this->response->redirect($this->url->link('extension/tmdimportexportcombo/tmd/import', 'user_token=' . $this->session->data['user_token'], true));
			} 
			 else {
				$this->session->data['warning'] = $this->language->get('error_empty');
			}
			
			
			
		}

			
		$data['heading_title'] = $this->language->get('heading_title1');
	
			/////////// Stores
		$this->load->model('setting/store');
		$data['stores'] = $this->model_setting_store->getStores();
		/////////// Stores
		/////////// Stock status
		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();
		/////////// Stores
		
		if (isset($this->session->data['warning'])) {
			$data['error_warning'] = $this->session->data['warning'];
		
			unset($this->session->data['warning']);
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
		
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
  		$data['breadcrumbs'] = [];

   		$data['breadcrumbs'][] = [
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'])     		
      	];

   		$data['breadcrumbs'][] = [
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('extension/tmdimportexportcombo/tmd/import', 'user_token=' . $this->session->data['user_token'])
      	];
		
		$data['import'] = $this->url->link('extension/tmdimportexportcombo/tmd/import', 'user_token=' . $this->session->data['user_token']);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
				
		$this->response->setOutput($this->load->view('extension/tmdimportexportcombo/tmd/import', $data));
	}
	
	
}
?>