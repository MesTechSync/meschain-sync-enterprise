<?php
/**
 * Enhanced N11 Controller with Multi-User Support
 * Developer 1 Task: N11 Integration Completion
 */
require_once(DIR_APPLICATION . 'controller/extension/module/base_marketplace.php');

class ControllerExtensionModuleN11Enhanced extends ControllerExtensionModuleBaseMarketplace {
    
    public function __construct($registry) {
        parent::__construct($registry);
        $this->marketplace_name = 'n11';
    }
    
    /**
     * N11'e özgü dashboard verileri
     */
    protected function prepareMarketplaceData() {
        $user_id = $this->user->getId();
        $data = array();
        
        // Kullanıcı API ayarları
        $api_settings = $this->getUserApiSettings($user_id);
        foreach (array('app_key', 'app_secret') as $field) {
            $key = 'module_n11_' . $field;
            $data[$key] = isset($api_settings[$field]) ? $api_settings[$field] : '';
        }
        
        // N11'e özel URL'ler
        $data['category_mapping_url'] = $this->url->link('extension/module/n11_category', 'user_token=' . $this->session->data['user_token'], true);
        $data['variation_management_url'] = $this->url->link('extension/module/n11_enhanced/variation_management', 'user_token=' . $this->session->data['user_token'], true);
        $data['bulk_operations_url'] = $this->url->link('extension/module/n11_enhanced/bulk_operations', 'user_token=' . $this->session->data['user_token'], true);
        
        // Kullanıcıya özel istatistikler
        $data['user_statistics'] = $this->getUserN11Statistics($user_id);
        
        return $data;
    }
    
    /**
     * N11 için ürün verisi hazırlama (Geliştirilmiş)
     */
    protected function prepareProductForMarketplace($product) {
        $user_id = $this->user->getId();
        
        // Kategori mapping kontrolü
        $category_mapping = $this->getCategoryMapping($product['category_id']);
        if (!$category_mapping) {
            throw new Exception('Ürün kategorisi N11 ile eşleştirilmemiş: ' . $product['name']);
        }
        
        // Kullanıcının komisyon kuralları
        $commission_rules = $this->getUserCommissionRules($user_id, 'n11', $product);
        $final_price = $this->calculateFinalPrice($product['price'], $commission_rules);
        
        // N11 ürün formatı
        $n11_product = array(
            'productSellerCode' => $this->generateSellerCode($user_id, $product['model']),
            'title' => $this->sanitizeTitle($product['name']),
            'subtitle' => $this->generateSubtitle($product),
            'description' => $this->sanitizeDescription($product['description']),
            'category' => array(
                'id' => $category_mapping['n11_category_id']
            ),
            'price' => $final_price,
            'currencyType' => 'TL',
            'images' => $this->prepareImages($product),
            'stockItems' => $this->prepareStockItems($product, $user_id),
            'attributes' => $this->prepareAttributes($product, $category_mapping),
            'preparingDay' => $this->config->get('module_n11_preparing_day') ?: 1,
            'shipmentTemplate' => $this->config->get('module_n11_shipment_template') ?: 'FAST'
        );
        
        // SEO optimizasyonu
        if ($this->config->get('module_n11_seo_optimization')) {
            $n11_product = $this->applySeoOptimization($n11_product, $product);
        }
        
        return $n11_product;
    }
    
    /**
     * N11 siparişini OpenCart siparişine dönüştürme (Geliştirilmiş)
     */
    protected function importOrder($n11_order) {
        $user_id = $this->user->getId();
        
        // Sipariş zaten var mı kontrol et
        if ($this->orderExists($user_id, $n11_order['id'])) {
            return false;
        }
        
        // Dropshipping kontrolü
        $is_dropshipping = $this->isDropshippingOrder($user_id, $n11_order);
        
        try {
            if ($is_dropshipping) {
                $order_id = $this->processDropshippingOrder($user_id, $n11_order);
            } else {
                $order_id = $this->processRegularOrder($user_id, $n11_order);
            }
            
            // N11 sipariş eşleştirmesini kaydet
            $this->saveOrderMapping($user_id, $order_id, $n11_order);
            
            // Kullanıcı aktivitesini logla
            $this->logUserActivity($user_id, 'ORDER_IMPORT', 'N11', 'Sipariş import edildi: ' . $n11_order['orderNumber']);
            
            return true;
            
        } catch (Exception $e) {
            $this->log('ORDER_IMPORT_ERROR', 'User: ' . $user_id . ' - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Varyasyon yönetimi
     */
    public function variation_management() {
        $this->load->language('extension/module/n11');
        $this->document->setTitle('N11 Varyasyon Yönetimi');
        
        $user_id = $this->user->getId();
        $data = $this->prepareCommonData();
        
        // Varyasyonlu ürünleri getir
        $data['variation_products'] = $this->getVariationProducts($user_id);
        
        // N11 varyasyon şablonları
        $data['variation_templates'] = $this->getN11VariationTemplates();
        
        $this->renderView('n11_variation_management', $data);
    }
    
    /**
     * Toplu işlemler
     */
    public function bulk_operations() {
        $this->load->language('extension/module/n11');
        $this->document->setTitle('N11 Toplu İşlemler');
        
        $user_id = $this->user->getId();
        
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && isset($this->request->post['operation'])) {
            $this->processBulkOperation($user_id, $this->request->post);
        }
        
        $data = $this->prepareCommonData();
        
        // Toplu işlem seçenekleri
        $data['bulk_operations'] = array(
            'bulk_price_update' => 'Toplu Fiyat Güncelleme',
            'bulk_stock_update' => 'Toplu Stok Güncelleme',
            'bulk_status_update' => 'Toplu Durum Güncelleme',
            'bulk_category_change' => 'Toplu Kategori Değişimi',
            'bulk_delete' => 'Toplu Ürün Silme'
        );
        
        // Kullanıcının N11 ürünleri
        $data['user_products'] = $this->getUserN11Products($user_id);
        
        $this->renderView('n11_bulk_operations', $data);
    }
    
    /**
     * Otomatik senkronizasyon (Cron Job)
     */
    public function auto_sync() {
        $user_id = isset($this->request->get['user_id']) ? (int)$this->request->get['user_id'] : 0;
        
        if (!$user_id) {
            echo "User ID gerekli\n";
            return;
        }
        
        // Kullanıcının API ayarlarını kontrol et
        if (!$this->hasValidApiSettings($user_id)) {
            echo "User $user_id için geçersiz API ayarları\n";
            return;
        }
        
        try {
            // Otomatik sipariş çekme
            $new_orders = $this->autoImportOrders($user_id);
            echo "User $user_id: $new_orders yeni sipariş import edildi\n";
            
            // Otomatik stok güncelleme
            $updated_products = $this->autoUpdateStock($user_id);
            echo "User $user_id: $updated_products ürün stoğu güncellendi\n";
            
            // Otomatik fiyat güncelleme
            $price_updates = $this->autoUpdatePrices($user_id);
            echo "User $user_id: $price_updates ürün fiyatı güncellendi\n";
            
        } catch (Exception $e) {
            echo "User $user_id otomatik senkronizasyon hatası: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * API Helper başlatma
     */
    protected function initializeApiHelper($credentials) {
        require_once(DIR_SYSTEM . 'helper/n11_helper.php');
        $this->api_helper = new N11Helper($credentials['app_key'], $credentials['app_secret']);
    }
    
    /**
     * Kullanıcı API ayarları
     */
    private function getUserApiSettings($user_id) {
        $query = $this->db->query("
            SELECT api_data FROM " . DB_PREFIX . "user_api_settings 
            WHERE user_id = '" . (int)$user_id . "' AND marketplace = 'n11'
        ");
        
        if ($query->num_rows) {
            $api_data = json_decode($query->row['api_data'], true);
            
            // Şifrelenmiş verileri çöz
            $decrypted = array();
            foreach ($api_data as $key => $value) {
                $decrypted[$key] = SecurityHelper::decryptApiKey($value);
            }
            
            return $decrypted;
        }
        
        return array();
    }
    
    /**
     * Kullanıcı N11 istatistikleri
     */
    private function getUserN11Statistics($user_id) {
        $stats = array(
            'total_products' => 0,
            'active_products' => 0,
            'pending_products' => 0,
            'failed_products' => 0,
            'total_orders' => 0,
            'pending_orders' => 0,
            'completed_orders' => 0,
            'total_revenue' => 0,
            'commission_earned' => 0,
            'last_sync' => null
        );
        
        // Ürün istatistikleri
        $query = $this->db->query("
            SELECT 
                COUNT(*) as total_products,
                SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as active_products,
                SUM(CASE WHEN sync_status = 'pending' THEN 1 ELSE 0 END) as pending_products,
                SUM(CASE WHEN sync_status = 'failed' THEN 1 ELSE 0 END) as failed_products,
                MAX(last_updated) as last_sync
            FROM " . DB_PREFIX . "user_n11_products 
            WHERE user_id = '" . (int)$user_id . "'
        ");
        
        if ($query->num_rows) {
            $stats = array_merge($stats, $query->row);
        }
        
        // Sipariş istatistikleri
        $query = $this->db->query("
            SELECT 
                COUNT(*) as total_orders,
                SUM(CASE WHEN status IN ('New', 'Approved') THEN 1 ELSE 0 END) as pending_orders,
                SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed_orders,
                SUM(CASE WHEN status = 'Completed' THEN total ELSE 0 END) as total_revenue,
                SUM(CASE WHEN status = 'Completed' THEN commission ELSE 0 END) as commission_earned
            FROM " . DB_PREFIX . "user_n11_orders 
            WHERE user_id = '" . (int)$user_id . "'
        ");
        
        if ($query->num_rows) {
            $order_stats = $query->row;
            $stats['total_orders'] = $order_stats['total_orders'];
            $stats['pending_orders'] = $order_stats['pending_orders'];
            $stats['completed_orders'] = $order_stats['completed_orders'];
            $stats['total_revenue'] = $order_stats['total_revenue'];
            $stats['commission_earned'] = $order_stats['commission_earned'];
        }
        
        return $stats;
    }
    
    /**
     * Kullanıcı komisyon kuralları
     */
    private function getUserCommissionRules($user_id, $marketplace, $product) {
        $query = $this->db->query("
            SELECT * FROM " . DB_PREFIX . "marketplace_commission_rules 
            WHERE user_id = '" . (int)$user_id . "' 
            AND marketplace = '" . $this->db->escape($marketplace) . "'
            AND status = '1'
            AND (category_id IS NULL OR category_id = '" . (int)$product['category_id'] . "')
            AND (product_id IS NULL OR product_id = '" . (int)$product['product_id'] . "')
            AND (min_price IS NULL OR min_price <= '" . (float)$product['price'] . "')
            AND (max_price IS NULL OR max_price >= '" . (float)$product['price'] . "')
            ORDER BY priority DESC
            LIMIT 1
        ");
        
        return $query->num_rows ? $query->row : null;
    }
    
    /**
     * Final fiyat hesaplama
     */
    private function calculateFinalPrice($base_price, $commission_rules) {
        if (!$commission_rules) {
            return $base_price;
        }
        
        if ($commission_rules['commission_type'] == 'percentage') {
            return $base_price * (1 + ($commission_rules['commission_value'] / 100));
        } else {
            return $base_price + $commission_rules['commission_value'];
        }
    }
    
    /**
     * Satıcı kodu oluştur
     */
    private function generateSellerCode($user_id, $model) {
        return 'U' . $user_id . '_' . $model . '_' . time();
    }
    
    /**
     * Dropshipping sipariş kontrolü
     */
    private function isDropshippingOrder($user_id, $n11_order) {
        $query = $this->db->query("
            SELECT dropshipping_enabled FROM " . DB_PREFIX . "user_meschain_settings 
            WHERE user_id = '" . (int)$user_id . "'
        ");
        
        return $query->num_rows && $query->row['dropshipping_enabled'];
    }
    
    /**
     * Dropshipping sipariş işleme
     */
    private function processDropshippingOrder($user_id, $n11_order) {
        // Dropshipping tablosuna kaydet
        $this->db->query("
            INSERT INTO " . DB_PREFIX . "dropshipping_orders SET
                user_id = '" . (int)$user_id . "',
                marketplace = 'n11',
                marketplace_order_id = '" . $this->db->escape($n11_order['id']) . "',
                customer_name = '" . $this->db->escape($n11_order['buyerName']) . "',
                customer_email = '" . $this->db->escape($n11_order['buyerEmail']) . "',
                customer_phone = '" . $this->db->escape($n11_order['buyerPhone']) . "',
                shipping_address = '" . $this->db->escape(json_encode($n11_order['shippingAddress'])) . "',
                billing_address = '" . $this->db->escape(json_encode($n11_order['billingAddress'])) . "',
                products = '" . $this->db->escape(json_encode($n11_order['orderItemList'])) . "',
                total_amount = '" . (float)$n11_order['totalAmount'] . "',
                commission_rate = '" . (float)$this->getUserCommissionRate($user_id) . "',
                commission_amount = '" . (float)($n11_order['totalAmount'] * $this->getUserCommissionRate($user_id) / 100) . "',
                status = 'pending',
                created_date = NOW()
        ");
        
        return $this->db->getLastId();
    }
    
    /**
     * Sipariş var mı kontrolü (kullanıcı bazlı)
     */
    private function orderExists($user_id, $n11_order_id) {
        $query = $this->db->query("
            SELECT * FROM " . DB_PREFIX . "user_n11_orders 
            WHERE user_id = '" . (int)$user_id . "' 
            AND n11_order_id = '" . $this->db->escape($n11_order_id) . "'
        ");
        
        return $query->num_rows > 0;
    }
    
    /**
     * Kullanıcı aktivitesi logla
     */
    private function logUserActivity($user_id, $action, $module, $description) {
        $this->db->query("
            INSERT INTO " . DB_PREFIX . "user_activity_log SET
                user_id = '" . (int)$user_id . "',
                action = '" . $this->db->escape($action) . "',
                module = '" . $this->db->escape($module) . "',
                description = '" . $this->db->escape($description) . "',
                ip_address = '" . $this->db->escape($this->request->server['REMOTE_ADDR']) . "',
                user_agent = '" . $this->db->escape(substr($this->request->server['HTTP_USER_AGENT'], 0, 255)) . "',
                created_date = NOW()
        ");
    }
    
    /**
     * Otomatik sipariş import
     */
    private function autoImportOrders($user_id) {
        $api_settings = $this->getUserApiSettings($user_id);
        $this->initializeApiHelper($api_settings);
        
        // Son 24 saat içindeki siparişleri al
        $orders = $this->api_helper->getOrders('New', 0, 50, 
            date('Y-m-d H:i:s', strtotime('-24 hours')), 
            date('Y-m-d H:i:s')
        );
        
        $imported_count = 0;
        if ($orders && isset($orders['orderList']['order'])) {
            foreach ($orders['orderList']['order'] as $order) {
                if ($this->importOrder($order)) {
                    $imported_count++;
                }
            }
        }
        
        return $imported_count;
    }
    
    // Diğer yardımcı metodlar...
} 