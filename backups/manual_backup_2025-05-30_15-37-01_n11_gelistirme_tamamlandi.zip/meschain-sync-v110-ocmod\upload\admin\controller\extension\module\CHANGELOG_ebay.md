# CHANGELOG (ebay)

## 2025-05-29
- eBay modülü için OpenCart şablon dosyaları oluşturuldu.
- Loglama ve hata yönetimi standartları uygulandı. 