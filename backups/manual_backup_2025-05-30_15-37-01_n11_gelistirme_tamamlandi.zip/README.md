# MesChain-Sync: OpenCart Çoklu Pazaryeri Entegrasyon Sistemi

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![OpenCart](https://img.shields.io/badge/OpenCart-3.0.4.0-green.svg)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-purple.svg)
![License](https://img.shields.io/badge/license-Commercial-red.svg)

MesChain-Sync, OpenCart mağazanızı Türkiye ve dünya çapındaki önde gelen e-ticaret pazaryerleriyle entegre eden güçlü bir çoklu kanal yönetim sistemidir.

## 🚀 Özellikler

### ✅ Desteklenen Pazaryerleri

| Pazaryeri | Durum | Tamamlanma | Özellikler |
|-----------|--------|------------|------------|
| **Trendyol** | ✅ Aktif | %80 | Ürün, sipariş, stok senkronizasyonu + Webhook |
| **Ozon** | ✅ Aktif | %65 | Ürün, sipariş yönetimi |
| **N11** | 🚧 Geliştiriliyor | %30 | Temel entegrasyon |
| **Amazon** | 🚧 Geliştiriliyor | %15 | API bağlantısı |
| **Hepsiburada** | 🚧 Geliştiriliyor | %25 | Ürün senkronizasyonu |
| **eBay** | 📅 Planlanıyor | %0 | - |

### 🔧 Temel Özellikler

- **Merkezi Yönetim**: Tüm pazaryerlerini tek panelden yönetin
- **Otomatik Senkronizasyon**: Ürün, stok ve fiyat güncellemeleri
- **Sipariş Entegrasyonu**: Pazaryeri siparişlerini OpenCart'a aktarın
- **Webhook Desteği**: Gerçek zamanlı bildirimler (Trendyol)
- **Çoklu Dil**: Türkçe ve İngilizce arayüz
- **Detaylı Loglama**: Her işlem için ayrıntılı kayıt
- **Güvenli API İletişimi**: Şifrelenmiş bağlantılar

## 📋 Sistem Gereksinimleri

- OpenCart 3.0.4.0
- PHP 7.4 veya üzeri
- MySQL 5.7 veya üzeri
- cURL PHP eklentisi
- JSON PHP eklentisi
- ZIP PHP eklentisi (yedekleme için)

## 🛠️ Kurulum

1. **Dosyaları Yükleyin**
   ```bash
   upload/ klasörünün içeriğini OpenCart ana dizinine kopyalayın
   ```

2. **Yönetici Paneline Giriş**
   ```
   Admin Panel > Extensions > Modules
   ```

3. **Modülleri Kurun**
   - Her pazaryeri modülünü tek tek kurun
   - API bilgilerini girin
   - Durumu "Enabled" yapın

## 🔐 Güvenlik

- API anahtarları şifrelenmiş olarak saklanır
- Tüm API iletişimi HTTPS üzerinden yapılır
- Oturum güvenliği ve IP kontrolü
- Detaylı erişim logları

## 📁 Dizin Yapısı

```
MesChain-Sync/
├── upload/
│   ├── admin/
│   │   ├── controller/extension/module/  # Ana kontrolör dosyaları
│   │   │   ├── extension/module/        # Ana kontrolör dosyaları
│   │   │   └── language/                # Dil dosyaları
│   │   └── system/
│   │       └── library/
│   │           └── meschain/             # MesChain kütüphaneleri
│   │               ├── helper/            # Yardımcı sınıflar
│   │               ├── api/               # API bağlantı sınıfları
│   │               └── logger/            # Loglama sistemi
│   ├── backups/                              # Otomatik yedekler
│   ├── logs/                                 # Sistem logları
│   └── config/                               # Yapılandırma dosyaları
```

## 🔧 Yedekleme Sistemi

Proje, gelişmiş bir yedekleme sistemi ile birlikte gelir:

```powershell
# Manuel yedekleme
.\backup_system.ps1 -Action manual -Description "aciklama"

# Yedekleri listele
.\backup_system.ps1 -Action list

# Temizlik analizi
.\backup_system.ps1 -Action analyze
```

## 🧹 Temizlik ve Bakım

Proje, gereksiz dosyaları temizlemek için özel scriptler içerir:

```powershell
# Temizlik analizi (dry run)
.\cleanup_project.ps1 -DryRun

# Gerçek temizlik
.\cleanup_project.ps1 -Force
```

## 📊 Proje Durumu

### ✅ Tamamlanan İşlemler
- Trendyol entegrasyonu (%80)
- Webhook sistemi (Trendyol)
- Yedekleme sistemi
- Proje temizliği (39 gereksiz dosya silindi)
- Dizin reorganizasyonu
- Dokümantasyon güncellemesi

### 🚧 Devam Eden İşlemler
- N11 entegrasyonunun tamamlanması
- Amazon SP-API entegrasyonu
- Hepsiburada API bağlantısı
- Dropshipping modülü

### 📅 Planlanan Özellikler
- eBay REST API entegrasyonu
- Toplu ürün yükleme
- Gelişmiş raporlama
- Otomatik fiyat optimizasyonu
- Multi-tenant desteği

## 🤝 Destek

Teknik destek ve sorularınız için:
- 📧 Email: destek@meschain.com
- 📱 WhatsApp: +90 XXX XXX XX XX
- 🌐 Web: www.meschain.com

## 📄 Lisans

Bu yazılım ticari bir üründür. Lisans bilgileri için lütfen bizimle iletişime geçin.

---

**MesChain-Sync** - E-ticaret entegrasyonunda yeni standart 🚀 