<?php
/**
 * User Management Model
 * Developer 1: Database operations for multi-user system
 */
class ModelExtensionModuleUserManagement extends Model {
    
    /**
     * Install - Kullanıcı yönetimi tabloları oluştur
     */
    public function install() {
        // Multi-user tabloları oluştur
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "user_meschain_settings` (
              `user_id` INT(11) NOT NULL,
              `role` VARCHAR(32) NOT NULL DEFAULT 'user',
              `marketplace_access` TEXT,
              `dropshipping_enabled` TINYINT(1) NOT NULL DEFAULT '0',
              `commission_rate` DECIMAL(5,2) NOT NULL DEFAULT '0.00',
              `status` TINYINT(1) NOT NULL DEFAULT '1',
              `created_date` DATETIME NOT NULL,
              `updated_date` DATETIME DEFAULT NULL,
              `created_by` INT(11) NOT NULL,
              `updated_by` INT(11) DEFAULT NULL,
              PRIMARY KEY (`user_id`),
              KEY `role` (`role`),
              KEY `status` (`status`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");
        
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "user_api_settings` (
              `id` INT(11) NOT NULL AUTO_INCREMENT,
              `user_id` INT(11) NOT NULL,
              `marketplace` VARCHAR(32) NOT NULL,
              `api_data` TEXT NOT NULL,
              `status` TINYINT(1) NOT NULL DEFAULT '1',
              `created_date` DATETIME NOT NULL,
              `updated_date` DATETIME DEFAULT NULL,
              `last_sync` DATETIME DEFAULT NULL,
              PRIMARY KEY (`id`),
              UNIQUE KEY `user_marketplace` (`user_id`, `marketplace`),
              KEY `marketplace` (`marketplace`),
              KEY `status` (`status`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");
        
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "user_activity_log` (
              `log_id` INT(11) NOT NULL AUTO_INCREMENT,
              `user_id` INT(11) NOT NULL,
              `action` VARCHAR(64) NOT NULL,
              `module` VARCHAR(32) NOT NULL,
              `description` TEXT NOT NULL,
              `ip_address` VARCHAR(45) NOT NULL,
              `user_agent` TEXT,
              `data` TEXT,
              `created_date` DATETIME NOT NULL,
              PRIMARY KEY (`log_id`),
              KEY `user_id` (`user_id`),
              KEY `action` (`action`),
              KEY `module` (`module`),
              KEY `created_date` (`created_date`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");
        
        // Varsayılan süper admin rolü oluştur
        $this->createDefaultSuperAdmin();
    }
    
    /**
     * Uninstall - Tabloları kaldır
     */
    public function uninstall() {
        // Bu method kasıtlı olarak boş - veri kaybını önlemek için
        // DROP table işlemleri manuel yapılmalı
    }
    
    /**
     * Kullanıcı oluştur
     */
    public function createUser($data) {
        $this->db->query("
            INSERT INTO " . DB_PREFIX . "user_meschain_settings SET
                user_id = '" . (int)$data['user_id'] . "',
                role = '" . $this->db->escape($data['role']) . "',
                marketplace_access = '" . $this->db->escape(json_encode($data['marketplace_access'] ?? array())) . "',
                dropshipping_enabled = '" . (int)($data['dropshipping_enabled'] ?? 0) . "',
                commission_rate = '" . (float)($data['commission_rate'] ?? 0) . "',
                status = '" . (int)($data['status'] ?? 1) . "',
                created_date = NOW(),
                created_by = '" . (int)$data['created_by'] . "'
        ");
        
        return $data['user_id'];
    }
    
    /**
     * Kullanıcı güncelle
     */
    public function updateUser($user_id, $data) {
        $this->db->query("
            UPDATE " . DB_PREFIX . "user_meschain_settings SET
                role = '" . $this->db->escape($data['role']) . "',
                marketplace_access = '" . $this->db->escape(json_encode($data['marketplace_access'] ?? array())) . "',
                dropshipping_enabled = '" . (int)($data['dropshipping_enabled'] ?? 0) . "',
                commission_rate = '" . (float)($data['commission_rate'] ?? 0) . "',
                status = '" . (int)($data['status'] ?? 1) . "',
                updated_date = NOW(),
                updated_by = '" . (int)$data['updated_by'] . "'
            WHERE user_id = '" . (int)$user_id . "'
        ");
    }
    
    /**
     * Kullanıcı listesi
     */
    public function getUsers() {
        $query = $this->db->query("
            SELECT u.*, ums.role, ums.status as meschain_status, ums.created_date,
                   COUNT(DISTINCT uapi.marketplace) as marketplace_count,
                   MAX(uapi.last_sync) as last_sync
            FROM " . DB_PREFIX . "user u
            LEFT JOIN " . DB_PREFIX . "user_meschain_settings ums ON (u.user_id = ums.user_id)
            LEFT JOIN " . DB_PREFIX . "user_api_settings uapi ON (u.user_id = uapi.user_id)
            GROUP BY u.user_id
            ORDER BY u.user_id DESC
        ");
        
        return $query->rows;
    }
    
    /**
     * Kullanıcı bilgisi
     */
    public function getUser($user_id) {
        $query = $this->db->query("
            SELECT u.*, ums.*
            FROM " . DB_PREFIX . "user u
            LEFT JOIN " . DB_PREFIX . "user_meschain_settings ums ON (u.user_id = ums.user_id)
            WHERE u.user_id = '" . (int)$user_id . "'
        ");
        
        return $query->row;
    }
    
    /**
     * API ayarları kaydet
     */
    public function saveApiSettings($user_id, $marketplace, $api_data) {
        // Şifrelenmiş veri kaydet
        require_once(DIR_APPLICATION . 'controller/extension/module/security_helper.php');
        
        $encrypted_data = array();
        foreach ($api_data as $key => $value) {
            if (!empty($value)) {
                $encrypted_data[$key] = SecurityHelper::encryptApiKey($value);
            }
        }
        
        $this->db->query("
            INSERT INTO " . DB_PREFIX . "user_api_settings SET
                user_id = '" . (int)$user_id . "',
                marketplace = '" . $this->db->escape($marketplace) . "',
                api_data = '" . $this->db->escape(json_encode($encrypted_data)) . "',
                status = '1',
                created_date = NOW()
            ON DUPLICATE KEY UPDATE
                api_data = VALUES(api_data),
                updated_date = NOW()
        ");
    }
    
    /**
     * API ayarları al
     */
    public function getApiSettings($user_id, $marketplace = null) {
        $sql = "SELECT * FROM " . DB_PREFIX . "user_api_settings WHERE user_id = '" . (int)$user_id . "'";
        
        if ($marketplace) {
            $sql .= " AND marketplace = '" . $this->db->escape($marketplace) . "'";
        }
        
        $query = $this->db->query($sql);
        
        $settings = array();
        foreach ($query->rows as $row) {
            $api_data = json_decode($row['api_data'], true);
            
            // Şifrelenmiş verileri çöz
            $decrypted_data = array();
            foreach ($api_data as $key => $value) {
                $decrypted_data[$key] = SecurityHelper::decryptApiKey($value);
            }
            
            $settings[$row['marketplace']] = $decrypted_data;
        }
        
        return $marketplace ? ($settings[$marketplace] ?? array()) : $settings;
    }
    
    /**
     * Aktivite logla
     */
    public function logActivity($user_id, $action, $module, $description, $data = null) {
        $this->db->query("
            INSERT INTO " . DB_PREFIX . "user_activity_log SET
                user_id = '" . (int)$user_id . "',
                action = '" . $this->db->escape($action) . "',
                module = '" . $this->db->escape($module) . "',
                description = '" . $this->db->escape($description) . "',
                ip_address = '" . $this->db->escape($_SERVER['REMOTE_ADDR'] ?? '') . "',
                user_agent = '" . $this->db->escape(substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)) . "',
                data = '" . $this->db->escape(json_encode($data)) . "',
                created_date = NOW()
        ");
    }
    
    /**
     * Son aktiviteler
     */
    public function getRecentActivities($user_id, $limit = 10) {
        $query = $this->db->query("
            SELECT * FROM " . DB_PREFIX . "user_activity_log 
            WHERE user_id = '" . (int)$user_id . "'
            ORDER BY created_date DESC 
            LIMIT " . (int)$limit
        );
        
        return $query->rows;
    }
    
    /**
     * Varsayılan süper admin oluştur
     */
    private function createDefaultSuperAdmin() {
        // İlk kullanıcıyı süper admin yap
        $query = $this->db->query("SELECT user_id FROM " . DB_PREFIX . "user ORDER BY user_id ASC LIMIT 1");
        
        if ($query->num_rows) {
            $user_id = $query->row['user_id'];
            
            $this->db->query("
                INSERT IGNORE INTO " . DB_PREFIX . "user_meschain_settings SET
                    user_id = '" . (int)$user_id . "',
                    role = 'super_admin',
                    marketplace_access = '" . json_encode(array('n11', 'trendyol', 'amazon', 'ebay', 'hepsiburada', 'ozon')) . "',
                    dropshipping_enabled = '1',
                    commission_rate = '0.00',
                    status = '1',
                    created_date = NOW(),
                    created_by = '" . (int)$user_id . "'
            ");
        }
    }
} 