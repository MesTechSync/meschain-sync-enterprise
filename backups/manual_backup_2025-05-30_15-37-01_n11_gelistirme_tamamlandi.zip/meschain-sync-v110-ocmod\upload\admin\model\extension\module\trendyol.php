<?php
/**
 * trendyol.php (Model)
 *
 * Amaç: Trendyol modülünün veritabanı işlemlerini yöneten model dosyası.
 * Bu dosya sipariş yönetimi, ürün eşleştirme ve raporlama işlemleri için veritabanı fonksiyonlarını içerir.
 */
class ModelExtensionModuleTrendyol extends Model {
    /**
     * Sipariş ekler
     * 
     * @param array $data
     * @return int
     */
    public function addOrder($data) {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "trendyol_order` SET 
            order_id = '" . $this->db->escape($data['order_id']) . "', 
            order_number = '" . $this->db->escape($data['order_number']) . "', 
            status = '" . $this->db->escape($data['status']) . "', 
            total_price = '" . (float)$data['total_price'] . "', 
            shipping_cost = '" . (float)$data['shipping_cost'] . "', 
            customer_name = '" . $this->db->escape($data['customer_name']) . "', 
            customer_email = '" . $this->db->escape($data['customer_email']) . "', 
            customer_phone = '" . $this->db->escape($data['customer_phone']) . "', 
            shipping_address = '" . $this->db->escape($data['shipping_address']) . "', 
            shipping_city = '" . $this->db->escape($data['shipping_city']) . "', 
            shipping_district = '" . $this->db->escape($data['shipping_district']) . "', 
            date_added = '" . $this->db->escape($data['date_added']) . "', 
            data = '" . $this->db->escape($data['data']) . "'");
        
        return $this->db->getLastId();
    }
    
    /**
     * Sipariş ürünü ekler
     * 
     * @param array $data
     * @return int
     */
    public function addOrderProduct($data) {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "trendyol_order_product` SET 
            order_id = '" . $this->db->escape($data['order_id']) . "', 
            product_id = '" . $this->db->escape($data['product_id']) . "', 
            barcode = '" . $this->db->escape($data['barcode']) . "', 
            name = '" . $this->db->escape($data['name']) . "', 
            quantity = '" . (int)$data['quantity'] . "', 
            price = '" . (float)$data['price'] . "', 
            total = '" . (float)$data['total'] . "'");
        
        return $this->db->getLastId();
    }
    
    /**
     * Trendyol siparişi ile OpenCart siparişi arasında ilişki kurar
     * 
     * @param string $trendyol_order_id
     * @param int $opencart_order_id
     * @return void
     */
    public function addOrderRelation($trendyol_order_id, $opencart_order_id) {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "trendyol_order_relation` SET 
            trendyol_order_id = '" . $this->db->escape($trendyol_order_id) . "', 
            opencart_order_id = '" . (int)$opencart_order_id . "', 
            date_added = NOW()");
    }
    
    /**
     * Sipariş bilgilerini getirir
     * 
     * @param string $order_id
     * @return array
     */
    public function getOrder($order_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "trendyol_order` WHERE order_id = '" . $this->db->escape($order_id) . "'");
        
        return $query->row;
    }
    
    /**
     * Sipariş ürünlerini getirir
     * 
     * @param string $order_id
     * @return array
     */
    public function getOrderProducts($order_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "trendyol_order_product` WHERE order_id = '" . $this->db->escape($order_id) . "'");
        
        return $query->rows;
    }
    
    /**
     * Trendyol siparişinin OpenCart sipariş ID'sini getirir
     * 
     * @param string $trendyol_order_id
     * @return array
     */
    public function getOpenCartOrderId($trendyol_order_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "trendyol_order_relation` WHERE trendyol_order_id = '" . $this->db->escape($trendyol_order_id) . "'");
        
        return $query->row;
    }
    
    /**
     * Siparişleri filtreler ve listeler
     * 
     * @param array $data
     * @return array
     */
    public function getOrders($data = array()) {
        $sql = "SELECT * FROM `" . DB_PREFIX . "trendyol_order` o WHERE 1";
        
        if (!empty($data['filter_order_id'])) {
            $sql .= " AND o.order_id = '" . $this->db->escape($data['filter_order_id']) . "'";
        }
        
        if (!empty($data['filter_status'])) {
            $sql .= " AND o.status = '" . $this->db->escape($data['filter_status']) . "'";
        }
        
        if (isset($data['filter_convert_status'])) {
            if ($data['filter_convert_status'] == '1') {
                $sql .= " AND EXISTS (SELECT 1 FROM `" . DB_PREFIX . "trendyol_order_relation` r WHERE r.trendyol_order_id = o.order_id)";
            } elseif ($data['filter_convert_status'] == '0') {
                $sql .= " AND NOT EXISTS (SELECT 1 FROM `" . DB_PREFIX . "trendyol_order_relation` r WHERE r.trendyol_order_id = o.order_id)";
            }
        }
        
        if (!empty($data['filter_date_start'])) {
            $sql .= " AND DATE(o.date_added) >= '" . $this->db->escape($data['filter_date_start']) . "'";
        }
        
        if (!empty($data['filter_date_end'])) {
            $sql .= " AND DATE(o.date_added) <= '" . $this->db->escape($data['filter_date_end']) . "'";
        }
        
        $sort_data = array(
            'o.order_id',
            'o.customer_name',
            'o.total_price',
            'o.status',
            'o.date_added'
        );
        
        if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
            $sql .= " ORDER BY " . $data['sort'];
        } else {
            $sql .= " ORDER BY o.date_added";
        }
        
        if (isset($data['order']) && ($data['order'] == 'DESC')) {
            $sql .= " DESC";
        } else {
            $sql .= " ASC";
        }
        
        if (isset($data['start']) || isset($data['limit'])) {
            if ($data['start'] < 0) {
                $data['start'] = 0;
            }
            
            if ($data['limit'] < 1) {
                $data['limit'] = 20;
            }
            
            $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
        }
        
        $query = $this->db->query($sql);
        
        return $query->rows;
    }
    
    /**
     * Filtre kriterlerine göre sipariş sayısını getirir
     * 
     * @param array $data
     * @return int
     */
    public function getTotalOrders($data = array()) {
        $sql = "SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "trendyol_order` o WHERE 1";
        
        if (!empty($data['filter_order_id'])) {
            $sql .= " AND o.order_id = '" . $this->db->escape($data['filter_order_id']) . "'";
        }
        
        if (!empty($data['filter_status'])) {
            $sql .= " AND o.status = '" . $this->db->escape($data['filter_status']) . "'";
        }
        
        if (isset($data['filter_convert_status'])) {
            if ($data['filter_convert_status'] == '1') {
                $sql .= " AND EXISTS (SELECT 1 FROM `" . DB_PREFIX . "trendyol_order_relation` r WHERE r.trendyol_order_id = o.order_id)";
            } elseif ($data['filter_convert_status'] == '0') {
                $sql .= " AND NOT EXISTS (SELECT 1 FROM `" . DB_PREFIX . "trendyol_order_relation` r WHERE r.trendyol_order_id = o.order_id)";
            }
        }
        
        if (!empty($data['filter_date_start'])) {
            $sql .= " AND DATE(o.date_added) >= '" . $this->db->escape($data['filter_date_start']) . "'";
        }
        
        if (!empty($data['filter_date_end'])) {
            $sql .= " AND DATE(o.date_added) <= '" . $this->db->escape($data['filter_date_end']) . "'";
        }
        
        $query = $this->db->query($sql);
        
        return $query->row['total'];
    }
    
    /**
     * Gerekli veritabanı tablolarını kurar
     * 
     * @return void
     */
    public function install() {
        // Sipariş tablosu
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "trendyol_order` (
                `order_id` VARCHAR(64) NOT NULL,
                `order_number` VARCHAR(64) NOT NULL,
                `status` VARCHAR(32) NOT NULL,
                `total_price` DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
                `shipping_cost` DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
                `customer_name` VARCHAR(128) NOT NULL,
                `customer_email` VARCHAR(128) NOT NULL,
                `customer_phone` VARCHAR(32) NOT NULL,
                `shipping_address` TEXT NOT NULL,
                `shipping_city` VARCHAR(64) NOT NULL,
                `shipping_district` VARCHAR(64) NOT NULL,
                `date_added` DATETIME NOT NULL,
                `data` TEXT NOT NULL,
                PRIMARY KEY (`order_id`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");
        
        // Sipariş ürünleri tablosu
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "trendyol_order_product` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `order_id` VARCHAR(64) NOT NULL,
                `product_id` VARCHAR(64) NOT NULL,
                `barcode` VARCHAR(64) NOT NULL,
                `name` VARCHAR(255) NOT NULL,
                `quantity` INT(4) NOT NULL DEFAULT 0,
                `price` DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
                `total` DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
                PRIMARY KEY (`id`),
                KEY `order_id` (`order_id`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");
        
        // Sipariş ilişkileri tablosu
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "trendyol_order_relation` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `trendyol_order_id` VARCHAR(64) NOT NULL,
                `opencart_order_id` INT(11) NOT NULL,
                `date_added` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `trendyol_order_id` (`trendyol_order_id`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");
    }
    
    /**
     * Veritabanı tablolarını kaldırır
     * 
     * @return void
     */
    public function uninstall() {
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "trendyol_order`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "trendyol_order_product`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "trendyol_order_relation`");
    }
} 