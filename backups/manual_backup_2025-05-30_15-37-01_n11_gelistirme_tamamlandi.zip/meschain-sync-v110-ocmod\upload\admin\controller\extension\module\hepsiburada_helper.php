<?php
/**
 * hepsiburada_helper.php
 *
 * Amaç: Hepsiburada modülünde ürün gönderme, sipariş çekme gibi yardımcı fonksiyonları içerir.
 *
 * Loglama: Tüm önemli işlemler ve hatalar hepsiburada_helper.log dosyasına kaydedilmelidir.
 * Log formatı: [YYYY-MM-DD HH:MM:SS] [KULLANICI/ROL] [İŞLEM] [AÇIKLAMA]
 *
 * Hata yönetimi: Hatalar loglanmalı ve kullanıcıya açıklayıcı mesaj gösterilmelidir.
 */
// Hepsiburada'ya ürün gönderme, sipariş çekme gibi fonksiyonlar buraya yazılır

/**
 * API çağrısı yapar
 * @param string $url API URL
 * @param array $headers Headers
 * @param string $method HTTP methodu (GET, POST, PUT)
 * @param array $data Gönderilecek veri
 * @param int $retry_count Yeniden deneme sayısı
 * @return array|bool Yanıt veya başarısızlık durumunda false
 */
function hepsiburada_api_call($url, $headers, $method = 'GET', $data = null, $retry_count = 0) {
    $max_retries = 3;
    $timeout = 30; // 30 saniye timeout
    
    try {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        
        if ($method == 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        } else if ($method == 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        }
        
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_errno($ch);
        curl_close($ch);
        
        // Timeout veya bağlantı hatası
        if ($curl_error > 0) {
            hepsiburada_logla('SISTEM', 'API_HATA', 'API çağrısı hatası: ' . curl_strerror($curl_error) . ' (' . $curl_error . ')');
            
            // Yeniden deneme
            if ($retry_count < $max_retries) {
                hepsiburada_logla('SISTEM', 'API_RETRY', 'API çağrısı yeniden deneniyor. Deneme: ' . ($retry_count + 1));
                sleep(2); // 2 saniye bekle
                return hepsiburada_api_call($url, $headers, $method, $data, $retry_count + 1);
            }
            
            return false;
        }
        
        // HTTP 429: Too Many Requests - Rate limiting
        if ($httpcode == 429 && $retry_count < $max_retries) {
            hepsiburada_logla('SISTEM', 'API_RATE_LIMIT', 'API rate limit aşıldı. Yeniden deneniyor. Deneme: ' . ($retry_count + 1));
            sleep(5); // 5 saniye bekle
            return hepsiburada_api_call($url, $headers, $method, $data, $retry_count + 1);
        }
        
        // Başarılı yanıt
        if ($httpcode >= 200 && $httpcode < 300) {
            return [
                'status' => $httpcode,
                'data' => json_decode($response, true)
            ];
        } else {
            hepsiburada_logla('SISTEM', 'API_HTTP_HATA', 'HTTP hata kodu: ' . $httpcode . ' - ' . $response);
            return [
                'status' => $httpcode,
                'error' => $response
            ];
        }
    } catch (Exception $e) {
        hepsiburada_logla('SISTEM', 'API_EXCEPTION', 'API çağrısı exception: ' . $e->getMessage());
        return false;
    }
}

/**
 * Hepsiburada API'ye bağlantı kurar
 * @param string $api_key Hepsiburada API anahtarı
 * @param string $api_secret Hepsiburada API şifresi
 * @return bool Başarı durumu
 */
function hepsiburada_baglan($api_key, $api_secret) {
    $result = false;
    try {
        // API bağlantı testi
        $url = 'https://api.hepsiburada.com/api/authenticate';
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json'
        ];
        
        $data = [
            'username' => $api_key,
            'password' => $api_secret
        ];
        
        $response = hepsiburada_api_call($url, $headers, 'POST', $data);
        
        if ($response && isset($response['status']) && $response['status'] == 200) {
            $response_data = $response['data'];
            if (isset($response_data['accessToken'])) {
                $result = true;
                hepsiburada_logla('SISTEM', 'BAGLAN', 'Hepsiburada API bağlantısı başarılı.');
            } else {
                hepsiburada_logla('SISTEM', 'HATA', 'Token alınamadı.');
            }
        } else {
            hepsiburada_logla('SISTEM', 'HATA', 'Bağlantı hatası.');
        }
    } catch (Exception $e) {
        hepsiburada_logla('SISTEM', 'HATA', 'Bağlantı hatası: ' . $e->getMessage());
    }
    return $result;
}

/**
 * Hepsiburada API'den token alır
 * @param string $api_key Hepsiburada API anahtarı
 * @param string $api_secret Hepsiburada API şifresi
 * @return string|bool Token veya başarısızlık durumunda false
 */
function hepsiburada_get_token($api_key, $api_secret) {
    // Önce cache'e bakılır
    $cache_file = DIR_CACHE . 'hepsiburada_token.json';
    
    if (file_exists($cache_file)) {
        $token_data = json_decode(file_get_contents($cache_file), true);
        
        // Token geçerlilik süresi kontrolü (1 saat)
        if (isset($token_data['expires']) && $token_data['expires'] > time() && isset($token_data['token'])) {
            hepsiburada_logla('SISTEM', 'TOKEN_CACHE', 'Token cache\'den alındı.');
            return $token_data['token'];
        }
    }
    
    try {
        $url = 'https://api.hepsiburada.com/api/authenticate';
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json'
        ];
        
        $data = [
            'username' => $api_key,
            'password' => $api_secret
        ];
        
        $response = hepsiburada_api_call($url, $headers, 'POST', $data);
        
        if ($response && isset($response['status']) && $response['status'] == 200) {
            $response_data = $response['data'];
            if (isset($response_data['accessToken'])) {
                // Token cache'e kaydedilir
                $token_data = [
                    'token' => $response_data['accessToken'],
                    'expires' => time() + 3500 // 58 dakika (1 saat'ten biraz az)
                ];
                
                file_put_contents($cache_file, json_encode($token_data));
                
                hepsiburada_logla('SISTEM', 'TOKEN', 'Hepsiburada token başarıyla alındı ve cache\'lendi.');
                return $response_data['accessToken'];
            } else {
                hepsiburada_logla('SISTEM', 'HATA', 'Token alınamadı.');
            }
        } else {
            if (isset($response['status'])) {
                hepsiburada_logla('SISTEM', 'HATA', 'Token alma hatası: HTTP ' . $response['status']);
            } else {
                hepsiburada_logla('SISTEM', 'HATA', 'Token alma hatası: Bağlantı başarısız.');
            }
        }
    } catch (Exception $e) {
        hepsiburada_logla('SISTEM', 'HATA', 'Token alma hatası: ' . $e->getMessage());
    }
    return false;
}

/**
 * Hepsiburada'ya ürün gönderir
 * @param array $urun Ürün verisi
 * @param string $api_key Hepsiburada API anahtarı
 * @param string $api_secret Hepsiburada API şifresi
 * @param string $merchant_id Satıcı ID
 * @return bool Başarı durumu
 */
function hepsiburada_urun_gonder($urun, $api_key, $api_secret, $merchant_id) {
    try {
        $token = hepsiburada_get_token($api_key, $api_secret);
        if (!$token) {
            return false;
        }
        
        $url = 'https://api.hepsiburada.com/api/products';
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'Accept: application/json',
            'Merchant-Id: ' . $merchant_id
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($urun));
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200 || $httpcode == 201) {
            hepsiburada_logla('SISTEM', 'URUN_GONDER', 'Ürün başarıyla gönderildi: ' . $urun['ProductCode']);
            return true;
        } else {
            hepsiburada_logla('SISTEM', 'HATA', 'Ürün gönderme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return false;
        }
    } catch (Exception $e) {
        hepsiburada_logla('SISTEM', 'HATA', 'Ürün gönderme hatası: ' . $e->getMessage());
        return false;
    }
}

/**
 * Hepsiburada'dan sipariş çeker
 * @param string $tarih_baslangic Başlangıç tarihi
 * @param string $tarih_bitis Bitiş tarihi
 * @param string $api_key Hepsiburada API anahtarı
 * @param string $api_secret Hepsiburada API şifresi
 * @param string $merchant_id Satıcı ID
 * @return array Siparişler
 */
function hepsiburada_siparis_cek($tarih_baslangic, $tarih_bitis, $api_key, $api_secret, $merchant_id) {
    try {
        $token = hepsiburada_get_token($api_key, $api_secret);
        if (!$token) {
            return array();
        }
        
        $url = 'https://api.hepsiburada.com/api/orders';
        $url .= '?beginDate=' . urlencode($tarih_baslangic) . '&endDate=' . urlencode($tarih_bitis);
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'Accept: application/json',
            'Merchant-Id: ' . $merchant_id
        ];
        
        $response = hepsiburada_api_call($url, $headers, 'GET');
        
        if ($response && isset($response['status']) && $response['status'] == 200) {
            $siparisler = $response['data'];
            $count = isset($siparisler['orders']) ? count($siparisler['orders']) : 0;
            hepsiburada_logla('SISTEM', 'SIPARIS_CEK', 'Siparişler başarıyla çekildi: ' . $count . ' adet sipariş');
            return $siparisler;
        } else {
            if (isset($response['status'])) {
                hepsiburada_logla('SISTEM', 'HATA', 'Sipariş çekme hatası: HTTP ' . $response['status']);
            } else {
                hepsiburada_logla('SISTEM', 'HATA', 'Sipariş çekme hatası: Bağlantı başarısız.');
            }
            return array();
        }
    } catch (Exception $e) {
        hepsiburada_logla('SISTEM', 'HATA', 'Sipariş çekme hatası: ' . $e->getMessage());
        return array();
    }
}

/**
 * Hepsiburada'dan sipariş detayı çeker
 * @param string $siparis_no Sipariş numarası
 * @param string $api_key Hepsiburada API anahtarı
 * @param string $api_secret Hepsiburada API şifresi
 * @param string $merchant_id Satıcı ID
 * @return array Sipariş detayları
 */
function hepsiburada_siparis_detay($siparis_no, $api_key, $api_secret, $merchant_id) {
    try {
        $token = hepsiburada_get_token($api_key, $api_secret);
        if (!$token) {
            return array();
        }
        
        $url = 'https://api.hepsiburada.com/api/orders/' . $siparis_no;
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'Accept: application/json',
            'Merchant-Id: ' . $merchant_id
        ];
        
        $response = hepsiburada_api_call($url, $headers, 'GET');
        
        if ($response && isset($response['status']) && $response['status'] == 200) {
            $siparis = $response['data'];
            hepsiburada_logla('SISTEM', 'SIPARIS_DETAY', 'Sipariş detayı başarıyla çekildi: ' . $siparis_no);
            return $siparis;
        } else {
            if (isset($response['status'])) {
                hepsiburada_logla('SISTEM', 'HATA', 'Sipariş detayı çekme hatası: HTTP ' . $response['status']);
            } else {
                hepsiburada_logla('SISTEM', 'HATA', 'Sipariş detayı çekme hatası: Bağlantı başarısız.');
            }
            return array();
        }
    } catch (Exception $e) {
        hepsiburada_logla('SISTEM', 'HATA', 'Sipariş detayı çekme hatası: ' . $e->getMessage());
        return array();
    }
}

/**
 * Hepsiburada'da sipariş durumunu günceller
 * @param string $siparis_no Sipariş numarası
 * @param string $durum Yeni durum
 * @param string $api_key Hepsiburada API anahtarı
 * @param string $api_secret Hepsiburada API şifresi
 * @param string $merchant_id Satıcı ID
 * @return bool Başarı durumu
 */
function hepsiburada_siparis_durum_guncelle($siparis_no, $durum, $api_key, $api_secret, $merchant_id) {
    try {
        $token = hepsiburada_get_token($api_key, $api_secret);
        if (!$token) {
            return false;
        }
        
        $url = 'https://api.hepsiburada.com/api/orders/' . $siparis_no . '/status';
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'Accept: application/json',
            'Merchant-Id: ' . $merchant_id
        ];
        
        $data = [
            'status' => $durum
        ];
        
        $response = hepsiburada_api_call($url, $headers, 'PUT', $data);
        
        if ($response && isset($response['status']) && ($response['status'] == 200 || $response['status'] == 204)) {
            hepsiburada_logla('SISTEM', 'SIPARIS_DURUM', 'Sipariş durumu başarıyla güncellendi: ' . $siparis_no . ' -> ' . $durum);
            return true;
        } else {
            if (isset($response['status'])) {
                hepsiburada_logla('SISTEM', 'HATA', 'Sipariş durumu güncelleme hatası: HTTP ' . $response['status']);
            } else {
                hepsiburada_logla('SISTEM', 'HATA', 'Sipariş durumu güncelleme hatası: Bağlantı başarısız.');
            }
            return false;
        }
    } catch (Exception $e) {
        hepsiburada_logla('SISTEM', 'HATA', 'Sipariş durumu güncelleme hatası: ' . $e->getMessage());
        return false;
    }
}

/**
 * Stok güncelleme fonksiyonu
 * @param array $stok_bilgisi Stok bilgisi (productCode, quantity)
 * @param string $api_key Hepsiburada API anahtarı
 * @param string $api_secret Hepsiburada API şifresi
 * @param string $merchant_id Satıcı ID
 * @return bool Başarı durumu
 */
function hepsiburada_stok_guncelle($stok_bilgisi, $api_key, $api_secret, $merchant_id) {
    try {
        $token = hepsiburada_get_token($api_key, $api_secret);
        if (!$token) {
            return false;
        }
        
        $url = 'https://api.hepsiburada.com/api/products/inventory';
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'Accept: application/json',
            'Merchant-Id: ' . $merchant_id
        ];
        
        $response = hepsiburada_api_call($url, $headers, 'POST', $stok_bilgisi);
        
        if ($response && isset($response['status']) && ($response['status'] == 200 || $response['status'] == 201 || $response['status'] == 204)) {
            hepsiburada_logla('SISTEM', 'STOK_GUNCELLE', 'Stok başarıyla güncellendi: ' . $stok_bilgisi['productCode']);
            return true;
        } else {
            if (isset($response['status'])) {
                hepsiburada_logla('SISTEM', 'HATA', 'Stok güncelleme hatası: HTTP ' . $response['status']);
            } else {
                hepsiburada_logla('SISTEM', 'HATA', 'Stok güncelleme hatası: Bağlantı başarısız.');
            }
            return false;
        }
    } catch (Exception $e) {
        hepsiburada_logla('SISTEM', 'HATA', 'Stok güncelleme hatası: ' . $e->getMessage());
        return false;
    }
}

/**
 * Fiyat güncelleme fonksiyonu
 * @param array $fiyat_bilgisi Fiyat bilgisi (productCode, price, discountedPrice)
 * @param string $api_key Hepsiburada API anahtarı
 * @param string $api_secret Hepsiburada API şifresi
 * @param string $merchant_id Satıcı ID
 * @return bool Başarı durumu
 */
function hepsiburada_fiyat_guncelle($fiyat_bilgisi, $api_key, $api_secret, $merchant_id) {
    try {
        $token = hepsiburada_get_token($api_key, $api_secret);
        if (!$token) {
            return false;
        }
        
        $url = 'https://api.hepsiburada.com/api/products/pricing';
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'Accept: application/json',
            'Merchant-Id: ' . $merchant_id
        ];
        
        $response = hepsiburada_api_call($url, $headers, 'POST', $fiyat_bilgisi);
        
        if ($response && isset($response['status']) && ($response['status'] == 200 || $response['status'] == 201 || $response['status'] == 204)) {
            hepsiburada_logla('SISTEM', 'FIYAT_GUNCELLE', 'Fiyat başarıyla güncellendi: ' . $fiyat_bilgisi['productCode']);
            return true;
        } else {
            if (isset($response['status'])) {
                hepsiburada_logla('SISTEM', 'HATA', 'Fiyat güncelleme hatası: HTTP ' . $response['status']);
            } else {
                hepsiburada_logla('SISTEM', 'HATA', 'Fiyat güncelleme hatası: Bağlantı başarısız.');
            }
            return false;
        }
    } catch (Exception $e) {
        hepsiburada_logla('SISTEM', 'HATA', 'Fiyat güncelleme hatası: ' . $e->getMessage());
        return false;
    }
}

/**
 * Hepsiburada'dan kategorileri çeker
 * @param string $api_key Hepsiburada API anahtarı
 * @param string $api_secret Hepsiburada API şifresi
 * @param string $merchant_id Satıcı ID
 * @return array Kategoriler
 */
function hepsiburada_kategoriler_cek($api_key, $api_secret, $merchant_id) {
    try {
        $token = hepsiburada_get_token($api_key, $api_secret);
        if (!$token) {
            return array();
        }
        
        $url = 'https://api.hepsiburada.com/api/categories';
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'Accept: application/json',
            'Merchant-Id: ' . $merchant_id
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            $kategoriler = json_decode($response, true);
            hepsiburada_logla('SISTEM', 'KATEGORILER', 'Kategoriler başarıyla çekildi.');
            return $kategoriler;
        } else {
            hepsiburada_logla('SISTEM', 'HATA', 'Kategoriler çekilemedi: HTTP ' . $httpcode . ' - ' . $response);
            return array();
        }
    } catch (Exception $e) {
        hepsiburada_logla('SISTEM', 'HATA', 'Kategoriler çekilemedi: ' . $e->getMessage());
        return array();
    }
}

/**
 * Hepsiburada'dan markaları çeker
 * @param string $api_key Hepsiburada API anahtarı
 * @param string $api_secret Hepsiburada API şifresi
 * @param string $merchant_id Satıcı ID
 * @return array Markalar
 */
function hepsiburada_markalar_cek($api_key, $api_secret, $merchant_id) {
    try {
        $token = hepsiburada_get_token($api_key, $api_secret);
        if (!$token) {
            return array();
        }
        
        $url = 'https://api.hepsiburada.com/api/brands';
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'Accept: application/json',
            'Merchant-Id: ' . $merchant_id
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            $markalar = json_decode($response, true);
            hepsiburada_logla('SISTEM', 'MARKALAR', 'Markalar başarıyla çekildi.');
            return $markalar;
        } else {
            hepsiburada_logla('SISTEM', 'HATA', 'Markalar çekilemedi: HTTP ' . $httpcode . ' - ' . $response);
            return array();
        }
    } catch (Exception $e) {
        hepsiburada_logla('SISTEM', 'HATA', 'Markalar çekilemedi: ' . $e->getMessage());
        return array();
    }
}

/**
 * Loglama fonksiyonu
 * @param string $user Kullanıcı
 * @param string $action İşlem
 * @param string $message Mesaj
 */
function hepsiburada_logla($user, $action, $message) {
    $log_file = DIR_LOGS . 'hepsiburada_helper.log';
    $date = date('Y-m-d H:i:s');
    $log = "[$date] [$user] [$action] $message\n";
    file_put_contents($log_file, $log, FILE_APPEND);
}

/**
 * Ürünü Hepsiburada formatına dönüştürür
 * @param array $opencart_urun OpenCart ürün verisi
 * @return array Hepsiburada ürün verisi
 */
function hepsiburada_urun_formatla($opencart_urun) {
    // Ürün formatını HB API'ye uygun hale getir
    $hb_urun = array(
        'ProductCode' => $opencart_urun['model'],
        'ProductName' => $opencart_urun['name'],
        'Description' => $opencart_urun['description'],
        'BrandId' => $opencart_urun['manufacturer_id'],
        'CategoryId' => $opencart_urun['category_id'],
        'Price' => $opencart_urun['price'],
        'StockCount' => $opencart_urun['quantity'],
        'Images' => array()
    );
    
    // Ürün resimleri
    if (!empty($opencart_urun['image'])) {
        $hb_urun['Images'][] = array(
            'Url' => HTTP_CATALOG . 'image/' . $opencart_urun['image']
        );
    }
    
    if (!empty($opencart_urun['product_images'])) {
        foreach ($opencart_urun['product_images'] as $image) {
            $hb_urun['Images'][] = array(
                'Url' => HTTP_CATALOG . 'image/' . $image['image']
            );
        }
    }
    
    return $hb_urun;
}

/**
 * OpenCart ürün verilerini Hepsiburada formatına dönüştürür
 * @param array $opencart_urunler OpenCart ürün verileri
 * @return array Hepsiburada ürün verileri
 */
function hepsiburada_urunleri_formatla($opencart_urunler) {
    $hb_urunler = array();
    
    foreach ($opencart_urunler as $opencart_urun) {
        $hb_urunler[] = hepsiburada_urun_formatla($opencart_urun);
    }
    
    return $hb_urunler;
}

/**
 * Hepsiburada Yardımcı Sınıfı
 */
class HepsiburadaHelper {
    /**
     * Hepsiburada'dan siparişleri çeker
     * @param array $settings Ayarlar
     * @param array $params Parametreler
     * @return array Siparişler
     */
    public static function getOrders($settings, $params = []) {
        $username = $settings['username'];
        $password = $settings['password'];
        $merchant_id = $settings['merchant_id'];
        
        $tarih_baslangic = isset($params['date_start']) ? $params['date_start'] : date('Y-m-d', strtotime('-7 days'));
        $tarih_bitis = isset($params['date_end']) ? $params['date_end'] : date('Y-m-d');
        
        return hepsiburada_siparis_cek($tarih_baslangic, $tarih_bitis, $username, $password, $merchant_id);
    }
    
    /**
     * Hepsiburada'dan sipariş detayı çeker
     * @param array $settings Ayarlar
     * @param string $order_id Sipariş ID
     * @return array Sipariş detayı
     */
    public static function getOrderDetail($settings, $order_id) {
        $username = $settings['username'];
        $password = $settings['password'];
        $merchant_id = $settings['merchant_id'];
        
        return hepsiburada_siparis_detay($order_id, $username, $password, $merchant_id);
    }
    
    /**
     * Hepsiburada'dan ürünleri çeker
     * @param array $settings Ayarlar
     * @return array Ürünler
     */
    public static function getProducts($settings) {
        // Bu fonksiyon geliştirilecek
        // Şu an için boş dizi dönüyor
        return array();
    }
    
    /**
     * Hepsiburada'ya ürün gönderir
     * @param array $settings Ayarlar
     * @param array $product Ürün
     * @return bool Başarı durumu
     */
    public static function sendProduct($settings, $product) {
        $username = $settings['username'];
        $password = $settings['password'];
        $merchant_id = $settings['merchant_id'];
        
        $hb_product = hepsiburada_urun_formatla($product);
        
        return hepsiburada_urun_gonder($hb_product, $username, $password, $merchant_id);
    }
    
    /**
     * Stok günceller
     * @param array $settings Ayarlar
     * @param array $inventory Stok bilgisi
     * @return bool Başarı durumu
     */
    public static function updateInventory($settings, $inventory) {
        $username = $settings['username'];
        $password = $settings['password'];
        $merchant_id = $settings['merchant_id'];
        
        return hepsiburada_stok_guncelle($inventory, $username, $password, $merchant_id);
    }
    
    /**
     * Fiyat günceller
     * @param array $settings Ayarlar
     * @param array $pricing Fiyat bilgisi
     * @return bool Başarı durumu
     */
    public static function updatePricing($settings, $pricing) {
        $username = $settings['username'];
        $password = $settings['password'];
        $merchant_id = $settings['merchant_id'];
        
        return hepsiburada_fiyat_guncelle($pricing, $username, $password, $merchant_id);
    }
    
    /**
     * Loglama
     * @param string $user Kullanıcı
     * @param string $action İşlem
     * @param string $message Mesaj
     */
    public static function writeLog($user, $action, $message) {
        hepsiburada_logla($user, $action, $message);
    }
    
    /**
     * Kategorileri çeker
     * @param array $settings Ayarlar
     * @return array Kategoriler
     */
    public static function getCategories($settings) {
        $username = $settings['username'];
        $password = $settings['password'];
        $merchant_id = $settings['merchant_id'];
        
        return hepsiburada_kategoriler_cek($username, $password, $merchant_id);
    }
    
    /**
     * Markaları çeker
     * @param array $settings Ayarlar
     * @return array Markalar
     */
    public static function getBrands($settings) {
        $username = $settings['username'];
        $password = $settings['password'];
        $merchant_id = $settings['merchant_id'];
        
        return hepsiburada_markalar_cek($username, $password, $merchant_id);
    }
    
    /**
     * Sipariş durumunu günceller
     * @param array $settings Ayarlar
     * @param string $order_id Sipariş ID
     * @param string $status Durum
     * @return bool Başarı durumu
     */
    public static function updateOrderStatus($settings, $order_id, $status) {
        $username = $settings['username'];
        $password = $settings['password'];
        $merchant_id = $settings['merchant_id'];
        
        return hepsiburada_siparis_durum_guncelle($order_id, $status, $username, $password, $merchant_id);
    }
} 