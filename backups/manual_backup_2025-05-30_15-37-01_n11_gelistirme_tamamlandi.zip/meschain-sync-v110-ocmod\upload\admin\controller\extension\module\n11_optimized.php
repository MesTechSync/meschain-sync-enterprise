<?php
require_once(DIR_APPLICATION . 'controller/extension/module/base_marketplace.php');

/**
 * N11 Controller - Optimized Version
 * Base Marketplace Controller'ı extend eder
 */
class ControllerExtensionModuleN11Optimized extends ControllerExtensionModuleBaseMarketplace {
    
    public function __construct($registry) {
        parent::__construct($registry);
        $this->marketplace_name = 'n11';
    }
    
    /**
     * N11'e özgü veri hazırlama
     */
    protected function prepareMarketplaceData() {
        $data = array();
        
        // N11 API ayarları
        $api_fields = array('app_key', 'app_secret');
        foreach ($api_fields as $field) {
            $key = 'module_n11_' . $field;
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $this->config->get($key);
            }
        }
        
        // N11'e özel URL'ler
        $data['category_mapping_url'] = $this->url->link('extension/module/n11_category', 'user_token=' . $this->session->data['user_token'], true);
        
        return $data;
    }
    
    /**
     * N11 için ürün verisi hazırlama
     */
    protected function prepareProductForMarketplace($product) {
        // Kategori mapping kontrolü
        $category_mapping = $this->getCategoryMapping($product['category_id']);
        if (!$category_mapping) {
            throw new Exception('Ürün kategorisi N11 ile eşleştirilmemiş: ' . $product['name']);
        }
        
        // N11 ürün formatı
        return array(
            'productSellerCode' => $product['model'],
            'title' => $this->sanitizeTitle($product['name']),
            'subtitle' => substr($product['name'], 0, 50),
            'description' => $this->sanitizeDescription($product['description']),
            'category' => array(
                'id' => $category_mapping['n11_category_id']
            ),
            'price' => $this->calculatePrice($product['price']),
            'currencyType' => 'TL',
            'images' => $this->prepareImages($product),
            'stockItems' => $this->prepareStockItems($product),
            'attributes' => $this->prepareAttributes($product, $category_mapping)
        );
    }
    
    /**
     * N11 siparişini OpenCart siparişine dönüştürme
     */
    protected function importOrder($n11_order) {
        // Sipariş zaten var mı kontrol et
        if ($this->orderExists($n11_order['id'])) {
            return false;
        }
        
        $this->load->model('checkout/order');
        
        // Müşteri bilgileri
        $customer_data = $this->prepareCustomerData($n11_order);
        $customer_id = $this->createOrGetCustomer($customer_data);
        
        // Sipariş verisi
        $order_data = array(
            'invoice_prefix' => 'N11-',
            'store_id' => $this->config->get('config_store_id'),
            'store_name' => $this->config->get('config_name'),
            'store_url' => HTTP_CATALOG,
            'customer_id' => $customer_id,
            'customer_group_id' => $this->config->get('config_customer_group_id'),
            'firstname' => $customer_data['firstname'],
            'lastname' => $customer_data['lastname'],
            'email' => $customer_data['email'],
            'telephone' => $customer_data['telephone'],
            'custom_field' => array(),
            'payment_firstname' => $customer_data['firstname'],
            'payment_lastname' => $customer_data['lastname'],
            'payment_company' => '',
            'payment_address_1' => $n11_order['billingAddress']['address'],
            'payment_address_2' => '',
            'payment_city' => $n11_order['billingAddress']['city'],
            'payment_postcode' => $n11_order['billingAddress']['postalCode'],
            'payment_country' => 'Türkiye',
            'payment_country_id' => 215,
            'payment_zone' => $n11_order['billingAddress']['city'],
            'payment_zone_id' => $this->getZoneId($n11_order['billingAddress']['city']),
            'payment_address_format' => '',
            'payment_custom_field' => array(),
            'payment_method' => 'N11 Ödeme',
            'payment_code' => 'n11_payment',
            'shipping_firstname' => $customer_data['firstname'],
            'shipping_lastname' => $customer_data['lastname'],
            'shipping_company' => '',
            'shipping_address_1' => $n11_order['shippingAddress']['address'],
            'shipping_address_2' => '',
            'shipping_city' => $n11_order['shippingAddress']['city'],
            'shipping_postcode' => $n11_order['shippingAddress']['postalCode'],
            'shipping_country' => 'Türkiye',
            'shipping_country_id' => 215,
            'shipping_zone' => $n11_order['shippingAddress']['city'],
            'shipping_zone_id' => $this->getZoneId($n11_order['shippingAddress']['city']),
            'shipping_address_format' => '',
            'shipping_custom_field' => array(),
            'shipping_method' => $n11_order['shipmentCompanyName'],
            'shipping_code' => 'n11_shipping',
            'comment' => 'N11 Sipariş No: ' . $n11_order['orderNumber'],
            'total' => $n11_order['totalAmount'],
            'order_status_id' => $this->mapOrderStatus($n11_order['status']),
            'affiliate_id' => 0,
            'commission' => 0,
            'marketing_id' => 0,
            'tracking' => '',
            'language_id' => $this->config->get('config_language_id'),
            'currency_id' => $this->config->get('config_currency_id'),
            'currency_code' => 'TRY',
            'currency_value' => 1.0,
            'ip' => '',
            'forwarded_ip' => '',
            'user_agent' => 'N11 API',
            'accept_language' => 'tr-TR',
            'products' => $this->prepareOrderProducts($n11_order['orderItemList']),
            'totals' => $this->prepareOrderTotals($n11_order)
        );
        
        // Siparişi oluştur
        $order_id = $this->model_checkout_order->addOrder($order_data);
        
        // N11 sipariş eşleştirmesini kaydet
        $this->saveOrderMapping($order_id, $n11_order);
        
        return true;
    }
    
    /**
     * API Helper başlatma
     */
    protected function initializeApiHelper($credentials) {
        require_once(DIR_SYSTEM . 'helper/n11_helper.php');
        $this->api_helper = new N11Helper($credentials['app_key'], $credentials['app_secret']);
    }
    
    /**
     * API kimlik bilgileri anahtarları
     */
    protected function getApiKeys() {
        return array('app_key', 'app_secret');
    }
    
    /**
     * İstatistikleri getir
     */
    protected function getStatistics() {
        $stats = parent::getStatistics();
        
        try {
            // N11'den gerçek verileri çek
            $credentials = $this->getApiCredentials();
            if ($credentials) {
                $this->initializeApiHelper($credentials);
                
                // Ürün sayısı
                $products = $this->api_helper->getProducts(0, 1);
                if ($products && isset($products['pagingData']['totalCount'])) {
                    $stats['total_products'] = $products['pagingData']['totalCount'];
                }
                
                // Sipariş sayıları
                $new_orders = $this->api_helper->getOrders('New', 0, 1);
                if ($new_orders && isset($new_orders['pagingData']['totalCount'])) {
                    $stats['pending_orders'] = $new_orders['pagingData']['totalCount'];
                }
                
                // Senkronize edilmiş ürün sayısı
                $query = $this->db->query("
                    SELECT COUNT(*) as total FROM " . DB_PREFIX . "n11_products 
                    WHERE sync_status = 'synced'
                ");
                $stats['synced_products'] = $query->row['total'];
                
                // Son senkronizasyon
                $query = $this->db->query("
                    SELECT MAX(last_updated) as last_sync FROM " . DB_PREFIX . "n11_products
                ");
                if ($query->row['last_sync']) {
                    $stats['last_sync'] = date('Y-m-d H:i:s', strtotime($query->row['last_sync']));
                }
            }
        } catch (Exception $e) {
            $this->log('STATS_ERROR', 'İstatistik çekme hatası: ' . $e->getMessage());
        }
        
        return $stats;
    }
    
    // Yardımcı metodlar
    private function getCategoryMapping($opencart_category_id) {
        $query = $this->db->query("
            SELECT * FROM " . DB_PREFIX . "n11_category_mapping 
            WHERE opencart_category_id = '" . (int)$opencart_category_id . "'
        ");
        
        return $query->row;
    }
    
    private function sanitizeTitle($title) {
        // N11 başlık kuralları
        $title = strip_tags($title);
        $title = preg_replace('/\s+/', ' ', $title);
        $title = trim($title);
        
        if (strlen($title) > 200) {
            $title = substr($title, 0, 197) . '...';
        }
        
        return $title;
    }
    
    private function sanitizeDescription($description) {
        // HTML temizleme ve N11 formatına uygun hale getirme
        $description = strip_tags($description, '<br><p><ul><li><strong><em>');
        $description = preg_replace('/\s+/', ' ', $description);
        
        return trim($description);
    }
    
    private function calculatePrice($price) {
        // KDV ve kar marjı hesaplamaları
        $tax_rate = 1.18; // %18 KDV
        $margin = 1.1; // %10 kar marjı
        
        return round($price * $tax_rate * $margin, 2);
    }
    
    private function prepareImages($product) {
        $this->load->model('catalog/product');
        $images = $this->model_catalog_product->getProductImages($product['product_id']);
        
        $n11_images = array();
        
        // Ana resim
        if ($product['image']) {
            $n11_images[] = array(
                'url' => HTTP_CATALOG . 'image/' . $product['image'],
                'order' => 1
            );
        }
        
        // Ek resimler
        $order = 2;
        foreach ($images as $image) {
            $n11_images[] = array(
                'url' => HTTP_CATALOG . 'image/' . $image['image'],
                'order' => $order++
            );
        }
        
        return array('image' => $n11_images);
    }
    
    private function prepareStockItems($product) {
        // Varyasyon kontrolü
        $this->load->model('catalog/product');
        $options = $this->model_catalog_product->getProductOptions($product['product_id']);
        
        if (empty($options)) {
            // Tek ürün
            return array(
                'stockItem' => array(
                    array(
                        'sellerStockCode' => $product['model'],
                        'quantity' => $product['quantity'],
                        'optionPrice' => $this->calculatePrice($product['price'])
                    )
                )
            );
        } else {
            // Varyasyonlu ürün
            return $this->prepareVariations($product, $options);
        }
    }
    
    private function prepareAttributes($product, $category_mapping) {
        $attributes = array();
        
        if (isset($category_mapping['attributes'])) {
            $required_attrs = json_decode($category_mapping['attributes'], true);
            
            // Gerekli özellikleri doldur
            foreach ($required_attrs as $attr) {
                if ($attr['mandatory']) {
                    $attributes[] = array(
                        'name' => $attr['name'],
                        'value' => $this->getAttributeValue($product, $attr)
                    );
                }
            }
        }
        
        return $attributes;
    }
    
    private function orderExists($n11_order_id) {
        $query = $this->db->query("
            SELECT * FROM " . DB_PREFIX . "n11_orders 
            WHERE n11_order_id = '" . $this->db->escape($n11_order_id) . "'
        ");
        
        return $query->num_rows > 0;
    }
    
    private function saveOrderMapping($order_id, $n11_order) {
        $this->db->query("
            INSERT INTO " . DB_PREFIX . "n11_orders SET
                n11_order_id = '" . $this->db->escape($n11_order['id']) . "',
                opencart_order_id = '" . (int)$order_id . "',
                order_number = '" . $this->db->escape($n11_order['orderNumber']) . "',
                status = '" . $this->db->escape($n11_order['status']) . "',
                total = '" . (float)$n11_order['totalAmount'] . "',
                order_data = '" . $this->db->escape(json_encode($n11_order)) . "',
                date_added = NOW(),
                date_modified = NOW()
        ");
    }
    
    private function mapOrderStatus($n11_status) {
        $status_map = array(
            'New' => 1, // Beklemede
            'Approved' => 2, // İşleniyor
            'Completed' => 5, // Tamamlandı
            'Cancelled' => 7 // İptal
        );
        
        return isset($status_map[$n11_status]) ? $status_map[$n11_status] : 1;
    }
} 