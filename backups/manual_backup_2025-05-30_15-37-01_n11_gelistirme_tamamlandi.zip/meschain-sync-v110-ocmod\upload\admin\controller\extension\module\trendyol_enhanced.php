<?php
/**
 * Enhanced Trendyol Controller with Fixed Login Redirection
 * Developer 1 Task: Trendyol Integration Improvements
 */
require_once(DIR_APPLICATION . 'controller/extension/module/base_marketplace.php');

class ControllerExtensionModuleTrendyolEnhanced extends ControllerExtensionModuleBaseMarketplace {
    
    public function __construct($registry) {
        parent::__construct($registry);
        $this->marketplace_name = 'trendyol';
    }
    
    /**
     * Ana dashboard - Login redirection sorunu çözüldü
     */
    public function index() {
        $this->load->language('extension/module/trendyol');
        $this->document->setTitle($this->language->get('heading_title'));
        
        // Session kontrolü ve güvenlik
        $this->validateUserSession();
        
        // API ayarları kontrolü
        $user_id = $this->user->getId();
        $api_settings = $this->getUserApiSettings($user_id);
        
        // Eğer API ayarları yoksa, ayarlar sayfasına yönlendir
        if (empty($api_settings['api_key']) || empty($api_settings['api_secret'])) {
            $this->session->data['warning'] = 'Lütfen önce Trendyol API ayarlarınızı yapılandırın.';
            $this->response->redirect($this->url->link('extension/module/trendyol_enhanced/settings', 'user_token=' . $this->session->data['user_token'], true));
            return;
        }
        
        $data = $this->prepareCommonData();
        $data = array_merge($data, $this->prepareMarketplaceData());
        
        // Dashboard istatistikleri
        $data['statistics'] = $this->getTrendyolStatistics($user_id);
        
        // Son aktiviteler
        $data['recent_activities'] = $this->getRecentActivities($user_id);
        
        // Dropshipping durumu
        if ($this->isDropshippingEnabled($user_id)) {
            $data['dropshipping_stats'] = $this->getDropshippingStats($user_id);
        }
        
        $this->renderView('trendyol_dashboard', $data);
    }
    
    /**
     * API Ayarları sayfası - Login redirection çözümü
     */
    public function settings() {
        $this->load->language('extension/module/trendyol');
        $this->document->setTitle('Trendyol API Ayarları');
        
        $user_id = $this->user->getId();
        
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateSettings()) {
            $this->saveUserApiSettings($user_id, $this->request->post);
            
            // Başarılı kayıt sonrası ana dashboard'a yönlendir (OpenCart dashboard'a değil!)
            $this->session->data['success'] = 'Trendyol API ayarları başarıyla kaydedildi!';
            $this->response->redirect($this->url->link('extension/module/trendyol_enhanced', 'user_token=' . $this->session->data['user_token'], true));
            return;
        }
        
        $data = $this->prepareCommonData();
        
        // Mevcut API ayarları
        $data['api_settings'] = $this->getUserApiSettings($user_id);
        
        // Test bağlantı URL'si
        $data['test_connection_url'] = $this->url->link('extension/module/trendyol_enhanced/test_connection', 'user_token=' . $this->session->data['user_token'], true);
        
        $this->renderView('trendyol_settings', $data);
    }
    
    /**
     * OAuth Login işlemi - Redirection sorunu çözümü
     */
    public function oauth_login() {
        $this->load->language('extension/module/trendyol');
        
        $user_id = $this->user->getId();
        
        // OAuth parametreleri
        $client_id = $this->request->get['client_id'] ?? '';
        $redirect_uri = $this->request->get['redirect_uri'] ?? '';
        $state = $this->request->get['state'] ?? '';
        
        if (empty($client_id)) {
            // API ayarlarından client_id al
            $api_settings = $this->getUserApiSettings($user_id);
            $client_id = $api_settings['client_id'] ?? '';
        }
        
        if (empty($client_id)) {
            $this->session->data['error_warning'] = 'Trendyol Client ID bulunamadı. Lütfen API ayarlarınızı kontrol edin.';
            $this->response->redirect($this->url->link('extension/module/trendyol_enhanced/settings', 'user_token=' . $this->session->data['user_token'], true));
            return;
        }
        
        // Doğru redirect URI'ı oluştur - Bu çok önemli!
        $correct_redirect_uri = HTTPS_SERVER . 'index.php?route=extension/module/trendyol_enhanced/oauth_callback&user_token=' . $this->session->data['user_token'];
        
        // OAuth URL'i oluştur
        $oauth_url = 'https://auth.trendyol.com/oauth/authorize?' . http_build_query(array(
            'client_id' => $client_id,
            'response_type' => 'code',
            'redirect_uri' => $correct_redirect_uri,
            'scope' => 'read write',
            'state' => base64_encode(json_encode(array(
                'user_id' => $user_id,
                'timestamp' => time(),
                'return_url' => $this->url->link('extension/module/trendyol_enhanced', 'user_token=' . $this->session->data['user_token'], true)
            )))
        ));
        
        // State'i session'a kaydet (güvenlik için)
        $this->session->data['trendyol_oauth_state'] = $state;
        
        // OAuth sayfasına yönlendir
        $this->response->redirect($oauth_url);
    }
    
    /**
     * OAuth Callback - Login sonrası doğru sayfaya yönlendirme
     */
    public function oauth_callback() {
        $this->load->language('extension/module/trendyol');
        
        $code = $this->request->get['code'] ?? '';
        $state = $this->request->get['state'] ?? '';
        $error = $this->request->get['error'] ?? '';
        
        // Hata kontrolü
        if ($error) {
            $this->session->data['error_warning'] = 'Trendyol OAuth hatası: ' . $error;
            $this->response->redirect($this->url->link('extension/module/trendyol_enhanced/settings', 'user_token=' . $this->session->data['user_token'], true));
            return;
        }
        
        // State doğrulama
        if (empty($state) || $state !== ($this->session->data['trendyol_oauth_state'] ?? '')) {
            $this->session->data['error_warning'] = 'OAuth state doğrulaması başarısız. Güvenlik nedeniyle işlem iptal edildi.';
            $this->response->redirect($this->url->link('extension/module/trendyol_enhanced/settings', 'user_token=' . $this->session->data['user_token'], true));
            return;
        }
        
        // State verilerini çöz
        $state_data = json_decode(base64_decode($state), true);
        $user_id = $state_data['user_id'] ?? $this->user->getId();
        $return_url = $state_data['return_url'] ?? $this->url->link('extension/module/trendyol_enhanced', 'user_token=' . $this->session->data['user_token'], true);
        
        // Authorization code ile token al
        try {
            $token_data = $this->getAccessToken($code, $user_id);
            
            if ($token_data) {
                // Token'ları güvenli şekilde kaydet
                $this->saveUserTokens($user_id, $token_data);
                
                $this->session->data['success'] = 'Trendyol hesabınız başarıyla bağlandı!';
                
                // Kullanıcı aktivitesini logla
                $this->logUserActivity($user_id, 'OAUTH_SUCCESS', 'TRENDYOL', 'OAuth bağlantısı başarıyla tamamlandı');
                
                // DOĞRU sayfaya yönlendir - OpenCart dashboard'a değil!
                $this->response->redirect($return_url);
            } else {
                throw new Exception('Token alınamadı');
            }
            
        } catch (Exception $e) {
            $this->session->data['error_warning'] = 'Trendyol bağlantı hatası: ' . $e->getMessage();
            $this->logUserActivity($user_id, 'OAUTH_ERROR', 'TRENDYOL', 'OAuth hatası: ' . $e->getMessage());
            $this->response->redirect($this->url->link('extension/module/trendyol_enhanced/settings', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        // State'i temizle
        unset($this->session->data['trendyol_oauth_state']);
    }
    
    /**
     * Trendyol'e özgü veri hazırlama
     */
    protected function prepareMarketplaceData() {
        $user_id = $this->user->getId();
        $data = array();
        
        // Kullanıcı API ayarları
        $api_settings = $this->getUserApiSettings($user_id);
        foreach (array('api_key', 'api_secret', 'supplier_id', 'client_id') as $field) {
            $key = 'module_trendyol_' . $field;
            $data[$key] = isset($api_settings[$field]) ? $this->maskApiKey($api_settings[$field]) : '';
        }
        
        // Trendyol'e özel URL'ler
        $data['oauth_login_url'] = $this->url->link('extension/module/trendyol_enhanced/oauth_login', 'user_token=' . $this->session->data['user_token'], true);
        $data['product_management_url'] = $this->url->link('extension/module/trendyol_enhanced/product_management', 'user_token=' . $this->session->data['user_token'], true);
        $data['commission_settings_url'] = $this->url->link('extension/module/trendyol_enhanced/commission_settings', 'user_token=' . $this->session->data['user_token'], true);
        
        return $data;
    }
    
    /**
     * Ürün hazırlama (Trendyol formatı)
     */
    protected function prepareProductForMarketplace($product) {
        $user_id = $this->user->getId();
        
        // Barcode oluştur
        $barcode = $this->generateBarcode($user_id, $product['model']);
        
        // Komisyon hesaplaması
        $commission_rules = $this->getUserCommissionRules($user_id, 'trendyol', $product);
        $final_price = $this->calculateFinalPrice($product['price'], $commission_rules);
        
        // Trendyol ürün formatı
        return array(
            'barcode' => $barcode,
            'title' => $this->sanitizeTitle($product['name']),
            'productMainId' => $product['model'],
            'brandId' => $this->getBrandId($product['manufacturer']),
            'categoryId' => $this->getTrendyolCategoryId($product['category_id']),
            'quantity' => $product['quantity'],
            'listPrice' => $final_price,
            'salePrice' => $final_price,
            'vatRate' => 18,
            'dimensionalWeight' => $this->calculateDimensionalWeight($product),
            'description' => $this->sanitizeDescription($product['description']),
            'images' => $this->prepareImages($product),
            'attributes' => $this->prepareTrendyolAttributes($product)
        );
    }
    
    /**
     * Sipariş import (Trendyol)
     */
    protected function importOrder($trendyol_order) {
        $user_id = $this->user->getId();
        
        // Sipariş kontrolü
        if ($this->orderExists($user_id, $trendyol_order['orderNumber'])) {
            return false;
        }
        
        // Dropshipping kontrolü
        $is_dropshipping = $this->isDropshippingEnabled($user_id);
        
        if ($is_dropshipping) {
            return $this->processDropshippingOrder($user_id, $trendyol_order);
        } else {
            return $this->processRegularOrder($user_id, $trendyol_order);
        }
    }
    
    /**
     * API Helper başlatma
     */
    protected function initializeApiHelper($credentials) {
        require_once(DIR_SYSTEM . 'helper/trendyol_helper.php');
        $this->api_helper = new TrendyolHelper(
            $credentials['api_key'], 
            $credentials['api_secret'], 
            $credentials['supplier_id']
        );
    }
    
    /**
     * Access token alma
     */
    private function getAccessToken($code, $user_id) {
        $api_settings = $this->getUserApiSettings($user_id);
        
        $token_url = 'https://auth.trendyol.com/oauth/token';
        $redirect_uri = HTTPS_SERVER . 'index.php?route=extension/module/trendyol_enhanced/oauth_callback&user_token=' . $this->session->data['user_token'];
        
        $post_data = array(
            'grant_type' => 'authorization_code',
            'client_id' => $api_settings['client_id'],
            'client_secret' => $api_settings['client_secret'],
            'code' => $code,
            'redirect_uri' => $redirect_uri
        );
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $token_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json'
        ));
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200) {
            return json_decode($response, true);
        }
        
        throw new Exception('Token alınamadı: HTTP ' . $http_code . ' - ' . $response);
    }
    
    /**
     * User token'ları kaydet
     */
    private function saveUserTokens($user_id, $token_data) {
        $encrypted_tokens = array();
        foreach ($token_data as $key => $value) {
            $encrypted_tokens[$key] = SecurityHelper::encryptApiKey($value);
        }
        
        $this->db->query("
            INSERT INTO " . DB_PREFIX . "user_api_settings SET
                user_id = '" . (int)$user_id . "',
                marketplace = 'trendyol_tokens',
                api_data = '" . $this->db->escape(json_encode($encrypted_tokens)) . "',
                status = '1',
                created_date = NOW()
            ON DUPLICATE KEY UPDATE
                api_data = VALUES(api_data),
                updated_date = NOW()
        ");
    }
    
    /**
     * Session validasyonu
     */
    private function validateUserSession() {
        // Session timeout kontrolü
        $timeout = 3600; // 1 saat
        if (isset($this->session->data['last_activity'])) {
            if ((time() - $this->session->data['last_activity']) > $timeout) {
                $this->session->data = array();
                $this->response->redirect($this->url->link('common/login', '', true));
                return;
            }
        }
        $this->session->data['last_activity'] = time();
        
        // IP kontrolü (güvenlik)
        $current_ip = $this->request->server['REMOTE_ADDR'];
        if (isset($this->session->data['user_ip']) && $this->session->data['user_ip'] !== $current_ip) {
            $this->log('SECURITY_WARNING', 'IP değişikliği tespit edildi: ' . $current_ip);
        }
        $this->session->data['user_ip'] = $current_ip;
    }
    
    /**
     * Kullanıcı API ayarları
     */
    private function getUserApiSettings($user_id) {
        $query = $this->db->query("
            SELECT api_data FROM " . DB_PREFIX . "user_api_settings 
            WHERE user_id = '" . (int)$user_id . "' AND marketplace = 'trendyol'
        ");
        
        if ($query->num_rows) {
            $api_data = json_decode($query->row['api_data'], true);
            
            // Şifrelenmiş verileri çöz
            $decrypted = array();
            foreach ($api_data as $key => $value) {
                $decrypted[$key] = SecurityHelper::decryptApiKey($value);
            }
            
            return $decrypted;
        }
        
        return array();
    }
    
    /**
     * API ayarları kaydet
     */
    private function saveUserApiSettings($user_id, $post_data) {
        $api_fields = array('api_key', 'api_secret', 'supplier_id', 'client_id', 'client_secret');
        $api_data = array();
        
        foreach ($api_fields as $field) {
            if (isset($post_data[$field]) && !empty($post_data[$field])) {
                $api_data[$field] = SecurityHelper::encryptApiKey($post_data[$field]);
            }
        }
        
        $this->db->query("
            INSERT INTO " . DB_PREFIX . "user_api_settings SET
                user_id = '" . (int)$user_id . "',
                marketplace = 'trendyol',
                api_data = '" . $this->db->escape(json_encode($api_data)) . "',
                status = '1',
                created_date = NOW()
            ON DUPLICATE KEY UPDATE
                api_data = VALUES(api_data),
                updated_date = NOW()
        ");
        
        $this->logUserActivity($user_id, 'API_SETTINGS_UPDATE', 'TRENDYOL', 'API ayarları güncellendi');
    }
    
    /**
     * Trendyol istatistikleri
     */
    private function getTrendyolStatistics($user_id) {
        // Kullanıcıya özel Trendyol istatistikleri
        $stats = array(
            'total_products' => 0,
            'approved_products' => 0,
            'pending_products' => 0,
            'rejected_products' => 0,
            'total_orders' => 0,
            'pending_shipment' => 0,
            'shipped_orders' => 0,
            'total_revenue' => 0
        );
        
        // Gerçek veriler burada çekilecek...
        
        return $stats;
    }
    
    // Diğer yardımcı metodlar...
    private function logUserActivity($user_id, $action, $module, $description) {
        $this->db->query("
            INSERT INTO " . DB_PREFIX . "user_activity_log SET
                user_id = '" . (int)$user_id . "',
                action = '" . $this->db->escape($action) . "',
                module = '" . $this->db->escape($module) . "',
                description = '" . $this->db->escape($description) . "',
                ip_address = '" . $this->db->escape($this->request->server['REMOTE_ADDR']) . "',
                created_date = NOW()
        ");
    }
    
    private function maskApiKey($key) {
        if (strlen($key) <= 8) {
            return str_repeat('*', strlen($key));
        }
        return substr($key, 0, 4) . str_repeat('*', strlen($key) - 8) . substr($key, -4);
    }
} 