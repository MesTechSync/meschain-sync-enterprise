<?php
/**
 * MeschainN11Helper
 * 
 * N11 API entegrasyonu için yardımcı sınıf.
 * Bu sınıf N11 API'si ile iletişim kurma, sipariş oluşturma ve ürün senkronizasyonu gibi işlemleri yönetir.
 */
class MeschainN11Helper {
    private $registry;
    private $config;
    private $log;
    private $db;
    private $session;
    private $currency;
    private $apiUrl = 'https://api.n11.com/ws/';
    private $apiKey;
    private $apiSecret;
    private $logFile = 'n11_helper.log';
    
    /**
     * Kurucu metod
     * 
     * @param object $registry OpenCart registry objesi
     */
    public function __construct($registry) {
        $this->registry = $registry;
        $this->config = $registry->get('config');
        $this->db = $registry->get('db');
        $this->session = $registry->get('session');
        $this->currency = $registry->get('currency');
        
        // Logger başlat
        $this->log = new Log($this->logFile);
        
        // API bilgilerini yükle
        $this->loadApiCredentials();
    }
    
    /**
     * API kimlik bilgilerini yükle
     */
    private function loadApiCredentials() {
        $this->apiKey = $this->config->get('module_n11_app_key');
        $this->apiSecret = $this->config->get('module_n11_app_secret');
        
        if (empty($this->apiKey) || empty($this->apiSecret)) {
            $this->writeLog('UYARI', 'N11 API kimlik bilgileri eksik');
        }
    }
    
    /**
     * N11 API bağlantısını test et
     * 
     * @return array Test sonucu
     */
    public function testConnection() {
        try {
            $this->writeLog('INFO', 'N11 API bağlantı testi başlatılıyor');
            
            $auth = $this->generateAuth();
            $requestData = [
                'auth' => $auth,
                'pagingData' => [
                    'currentPage' => 0,
                    'pageSize' => 1
                ]
            ];
            
            $response = $this->makeApiRequest('CategoryService/GetTopLevelCategories', $requestData);
            
            if (isset($response['result']['status']) && $response['result']['status'] == 'success') {
                $this->writeLog('BASARILI', 'N11 API bağlantı testi başarılı');
                return [
                    'success' => true,
                    'message' => 'N11 API bağlantısı başarılı'
                ];
            } else {
                $errorMsg = isset($response['result']['errorMessage']) ? $response['result']['errorMessage'] : 'Bilinmeyen hata';
                $this->writeLog('HATA', 'N11 API bağlantı testi başarısız: ' . $errorMsg);
                return [
                    'success' => false,
                    'message' => 'N11 API bağlantısı başarısız: ' . $errorMsg
                ];
            }
        } catch (Exception $e) {
            $this->writeLog('HATA', 'N11 API bağlantı testi exception: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Bağlantı hatası: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * N11 siparişlerini çek
     * 
     * @param array $params Filtre parametreleri
     * @return array Siparişler
     */
    public function getOrders($params = []) {
        try {
            $this->writeLog('INFO', 'N11 siparişleri çekiliyor');
            
            $auth = $this->generateAuth();
            $requestData = [
                'auth' => $auth,
                'searchData' => [
                    'productId' => $params['product_id'] ?? null,
                    'status' => $params['status'] ?? null,
                    'buyerName' => $params['buyer_name'] ?? null,
                    'orderNumber' => $params['order_number'] ?? null,
                    'productSellerCode' => $params['seller_code'] ?? null,
                    'recipient' => $params['recipient'] ?? null,
                    'sameDayDelivery' => $params['same_day_delivery'] ?? null
                ],
                'pagingData' => [
                    'currentPage' => $params['page'] ?? 0,
                    'pageSize' => $params['limit'] ?? 100
                ]
            ];
            
            // Boş değerleri temizle
            $requestData['searchData'] = array_filter($requestData['searchData'], function($value) {
                return $value !== null && $value !== '';
            });
            
            $response = $this->makeApiRequest('OrderService/OrderList', $requestData);
            
            if (isset($response['result']['status']) && $response['result']['status'] == 'success') {
                $orders = isset($response['orderList']) ? $response['orderList'] : [];
                $this->writeLog('BASARILI', count($orders) . ' N11 siparişi çekildi');
                return [
                    'success' => true,
                    'orders' => $orders,
                    'total' => count($orders)
                ];
            } else {
                $errorMsg = isset($response['result']['errorMessage']) ? $response['result']['errorMessage'] : 'Bilinmeyen hata';
                $this->writeLog('HATA', 'N11 sipariş çekme başarısız: ' . $errorMsg);
                return [
                    'success' => false,
                    'message' => $errorMsg
                ];
            }
        } catch (Exception $e) {
            $this->writeLog('HATA', 'N11 sipariş çekme exception: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Sipariş çekme hatası: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * N11 sipariş detayını çek
     * 
     * @param int $orderId N11 sipariş ID
     * @return array Sipariş detayı
     */
    public function getOrderDetail($orderId) {
        try {
            $this->writeLog('INFO', 'N11 sipariş detayı çekiliyor: ' . $orderId);
            
            $auth = $this->generateAuth();
            $requestData = [
                'auth' => $auth,
                'orderRequest' => [
                    'id' => $orderId
                ]
            ];
            
            $response = $this->makeApiRequest('OrderService/OrderDetail', $requestData);
            
            if (isset($response['result']['status']) && $response['result']['status'] == 'success') {
                $orderDetail = isset($response['orderDetail']) ? $response['orderDetail'] : null;
                $this->writeLog('BASARILI', 'N11 sipariş detayı çekildi: ' . $orderId);
                return [
                    'success' => true,
                    'order' => $orderDetail
                ];
            } else {
                $errorMsg = isset($response['result']['errorMessage']) ? $response['result']['errorMessage'] : 'Bilinmeyen hata';
                $this->writeLog('HATA', 'N11 sipariş detayı çekme başarısız: ' . $errorMsg);
                return [
                    'success' => false,
                    'message' => $errorMsg
                ];
            }
        } catch (Exception $e) {
            $this->writeLog('HATA', 'N11 sipariş detayı çekme exception: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Sipariş detayı çekme hatası: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * N11 kategorilerini çek
     * 
     * @param int $parentId Üst kategori ID (null ise ana kategoriler)
     * @return array Kategoriler
     */
    public function getCategories($parentId = null) {
        try {
            $this->writeLog('INFO', 'N11 kategorileri çekiliyor');
            
            $auth = $this->generateAuth();
            $requestData = [
                'auth' => $auth,
                'pagingData' => [
                    'currentPage' => 0,
                    'pageSize' => 1000
                ]
            ];
            
            $endpoint = $parentId ? 'CategoryService/GetSubCategories' : 'CategoryService/GetTopLevelCategories';
            
            if ($parentId) {
                $requestData['category'] = ['id' => $parentId];
            }
            
            $response = $this->makeApiRequest($endpoint, $requestData);
            
            if (isset($response['result']['status']) && $response['result']['status'] == 'success') {
                $categories = isset($response['categoryList']) ? $response['categoryList'] : [];
                $this->writeLog('BASARILI', count($categories) . ' N11 kategorisi çekildi');
                return [
                    'success' => true,
                    'categories' => $categories
                ];
            } else {
                $errorMsg = isset($response['result']['errorMessage']) ? $response['result']['errorMessage'] : 'Bilinmeyen hata';
                $this->writeLog('HATA', 'N11 kategori çekme başarısız: ' . $errorMsg);
                return [
                    'success' => false,
                    'message' => $errorMsg
                ];
            }
        } catch (Exception $e) {
            $this->writeLog('HATA', 'N11 kategori çekme exception: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Kategori çekme hatası: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Ürünü N11'e gönder
     * 
     * @param array $productData Ürün verisi
     * @return array Sonuç
     */
    public function sendProduct($productData) {
        try {
            $this->writeLog('INFO', 'Ürün N11\'e gönderiliyor: ' . $productData['model']);
            
            $auth = $this->generateAuth();
            $requestData = [
                'auth' => $auth,
                'product' => $this->prepareProductData($productData)
            ];
            
            $response = $this->makeApiRequest('ProductService/SaveProduct', $requestData);
            
            if (isset($response['result']['status']) && $response['result']['status'] == 'success') {
                $productInfo = isset($response['product']) ? $response['product'] : null;
                $this->writeLog('BASARILI', 'Ürün N11\'e gönderildi: ' . $productData['model']);
                return [
                    'success' => true,
                    'product' => $productInfo
                ];
            } else {
                $errorMsg = isset($response['result']['errorMessage']) ? $response['result']['errorMessage'] : 'Bilinmeyen hata';
                $this->writeLog('HATA', 'Ürün gönderme başarısız: ' . $errorMsg);
                return [
                    'success' => false,
                    'message' => $errorMsg
                ];
            }
        } catch (Exception $e) {
            $this->writeLog('HATA', 'Ürün gönderme exception: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Ürün gönderme hatası: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Ürün stok güncelle
     * 
     * @param string $productSellerCode Ürün satıcı kodu
     * @param int $quantity Stok miktarı
     * @return array Sonuç
     */
    public function updateStock($productSellerCode, $quantity) {
        try {
            $this->writeLog('INFO', 'N11 ürün stoku güncelleniyor: ' . $productSellerCode);
            
            $auth = $this->generateAuth();
            $requestData = [
                'auth' => $auth,
                'productStock' => [
                    'productSellerCode' => $productSellerCode,
                    'quantity' => $quantity
                ]
            ];
            
            $response = $this->makeApiRequest('ProductStockService/UpdateProductStock', $requestData);
            
            if (isset($response['result']['status']) && $response['result']['status'] == 'success') {
                $this->writeLog('BASARILI', 'N11 ürün stoku güncellendi: ' . $productSellerCode);
                return [
                    'success' => true,
                    'message' => 'Stok başarıyla güncellendi'
                ];
            } else {
                $errorMsg = isset($response['result']['errorMessage']) ? $response['result']['errorMessage'] : 'Bilinmeyen hata';
                $this->writeLog('HATA', 'N11 stok güncelleme başarısız: ' . $errorMsg);
                return [
                    'success' => false,
                    'message' => $errorMsg
                ];
            }
        } catch (Exception $e) {
            $this->writeLog('HATA', 'N11 stok güncelleme exception: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Stok güncelleme hatası: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * N11 siparişini OpenCart siparişine dönüştür
     * 
     * @param array $n11Order N11 sipariş verisi
     * @return array OpenCart sipariş verisi
     */
    public function createOrderFromN11($n11Order) {
        try {
            $this->writeLog('INFO', 'N11 siparişi OpenCart\'a dönüştürülüyor: ' . $n11Order['orderNumber']);
            
            // OpenCart order objesi oluştur
            $order_data = [
                'invoice_prefix' => 'N11-',
                'store_id' => 0,
                'store_name' => $this->config->get('config_name'),
                'store_url' => $this->config->get('config_url'),
                'customer_id' => 0,
                'customer_group_id' => $this->config->get('config_customer_group_id'),
                'firstname' => $this->extractFirstName($n11Order['buyer']['fullName']),
                'lastname' => $this->extractLastName($n11Order['buyer']['fullName']),
                'email' => $n11Order['buyer']['email'] ?? 'n11@example.com',
                'telephone' => $n11Order['buyer']['phoneNumber'] ?? '',
                'custom_field' => [],
                
                // Ödeme bilgileri
                'payment_firstname' => $this->extractFirstName($n11Order['buyer']['fullName']),
                'payment_lastname' => $this->extractLastName($n11Order['buyer']['fullName']),
                'payment_company' => '',
                'payment_address_1' => $n11Order['billingAddress']['address'] ?? '',
                'payment_address_2' => '',
                'payment_city' => $n11Order['billingAddress']['city'] ?? '',
                'payment_postcode' => $n11Order['billingAddress']['postalCode'] ?? '',
                'payment_country' => 'Türkiye',
                'payment_country_id' => 215, // Türkiye ID
                'payment_zone' => $n11Order['billingAddress']['city'] ?? '',
                'payment_zone_id' => 0,
                'payment_address_format' => '{firstname} {lastname}\n{company}\n{address_1}\n{address_2}\n{city} {postcode}\n{zone}\n{country}',
                'payment_custom_field' => [],
                'payment_method' => 'N11 Ödeme',
                'payment_code' => 'n11_payment',
                
                // Teslimat bilgileri
                'shipping_firstname' => $this->extractFirstName($n11Order['buyer']['fullName']),
                'shipping_lastname' => $this->extractLastName($n11Order['buyer']['fullName']),
                'shipping_company' => '',
                'shipping_address_1' => $n11Order['shippingAddress']['address'] ?? '',
                'shipping_address_2' => '',
                'shipping_city' => $n11Order['shippingAddress']['city'] ?? '',
                'shipping_postcode' => $n11Order['shippingAddress']['postalCode'] ?? '',
                'shipping_country' => 'Türkiye',
                'shipping_country_id' => 215,
                'shipping_zone' => $n11Order['shippingAddress']['city'] ?? '',
                'shipping_zone_id' => 0,
                'shipping_address_format' => '{firstname} {lastname}\n{company}\n{address_1}\n{address_2}\n{city} {postcode}\n{zone}\n{country}',
                'shipping_custom_field' => [],
                'shipping_method' => 'N11 Kargo',
                'shipping_code' => 'n11_shipping',
                
                // Sipariş bilgileri
                'currency_code' => 'TRY',
                'currency_id' => $this->currency->getId('TRY'),
                'currency_value' => 1.0000,
                'language_id' => $this->config->get('config_language_id'),
                'order_status_id' => $this->getOrderStatusId($n11Order['status']),
                'affiliate_id' => 0,
                'commission' => 0,
                'marketing_id' => 0,
                'tracking' => '',
                'comment' => 'N11 Siparişi - Sipariş No: ' . $n11Order['orderNumber'],
                'total' => $n11Order['totalAmount'] ?? 0,
                'reward' => 0,
                'order_status' => $this->getOrderStatusName($n11Order['status']),
                'date_added' => date('Y-m-d H:i:s'),
                'date_modified' => date('Y-m-d H:i:s')
            ];
            
            // Ürünleri ekle
            $products = [];
            if (isset($n11Order['itemList']) && is_array($n11Order['itemList'])) {
                foreach ($n11Order['itemList'] as $item) {
                    $product = $this->convertN11Product($item);
                    if ($product) {
                        $products[] = $product;
                    }
                }
            }
            $order_data['products'] = $products;
            
            // Voucher ve totals
            $order_data['vouchers'] = [];
            $order_data['totals'] = $this->calculateOrderTotals($n11Order);
            
            $this->writeLog('BASARILI', 'N11 siparişi OpenCart formatına dönüştürüldü: ' . $n11Order['orderNumber']);
            
            return [
                'success' => true,
                'order_data' => $order_data
            ];
            
        } catch (Exception $e) {
            $this->writeLog('HATA', 'Sipariş dönüştürme exception: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Sipariş dönüştürme hatası: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * N11 API isteği gönder
     * 
     * @param string $endpoint API endpoint
     * @param array $data Gönderilecek veri
     * @return array API yanıtı
     */
    private function makeApiRequest($endpoint, $data) {
        $url = $this->apiUrl . $endpoint;
        
        $postData = json_encode($data);
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($postData)
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new Exception('CURL Error: ' . $error);
        }
        
        curl_close($ch);
        
        if ($httpCode !== 200) {
            throw new Exception('HTTP Error: ' . $httpCode);
        }
        
        $decodedResponse = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('JSON Decode Error: ' . json_last_error_msg());
        }
        
        return $decodedResponse;
    }
    
    /**
     * N11 API için auth objesi oluştur
     * 
     * @return array Auth objesi
     */
    private function generateAuth() {
        return [
            'appKey' => $this->apiKey,
            'appSecret' => $this->apiSecret
        ];
    }
    
    /**
     * Log yaz
     * 
     * @param string $level Log seviyesi
     * @param string $message Mesaj
     */
    private function writeLog($level, $message) {
        $this->log->write('[' . $level . '] ' . $message);
    }
    
    /**
     * İsimden ad çıkar
     */
    private function extractFirstName($fullName) {
        $parts = explode(' ', trim($fullName));
        return isset($parts[0]) ? $parts[0] : 'N11';
    }
    
    /**
     * İsimden soyad çıkar
     */
    private function extractLastName($fullName) {
        $parts = explode(' ', trim($fullName));
        if (count($parts) > 1) {
            return implode(' ', array_slice($parts, 1));
        }
        return 'Müşteri';
    }
    
    /**
     * N11 durumunu OpenCart sipariş durumuna çevir
     */
    private function getOrderStatusId($n11Status) {
        $statusMap = [
            'New' => 1,           // Pending
            'Confirmed' => 2,     // Processing
            'Shipped' => 3,       // Shipped
            'Delivered' => 5,     // Complete
            'Cancelled' => 7,     // Cancelled
            'Returned' => 11      // Refunded
        ];
        
        return isset($statusMap[$n11Status]) ? $statusMap[$n11Status] : 1;
    }
    
    /**
     * N11 durumunu OpenCart sipariş durum adına çevir
     */
    private function getOrderStatusName($n11Status) {
        $statusMap = [
            'New' => 'Pending',
            'Confirmed' => 'Processing',
            'Shipped' => 'Shipped',
            'Delivered' => 'Complete',
            'Cancelled' => 'Cancelled',
            'Returned' => 'Refunded'
        ];
        
        return isset($statusMap[$n11Status]) ? $statusMap[$n11Status] : 'Pending';
    }
    
    /**
     * N11 ürünü OpenCart ürünü formatına çevir
     */
    private function convertN11Product($n11Item) {
        // Ürün ID'sini seller code'dan bul
        $productId = $this->findProductBySellerCode($n11Item['productSellerCode'] ?? '');
        
        return [
            'product_id' => $productId,
            'name' => $n11Item['productName'] ?? 'N11 Ürün',
            'model' => $n11Item['productSellerCode'] ?? '',
            'quantity' => $n11Item['quantity'] ?? 1,
            'price' => $n11Item['price'] ?? 0,
            'total' => ($n11Item['price'] ?? 0) * ($n11Item['quantity'] ?? 1),
            'tax' => 0,
            'reward' => 0
        ];
    }
    
    /**
     * Seller code'a göre ürün bul
     */
    private function findProductBySellerCode($sellerCode) {
        $query = $this->db->query("SELECT product_id FROM " . DB_PREFIX . "product WHERE model = '" . $this->db->escape($sellerCode) . "'");
        return $query->num_rows ? $query->row['product_id'] : 0;
    }
    
    /**
     * Sipariş toplamlarını hesapla
     */
    private function calculateOrderTotals($n11Order) {
        $totals = [];
        
        $subTotal = ($n11Order['totalAmount'] ?? 0) - ($n11Order['shippingAmount'] ?? 0);
        
        // Alt toplam
        $totals[] = [
            'code' => 'sub_total',
            'title' => 'Alt Toplam',
            'value' => $subTotal,
            'sort_order' => 1
        ];
        
        // Kargo
        if (isset($n11Order['shippingAmount']) && $n11Order['shippingAmount'] > 0) {
            $totals[] = [
                'code' => 'shipping',
                'title' => 'Kargo',
                'value' => $n11Order['shippingAmount'],
                'sort_order' => 2
            ];
        }
        
        // Toplam
        $totals[] = [
            'code' => 'total',
            'title' => 'Toplam',
            'value' => $n11Order['totalAmount'] ?? 0,
            'sort_order' => 3
        ];
        
        return $totals;
    }
    
    /**
     * Ürün verisini N11 formatına hazırla
     */
    private function prepareProductData($productData) {
        return [
            'productSellerCode' => $productData['model'],
            'title' => $productData['name'],
            'subtitle' => '',
            'description' => $productData['description'] ?? '',
            'category' => [
                'id' => $productData['n11_category_id'] ?? 0
            ],
            'price' => $productData['price'] ?? 0,
            'currencyType' => 'TL',
            'images' => isset($productData['images']) ? $productData['images'] : [],
            'approvalStatus' => 1,
            'preparingDay' => $productData['preparing_day'] ?? 1,
            'stockItems' => [
                'stockItem' => [
                    'bundle' => false,
                    'mpn' => $productData['mpn'] ?? '',
                    'gtin' => $productData['gtin'] ?? '',
                    'oem' => $productData['oem'] ?? '',
                    'quantity' => $productData['quantity'] ?? 0,
                    'sellerStockCode' => $productData['model'],
                    'attributes' => isset($productData['attributes']) ? $productData['attributes'] : []
                ]
            ]
        ];
    }
} 