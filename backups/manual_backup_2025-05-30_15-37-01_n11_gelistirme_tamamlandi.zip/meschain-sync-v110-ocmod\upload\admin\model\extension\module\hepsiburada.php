<?php
/**
 * hepsiburada.php
 *
 * Amaç: Hepsiburada modülünün OpenCart yönetici paneli (admin) tarafındaki model dosyasıdır.
 *
 * Loglama: Tüm önemli işlemler ve hatalar hepsiburada_model.log dosyasına kaydedilmelidir.
 * Log formatı: [YYYY-MM-DD HH:MM:SS] [KULLANICI/ROL] [İŞLEM] [AÇIKLAMA]
 *
 * Veritabanı işlemleri: Sipariş ve ürün bilgilerinin saklanması ve alınmasını sağlar.
 */
class ModelExtensionModuleHepsiburada extends Model {
    /**
     * Log yazmak için kullanılan fonksiyon
     *
     * @param string $user Kullanıcı adı veya rolü
     * @param string $action Yapılan işlem
     * @param string $message Açıklama
     * @return void
     */
    private function writeLog($user, $action, $message) {
        $log_file = DIR_LOGS . 'hepsiburada_model.log';
        $date = date('Y-m-d H:i:s');
        $log = "[$date] [$user] [$action] $message\n";
        file_put_contents($log_file, $log, FILE_APPEND);
    }

    /**
     * Hepsiburada'dan siparişleri çeker ve veritabanına kaydeder
     *
     * @param array $filter_data Filtre parametreleri
     * @return int Çekilen sipariş sayısı
     */
    public function getOrders($filter_data) {
        $username = $this->config->get('module_hepsiburada_username');
        $password = $this->config->get('module_hepsiburada_password');
        $merchant_id = $this->config->get('module_hepsiburada_merchant_id');
        
        // API'den siparişleri çek
        require_once(DIR_SYSTEM . 'library/hepsiburada/hepsiburada_api.php');
        
        $settings = array(
            'username' => $username,
            'password' => $password,
            'merchant_id' => $merchant_id
        );
        
        $params = array(
            'date_start' => $filter_data['filter_date_start'] ?? date('Y-m-d', strtotime('-7 days')),
            'date_end' => $filter_data['filter_date_end'] ?? date('Y-m-d')
        );
        
        if (isset($filter_data['filter_status']) && !empty($filter_data['filter_status'])) {
            $params['status'] = $filter_data['filter_status'];
        }
        
        $orders = HepsiburadaHelper::getOrders($settings, $params);
        
        if (empty($orders) || !isset($orders['orders'])) {
            $this->writeLog('SISTEM', 'SIPARIS_CEK', 'Sipariş bulunamadı veya API hatası.');
            return array();
        }
        
        // Veritabanına kaydet
        $count = 0;
        foreach ($orders['orders'] as $order) {
            $this->saveOrder($order);
            $count++;
        }
        
        $this->writeLog('SISTEM', 'SIPARIS_CEK', "Toplam $count sipariş veritabanına kaydedildi.");
        
        // Veritabanından filtreli siparişleri çek
        return $this->getOrdersFromDb($filter_data);
    }
    
    /**
     * Veritabanına sipariş kaydeder
     *
     * @param array $order Sipariş verisi
     * @return void
     */
    private function saveOrder($order) {
        // Sipariş zaten var mı kontrol et
        $query = $this->db->query("SELECT order_id FROM " . DB_PREFIX . "hepsiburada_order WHERE order_id = '" . $this->db->escape($order['orderId']) . "'");
        
        if ($query->num_rows > 0) {
            // Güncelle
            $this->db->query("UPDATE " . DB_PREFIX . "hepsiburada_order SET 
                customer = '" . $this->db->escape($order['customerName']) . "',
                status = '" . $this->db->escape($order['status']) . "',
                total = '" . (float)$order['totalPrice'] . "',
                date_added = '" . $this->db->escape($order['orderDate']) . "',
                date_modified = NOW()
                WHERE order_id = '" . $this->db->escape($order['orderId']) . "'");
            
            $this->writeLog('SISTEM', 'SIPARIS_GUNCELLE', 'Sipariş güncellendi: ' . $order['orderId']);
        } else {
            // Yeni ekle
            $this->db->query("INSERT INTO " . DB_PREFIX . "hepsiburada_order SET 
                order_id = '" . $this->db->escape($order['orderId']) . "',
                customer = '" . $this->db->escape($order['customerName']) . "',
                status = '" . $this->db->escape($order['status']) . "',
                total = '" . (float)$order['totalPrice'] . "',
                date_added = '" . $this->db->escape($order['orderDate']) . "',
                date_modified = NOW()");
            
            $hb_order_id = $this->db->getLastId();
            
            // Sipariş ürünlerini kaydet
            foreach ($order['items'] as $item) {
                $this->db->query("INSERT INTO " . DB_PREFIX . "hepsiburada_order_product SET 
                    hb_order_id = '" . (int)$hb_order_id . "',
                    product_id = '" . $this->db->escape($item['productId']) . "',
                    name = '" . $this->db->escape($item['productName']) . "',
                    model = '" . $this->db->escape($item['productCode'] ?? '') . "',
                    quantity = '" . (int)$item['quantity'] . "',
                    price = '" . (float)$item['price'] . "',
                    total = '" . (float)($item['price'] * $item['quantity']) . "'");
            }
            
            $this->writeLog('SISTEM', 'SIPARIS_EKLE', 'Yeni sipariş eklendi: ' . $order['orderId']);
        }
    }
    
    /**
     * Veritabanından siparişleri çeker
     *
     * @param array $filter_data Filtre parametreleri
     * @return array Siparişler
     */
    private function getOrdersFromDb($filter_data) {
        $sql = "SELECT * FROM " . DB_PREFIX . "hepsiburada_order WHERE 1";
        
        if (!empty($filter_data['filter_order_id'])) {
            $sql .= " AND order_id LIKE '%" . $this->db->escape($filter_data['filter_order_id']) . "%'";
        }
        
        if (!empty($filter_data['filter_customer'])) {
            $sql .= " AND customer LIKE '%" . $this->db->escape($filter_data['filter_customer']) . "%'";
        }
        
        if (!empty($filter_data['filter_status'])) {
            $sql .= " AND status = '" . $this->db->escape($filter_data['filter_status']) . "'";
        }
        
        if (!empty($filter_data['filter_date_start'])) {
            $sql .= " AND DATE(date_added) >= '" . $this->db->escape($filter_data['filter_date_start']) . "'";
        }
        
        if (!empty($filter_data['filter_date_end'])) {
            $sql .= " AND DATE(date_added) <= '" . $this->db->escape($filter_data['filter_date_end']) . "'";
        }
        
        $sort_data = array(
            'order_id',
            'customer',
            'status',
            'total',
            'date_added'
        );
        
        if (isset($filter_data['sort']) && in_array($filter_data['sort'], $sort_data)) {
            $sql .= " ORDER BY " . $filter_data['sort'];
        } else {
            $sql .= " ORDER BY date_added";
        }
        
        if (isset($filter_data['order']) && ($filter_data['order'] == 'DESC')) {
            $sql .= " DESC";
        } else {
            $sql .= " ASC";
        }
        
        if (isset($filter_data['start']) || isset($filter_data['limit'])) {
            if ($filter_data['start'] < 0) {
                $filter_data['start'] = 0;
            }
            
            if ($filter_data['limit'] < 1) {
                $filter_data['limit'] = 20;
            }
            
            $sql .= " LIMIT " . (int)$filter_data['start'] . "," . (int)$filter_data['limit'];
        }
        
        $query = $this->db->query($sql);
        
        return $query->rows;
    }
    
    /**
     * Veritabanındaki toplam sipariş sayısını döndürür
     *
     * @param array $filter_data Filtre parametreleri
     * @return int Toplam sipariş sayısı
     */
    public function getTotalOrders($filter_data) {
        $sql = "SELECT COUNT(*) AS total FROM " . DB_PREFIX . "hepsiburada_order WHERE 1";
        
        if (!empty($filter_data['filter_order_id'])) {
            $sql .= " AND order_id LIKE '%" . $this->db->escape($filter_data['filter_order_id']) . "%'";
        }
        
        if (!empty($filter_data['filter_customer'])) {
            $sql .= " AND customer LIKE '%" . $this->db->escape($filter_data['filter_customer']) . "%'";
        }
        
        if (!empty($filter_data['filter_status'])) {
            $sql .= " AND status = '" . $this->db->escape($filter_data['filter_status']) . "'";
        }
        
        if (!empty($filter_data['filter_date_start'])) {
            $sql .= " AND DATE(date_added) >= '" . $this->db->escape($filter_data['filter_date_start']) . "'";
        }
        
        if (!empty($filter_data['filter_date_end'])) {
            $sql .= " AND DATE(date_added) <= '" . $this->db->escape($filter_data['filter_date_end']) . "'";
        }
        
        $query = $this->db->query($sql);
        
        return $query->row['total'];
    }
    
    /**
     * Sipariş detayını veritabanından çeker
     *
     * @param string $order_id Sipariş ID
     * @return array Sipariş detayı
     */
    public function getOrder($order_id) {
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "hepsiburada_order WHERE order_id = '" . $this->db->escape($order_id) . "'");
        
        if ($query->num_rows) {
            $order_info = $query->row;
            
            // Sipariş ürünlerini al
            $order_products_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "hepsiburada_order_product WHERE hb_order_id = '" . (int)$order_info['hb_order_id'] . "'");
            
            $order_info['products'] = $order_products_query->rows;
            
            // Sipariş geçmişini al
            $order_history_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "hepsiburada_order_history WHERE hb_order_id = '" . (int)$order_info['hb_order_id'] . "' ORDER BY date_added DESC");
            
            $order_info['history'] = $order_history_query->rows;
            
            return $order_info;
        } else {
            // API'den sipariş detayını çek
            $username = $this->config->get('module_hepsiburada_username');
            $password = $this->config->get('module_hepsiburada_password');
            $merchant_id = $this->config->get('module_hepsiburada_merchant_id');
            
            require_once(DIR_SYSTEM . 'library/hepsiburada/hepsiburada_api.php');
            
            $settings = array(
                'username' => $username,
                'password' => $password,
                'merchant_id' => $merchant_id
            );
            
            $order_detail = HepsiburadaHelper::getOrderDetail($settings, $order_id);
            
            if ($order_detail) {
                $this->saveOrder($order_detail);
                return $this->getOrder($order_id);
            }
            
            return array();
        }
    }
    
    /**
     * Sipariş durumunu günceller
     *
     * @param string $order_id Sipariş ID
     * @param string $status Yeni durum
     * @param string $comment Yorum
     * @return bool Başarı durumu
     */
    public function updateOrderStatus($order_id, $status, $comment = '') {
        $order_info = $this->getOrder($order_id);
        
        if (!$order_info) {
            $this->writeLog('SISTEM', 'DURUM_GUNCELLEME_HATA', 'Sipariş bulunamadı: ' . $order_id);
            return false;
        }
        
        // API ile durumu güncelle
        $username = $this->config->get('module_hepsiburada_username');
        $password = $this->config->get('module_hepsiburada_password');
        $merchant_id = $this->config->get('module_hepsiburada_merchant_id');
        
        require_once(DIR_SYSTEM . 'library/hepsiburada/hepsiburada_api.php');
        
        $settings = array(
            'username' => $username,
            'password' => $password,
            'merchant_id' => $merchant_id
        );
        
        $result = HepsiburadaHelper::updateOrderStatus($settings, $order_id, $status);
        
        if ($result) {
            // Veritabanını güncelle
            $this->db->query("UPDATE " . DB_PREFIX . "hepsiburada_order SET 
                status = '" . $this->db->escape($status) . "',
                date_modified = NOW()
                WHERE order_id = '" . $this->db->escape($order_id) . "'");
            
            // Sipariş geçmişine ekle
            $this->db->query("INSERT INTO " . DB_PREFIX . "hepsiburada_order_history SET 
                hb_order_id = '" . (int)$order_info['hb_order_id'] . "',
                status = '" . $this->db->escape($status) . "',
                comment = '" . $this->db->escape($comment) . "',
                date_added = NOW()");
            
            $this->writeLog('SISTEM', 'DURUM_GUNCELLEME', 'Sipariş durumu güncellendi: ' . $order_id . ' -> ' . $status);
            
            return true;
        } else {
            $this->writeLog('SISTEM', 'DURUM_GUNCELLEME_HATA', 'API ile sipariş durumu güncellenemedi: ' . $order_id);
            return false;
        }
    }
    
    /**
     * OpenCart'a sipariş dönüştürür
     *
     * @param string $order_id Sipariş ID
     * @return int|bool OpenCart sipariş ID veya başarısızlık durumunda false
     */
    public function convertToOrder($order_id) {
        $order_info = $this->getOrder($order_id);
        
        if (!$order_info) {
            $this->writeLog('SISTEM', 'DONUSTURME_HATA', 'Sipariş bulunamadı: ' . $order_id);
            return false;
        }
        
        // OpenCart sipariş tablosuna ekle
        $this->load->model('customer/customer');
        $this->load->model('sale/order');
        
        // Müşteri var mı kontrol et
        $customer_info = $this->model_customer_customer->getCustomers(array(
            'filter_email' => 'hepsiburada_' . $order_id . '@example.com'
        ));
        
        $customer_id = 0;
        
        if (empty($customer_info)) {
            // Müşteri oluştur
            $customer_data = array(
                'firstname' => $order_info['customer'],
                'lastname' => 'Hepsiburada',
                'email' => 'hepsiburada_' . $order_id . '@example.com',
                'telephone' => '',
                'password' => 'hepsiburada123',
                'customer_group_id' => $this->config->get('config_customer_group_id'),
                'newsletter' => 0,
                'status' => 1,
                'approved' => 1
            );
            
            $customer_id = $this->model_customer_customer->addCustomer($customer_data);
        } else {
            $customer_id = $customer_info[0]['customer_id'];
        }
        
        // OpenCart sipariş verisi
        $opencart_order = array(
            'customer_id' => $customer_id,
            'firstname' => $order_info['customer'],
            'lastname' => 'Hepsiburada',
            'email' => 'hepsiburada_' . $order_id . '@example.com',
            'telephone' => '',
            'payment_firstname' => $order_info['customer'],
            'payment_lastname' => 'Hepsiburada',
            'payment_company' => 'Hepsiburada',
            'payment_address_1' => 'Hepsiburada',
            'payment_address_2' => '',
            'payment_city' => 'Istanbul',
            'payment_postcode' => '',
            'payment_country' => 'Türkiye',
            'payment_country_id' => 215,
            'payment_zone' => 'Istanbul',
            'payment_zone_id' => 3354,
            'payment_method' => 'Hepsiburada',
            'payment_code' => 'hepsiburada',
            'shipping_firstname' => $order_info['customer'],
            'shipping_lastname' => 'Hepsiburada',
            'shipping_company' => 'Hepsiburada',
            'shipping_address_1' => 'Hepsiburada',
            'shipping_address_2' => '',
            'shipping_city' => 'Istanbul',
            'shipping_postcode' => '',
            'shipping_country' => 'Türkiye',
            'shipping_country_id' => 215,
            'shipping_zone' => 'Istanbul',
            'shipping_zone_id' => 3354,
            'shipping_method' => 'Hepsiburada',
            'shipping_code' => 'hepsiburada',
            'comment' => 'Hepsiburada Sipariş: ' . $order_id,
            'total' => $order_info['total'],
            'order_status_id' => 1, // Beklemede
            'language_id' => $this->config->get('config_language_id'),
            'currency_id' => $this->currency->getId('TRY'),
            'currency_code' => 'TRY',
            'currency_value' => 1.0,
            'ip' => $this->request->server['REMOTE_ADDR'],
            'forwarded_ip' => '',
            'user_agent' => $this->request->server['HTTP_USER_AGENT'],
            'accept_language' => $this->request->server['HTTP_ACCEPT_LANGUAGE'],
            'products' => array(),
            'vouchers' => array(),
            'totals' => array()
        );
        
        // Ürünleri ekle
        foreach ($order_info['products'] as $product) {
            $opencart_order['products'][] = array(
                'product_id' => 0, // OpenCart ürün ID'si ile eşleştirme gerekecek
                'name' => $product['name'],
                'model' => $product['model'],
                'quantity' => $product['quantity'],
                'price' => $product['price'],
                'total' => $product['total'],
                'tax' => 0,
                'reward' => 0
            );
        }
        
        // Toplam bilgilerini ekle
        $opencart_order['totals'] = array(
            array(
                'code' => 'sub_total',
                'title' => 'Sub-Total',
                'value' => $order_info['total'],
                'sort_order' => 1
            ),
            array(
                'code' => 'total',
                'title' => 'Total',
                'value' => $order_info['total'],
                'sort_order' => 9
            )
        );
        
        // OpenCart siparişi oluştur
        $opencart_order_id = $this->model_sale_order->addOrder($opencart_order);
        
        if ($opencart_order_id) {
            // Hepsiburada siparişi ile ilişkilendir
            $this->db->query("UPDATE " . DB_PREFIX . "hepsiburada_order SET 
                opencart_order_id = '" . (int)$opencart_order_id . "'
                WHERE order_id = '" . $this->db->escape($order_id) . "'");
            
            $this->writeLog('SISTEM', 'DONUSTURME', 'Sipariş OpenCart\'a dönüştürüldü: ' . $order_id . ' -> ' . $opencart_order_id);
            
            return $opencart_order_id;
        } else {
            $this->writeLog('SISTEM', 'DONUSTURME_HATA', 'Sipariş dönüştürülemedi: ' . $order_id);
            return false;
        }
    }
    
    /**
     * Ürünleri senkronize eder
     *
     * @return int Senkronize edilen ürün sayısı
     */
    public function syncProducts() {
        $this->load->model('catalog/product');
        
        $products = $this->model_catalog_product->getProducts();
        
        $username = $this->config->get('module_hepsiburada_username');
        $password = $this->config->get('module_hepsiburada_password');
        $merchant_id = $this->config->get('module_hepsiburada_merchant_id');
        
        require_once(DIR_SYSTEM . 'library/hepsiburada/hepsiburada_api.php');
        
        $settings = array(
            'username' => $username,
            'password' => $password,
            'merchant_id' => $merchant_id
        );
        
        $count = 0;
        
        foreach ($products as $product) {
            $result = HepsiburadaHelper::sendProduct($settings, $product);
            
            if ($result) {
                $count++;
            }
        }
        
        $this->writeLog('SISTEM', 'URUN_SYNC', 'Ürünler senkronize edildi: ' . $count . ' adet');
        
        return $count;
    }
    
    /**
     * Stok bilgilerini günceller
     *
     * @return int Güncellenen ürün sayısı
     */
    public function updateStock() {
        $this->load->model('catalog/product');
        
        $products = $this->model_catalog_product->getProducts();
        
        $username = $this->config->get('module_hepsiburada_username');
        $password = $this->config->get('module_hepsiburada_password');
        $merchant_id = $this->config->get('module_hepsiburada_merchant_id');
        
        require_once(DIR_SYSTEM . 'library/hepsiburada/hepsiburada_api.php');
        
        $settings = array(
            'username' => $username,
            'password' => $password,
            'merchant_id' => $merchant_id
        );
        
        $count = 0;
        
        foreach ($products as $product) {
            $inventory = array(
                'productCode' => $product['model'],
                'quantity' => $product['quantity']
            );
            
            $result = HepsiburadaHelper::updateInventory($settings, $inventory);
            
            if ($result) {
                $count++;
            }
        }
        
        $this->writeLog('SISTEM', 'STOK_GUNCELLE', 'Stok bilgileri güncellendi: ' . $count . ' adet');
        
        return $count;
    }
    
    /**
     * Fiyat bilgilerini günceller
     *
     * @return int Güncellenen ürün sayısı
     */
    public function updatePrices() {
        $this->load->model('catalog/product');
        
        $products = $this->model_catalog_product->getProducts();
        
        $username = $this->config->get('module_hepsiburada_username');
        $password = $this->config->get('module_hepsiburada_password');
        $merchant_id = $this->config->get('module_hepsiburada_merchant_id');
        
        require_once(DIR_SYSTEM . 'library/hepsiburada/hepsiburada_api.php');
        
        $settings = array(
            'username' => $username,
            'password' => $password,
            'merchant_id' => $merchant_id
        );
        
        $count = 0;
        
        foreach ($products as $product) {
            $pricing = array(
                'productCode' => $product['model'],
                'price' => $product['price'],
                'discountedPrice' => $product['special'] ? $product['special'] : $product['price']
            );
            
            $result = HepsiburadaHelper::updatePricing($settings, $pricing);
            
            if ($result) {
                $count++;
            }
        }
        
        $this->writeLog('SISTEM', 'FIYAT_GUNCELLE', 'Fiyat bilgileri güncellendi: ' . $count . ' adet');
        
        return $count;
    }
    
    /**
     * Veritabanı tablolarını oluşturur
     *
     * @return void
     */
    public function createTables() {
        // Hepsiburada siparişleri tablosu
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "hepsiburada_order` (
                `hb_order_id` INT(11) NOT NULL AUTO_INCREMENT,
                `order_id` VARCHAR(64) NOT NULL,
                `opencart_order_id` INT(11) DEFAULT NULL,
                `customer` VARCHAR(128) NOT NULL,
                `status` VARCHAR(32) NOT NULL,
                `total` DECIMAL(15,4) NOT NULL DEFAULT '0.0000',
                `date_added` DATETIME NOT NULL,
                `date_modified` DATETIME NOT NULL,
                PRIMARY KEY (`hb_order_id`),
                KEY `order_id` (`order_id`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");
        
        // Hepsiburada sipariş ürünleri tablosu
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "hepsiburada_order_product` (
                `hb_order_product_id` INT(11) NOT NULL AUTO_INCREMENT,
                `hb_order_id` INT(11) NOT NULL,
                `product_id` VARCHAR(64) NOT NULL,
                `name` VARCHAR(255) NOT NULL,
                `model` VARCHAR(64) NOT NULL,
                `quantity` INT(4) NOT NULL,
                `price` DECIMAL(15,4) NOT NULL DEFAULT '0.0000',
                `total` DECIMAL(15,4) NOT NULL DEFAULT '0.0000',
                PRIMARY KEY (`hb_order_product_id`),
                KEY `hb_order_id` (`hb_order_id`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");
        
        // Hepsiburada sipariş geçmişi tablosu
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "hepsiburada_order_history` (
                `hb_order_history_id` INT(11) NOT NULL AUTO_INCREMENT,
                `hb_order_id` INT(11) NOT NULL,
                `status` VARCHAR(32) NOT NULL,
                `comment` TEXT NOT NULL,
                `date_added` DATETIME NOT NULL,
                PRIMARY KEY (`hb_order_history_id`),
                KEY `hb_order_id` (`hb_order_id`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");
        
        $this->writeLog('SISTEM', 'TABLO_OLUSTUR', 'Veritabanı tabloları oluşturuldu.');
    }
    
    /**
     * Veritabanı tablolarını siler
     *
     * @return void
     */
    public function dropTables() {
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "hepsiburada_order_history`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "hepsiburada_order_product`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "hepsiburada_order`");
        
        $this->writeLog('SISTEM', 'TABLO_SIL', 'Veritabanı tabloları silindi.');
    }
} 