<?php
/**
 * amazon.php
 *
 * Amaç: Amazon modülünün OpenCart yönetici paneli (admin) tarafındaki controller dosyasıdır.
 *
 * Loglama: Tüm önemli işlemler ve hatalar amazon_controller.log dosyasına kaydedilmelidir.
 * Log formatı: [YYYY-MM-DD HH:MM:SS] [KULLANICI/ROL] [İŞLEM] [AÇIKLAMA]
 *
 * Hata yönetimi: Hatalar loglanmalı ve kullanıcıya açıklayıcı mesaj gösterilmelidir.
 */
// Amazon modülünün OpenCart admin tarafındaki controller dosyası

class ControllerExtensionModuleAmazon extends Controller {
    private $error = array();

    public function index() {
        $this->load->language('extension/module/amazon');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('module_amazon', $this->request->post);
            $this->writeLog('admin', 'AYAR_GUNCELLEME', 'Amazon ayarları güncellendi.');
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('extension/module/amazon', 'user_token=' . $this->session->data['user_token'], true));
        }

        $data['heading_title'] = $this->language->get('heading_title');
        $data['action'] = $this->url->link('extension/module/amazon', 'user_token=' . $this->session->data['user_token'], true);
        $data['cancel'] = $this->url->link('extension/module/amazon', 'user_token=' . $this->session->data['user_token'], true);
        
        // API Key field
        if (isset($this->request->post['module_amazon_api_key'])) {
            $data['module_amazon_api_key'] = $this->request->post['module_amazon_api_key'];
        } else {
            $data['module_amazon_api_key'] = $this->config->get('module_amazon_api_key');
        }
        
        // API Secret field
        if (isset($this->request->post['module_amazon_api_secret'])) {
            $data['module_amazon_api_secret'] = $this->request->post['module_amazon_api_secret'];
        } else {
            $data['module_amazon_api_secret'] = $this->config->get('module_amazon_api_secret');
        }
        
        // Refresh Token field
        if (isset($this->request->post['module_amazon_refresh_token'])) {
            $data['module_amazon_refresh_token'] = $this->request->post['module_amazon_refresh_token'];
        } else {
            $data['module_amazon_refresh_token'] = $this->config->get('module_amazon_refresh_token');
        }
        
        // Seller ID field
        if (isset($this->request->post['module_amazon_seller_id'])) {
            $data['module_amazon_seller_id'] = $this->request->post['module_amazon_seller_id'];
        } else {
            $data['module_amazon_seller_id'] = $this->config->get('module_amazon_seller_id');
        }
        
        // Marketplace ID field
        if (isset($this->request->post['module_amazon_marketplace_id'])) {
            $data['module_amazon_marketplace_id'] = $this->request->post['module_amazon_marketplace_id'];
        } else {
            $data['module_amazon_marketplace_id'] = $this->config->get('module_amazon_marketplace_id');
        }
        
        // Region field
        if (isset($this->request->post['module_amazon_region'])) {
            $data['module_amazon_region'] = $this->request->post['module_amazon_region'];
        } else {
            $data['module_amazon_region'] = $this->config->get('module_amazon_region') ? $this->config->get('module_amazon_region') : 'eu';
        }
        
        // Status field
        if (isset($this->request->post['module_amazon_status'])) {
            $data['module_amazon_status'] = $this->request->post['module_amazon_status'];
        } else {
            $data['module_amazon_status'] = $this->config->get('module_amazon_status');
        }
        
        // Error messages
        $data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';
        
        // Success message
        $data['success'] = isset($this->session->data['success']) ? $this->session->data['success'] : '';
        unset($this->session->data['success']);
        
        // Breadcrumbs
        $data['breadcrumbs'] = array();
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/amazon', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        // Load header, column and footer
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('extension/module/amazon', $data));
    }
    
    /**
     * Amazon Dashboardu
     */
    public function dashboard() {
        $this->load->language('extension/module/amazon');
        $this->document->setTitle($this->language->get('heading_title') . ' - Dashboard');
        
        // Breadcrumbs
        $data['breadcrumbs'] = array();
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/amazon', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => 'Dashboard',
            'href' => $this->url->link('extension/module/amazon/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        // Aksiyon URL'leri
        $data['settings_url'] = $this->url->link('extension/module/amazon', 'user_token=' . $this->session->data['user_token'], true);
        $data['dashboard_url'] = $this->url->link('extension/module/amazon/dashboard', 'user_token=' . $this->session->data['user_token'], true);
        
        // Load header, column and footer
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('extension/module/amazon_dashboard', $data));
    }

    public function install() {
        // Yetkilendirme
        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/amazon');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/module/amazon');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/amazon/dashboard');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/module/amazon/dashboard');
        
        $this->writeLog('admin', 'KURULUM', 'Amazon modülü kuruldu.');
    }

    public function uninstall() {
        $this->writeLog('admin', 'KALDIRMA', 'Amazon modülü kaldırıldı.');
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/amazon')) {
            $this->error['warning'] = $this->language->get('error_permission');
            $this->writeLog('admin', 'HATA', 'İzin yok.');
            return false;
        }
        return true;
    }

    private function writeLog($user, $action, $message) {
        $log_file = DIR_LOGS . 'amazon_controller.log';
        $date = date('Y-m-d H:i:s');
        $log = "[$date] [$user] [$action] $message\n";
        file_put_contents($log_file, $log, FILE_APPEND);
    }
    
    /**
     * API Bağlantısını test eder
     */
    public function test_connection() {
        $this->load->language('extension/module/amazon');
        
        $json = array();
        
        if (!$this->user->hasPermission('modify', 'extension/module/amazon')) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            // Ayarları al
            $api_key = isset($this->request->post['module_amazon_api_key']) ? $this->request->post['module_amazon_api_key'] : $this->config->get('module_amazon_api_key');
            $api_secret = isset($this->request->post['module_amazon_api_secret']) ? $this->request->post['module_amazon_api_secret'] : $this->config->get('module_amazon_api_secret');
            $region = isset($this->request->post['module_amazon_region']) ? $this->request->post['module_amazon_region'] : $this->config->get('module_amazon_region');
            
            if (empty($api_key) || empty($api_secret)) {
                $json['error'] = 'API Key ve API Secret değerleri gereklidir!';
            } else {
                // Helper dosyasını yükle
                require_once(DIR_SYSTEM . '../admin/controller/extension/module/amazon_helper.php');
                
                // Bağlantıyı test et
                $result = amazon_baglan($api_key, $api_secret, $region);
                
                if ($result) {
                    $json['success'] = 'Amazon API bağlantısı başarılı!';
                    $this->writeLog('admin', 'API_TEST', 'Amazon API bağlantı testi başarılı.');
                } else {
                    $json['error'] = 'Amazon API bağlantısı başarısız! Ayarları kontrol edin.';
                    $this->writeLog('admin', 'API_TEST', 'Amazon API bağlantı testi başarısız.');
                }
            }
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    /**
     * İstatistikleri getirir
     */
    public function get_stats() {
        $this->load->language('extension/module/amazon');
        
        $json = array();
        
        if (!$this->user->hasPermission('access', 'extension/module/amazon')) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            // Örnek istatistikler (gerçek API entegrasyonu yapılmalı)
            $json['today_orders'] = rand(0, 10);
            $json['month_orders'] = rand(10, 100);
            $json['today_sales'] = '€' . number_format(rand(100, 1000), 2);
            $json['month_sales'] = '€' . number_format(rand(1000, 10000), 2);
            $json['active_products'] = rand(10, 100);
            $json['inactive_products'] = rand(0, 10);
            $json['in_stock'] = rand(10, 100);
            $json['out_of_stock'] = rand(0, 10);
            
            // Örnek siparişler
            $json['orders'] = array();
            for ($i = 1; $i <= 5; $i++) {
                $json['orders'][] = array(
                    'order_id' => 'AMZ-' . rand(10000, 99999),
                    'date_added' => date('Y-m-d H:i:s', strtotime('-' . $i . ' day')),
                    'customer' => 'Müşteri ' . $i,
                    'status' => (rand(0, 1) == 1) ? 'Tamamlandı' : 'İşlemde',
                    'total' => '€' . number_format(rand(50, 500), 2),
                    'view' => $this->url->link('extension/module/amazon/view_order', 'user_token=' . $this->session->data['user_token'] . '&order_id=AMZ-' . rand(10000, 99999), true)
                );
            }
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    /**
     * Sipariş senkronizasyon metodu
     */
    public function sync_orders() {
        $this->load->language('extension/module/amazon');
        
        $json = array();
        
        if (!$this->user->hasPermission('modify', 'extension/module/amazon')) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            // Gerçek API entegrasyonu burada yapılacak
            $json['success'] = 'Siparişler başarıyla senkronize edildi.';
            $this->writeLog('admin', 'SYNC', 'Siparişler senkronize edildi.');
            
            // İstatistikleri getir
            $json['today_orders'] = rand(5, 15);
            $json['month_orders'] = rand(30, 120);
            $json['today_sales'] = '€' . number_format(rand(200, 1500), 2);
            $json['month_sales'] = '€' . number_format(rand(1500, 15000), 2);
            
            // Örnek siparişler
            $json['orders'] = array();
            for ($i = 1; $i <= 5; $i++) {
                $json['orders'][] = array(
                    'order_id' => 'AMZ-' . rand(10000, 99999),
                    'date_added' => date('Y-m-d H:i:s', strtotime('-' . rand(0, 3) . ' day')),
                    'customer' => 'Müşteri ' . rand(1, 100),
                    'status' => (rand(0, 1) == 1) ? 'Tamamlandı' : 'İşlemde',
                    'total' => '€' . number_format(rand(50, 500), 2),
                    'view' => $this->url->link('extension/module/amazon/view_order', 'user_token=' . $this->session->data['user_token'] . '&order_id=AMZ-' . rand(10000, 99999), true)
                );
            }
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    /**
     * Ürün senkronizasyon metodu
     */
    public function sync_products() {
        $this->load->language('extension/module/amazon');
        
        $json = array();
        
        if (!$this->user->hasPermission('modify', 'extension/module/amazon')) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            // Gerçek API entegrasyonu burada yapılacak
            $json['success'] = 'Ürünler başarıyla senkronize edildi.';
            $this->writeLog('admin', 'SYNC', 'Ürünler senkronize edildi.');
            
            // İstatistikleri getir
            $json['active_products'] = rand(20, 150);
            $json['inactive_products'] = rand(0, 20);
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    /**
     * Stok senkronizasyon metodu
     */
    public function sync_inventory() {
        $this->load->language('extension/module/amazon');
        
        $json = array();
        
        if (!$this->user->hasPermission('modify', 'extension/module/amazon')) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            // Gerçek API entegrasyonu burada yapılacak
            $json['success'] = 'Stok bilgileri başarıyla senkronize edildi.';
            $this->writeLog('admin', 'SYNC', 'Stok bilgileri senkronize edildi.');
            
            // İstatistikleri getir
            $json['in_stock'] = rand(20, 150);
            $json['out_of_stock'] = rand(0, 15);
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    /**
     * Tüm verileri senkronize eder
     */
    public function sync_all() {
        $this->load->language('extension/module/amazon');
        
        $json = array();
        
        if (!$this->user->hasPermission('modify', 'extension/module/amazon')) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            // Gerçek API entegrasyonu burada yapılacak
            $json['success'] = 'Tüm veriler başarıyla senkronize edildi.';
            $this->writeLog('admin', 'SYNC', 'Tüm veriler senkronize edildi.');
            
            // İstatistikleri getir
            $json['today_orders'] = rand(5, 15);
            $json['month_orders'] = rand(30, 120);
            $json['today_sales'] = '€' . number_format(rand(200, 1500), 2);
            $json['month_sales'] = '€' . number_format(rand(1500, 15000), 2);
            $json['active_products'] = rand(20, 150);
            $json['inactive_products'] = rand(0, 20);
            $json['in_stock'] = rand(20, 150);
            $json['out_of_stock'] = rand(0, 15);
            
            // Örnek siparişler
            $json['orders'] = array();
            for ($i = 1; $i <= 5; $i++) {
                $json['orders'][] = array(
                    'order_id' => 'AMZ-' . rand(10000, 99999),
                    'date_added' => date('Y-m-d H:i:s', strtotime('-' . rand(0, 5) . ' day')),
                    'customer' => 'Müşteri ' . rand(1, 100),
                    'status' => (rand(0, 1) == 1) ? 'Tamamlandı' : 'İşlemde',
                    'total' => '€' . number_format(rand(50, 500), 2),
                    'view' => $this->url->link('extension/module/amazon/view_order', 'user_token=' . $this->session->data['user_token'] . '&order_id=AMZ-' . rand(10000, 99999), true)
                );
            }
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
}

// ... OpenCart controller fonksiyonları buraya eklenecek ... 