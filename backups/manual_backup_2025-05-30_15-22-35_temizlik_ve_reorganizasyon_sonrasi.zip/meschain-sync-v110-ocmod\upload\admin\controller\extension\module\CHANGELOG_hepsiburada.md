# CHANGELOG (hepsiburada)

## 2025-05-29
- Hepsiburada modülü için OpenCart şablon dosyaları oluşturuldu.
- Loglama ve hata yönetimi standartları uygulandı. 