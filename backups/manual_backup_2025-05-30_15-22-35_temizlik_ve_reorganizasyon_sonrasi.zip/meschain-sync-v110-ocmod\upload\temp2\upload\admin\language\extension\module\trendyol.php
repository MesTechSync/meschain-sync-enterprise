<?php
$_['heading_title'] = 'Trendyol Paneli';
$_['text_success'] = 'Ayarlar başarıyla kaydedildi!';
$_['error_permission'] = 'Bu modülü değiştirmek için izniniz yok!'; 