<?php
// Başlık
$_['heading_title']          = 'MesChain Sync - Pazaryeri Entegrasyonu';

// Metin
$_['text_step_1']            = 'Veritabanı tablolarını oluştur';
$_['text_step_2']            = 'Modül dosyalarını kopyala';
$_['text_step_3']            = 'İzinleri ayarla';
$_['text_step_4']            = 'Kurulumu tamamla';
$_['text_install']           = 'Kur';
$_['text_upgrade']           = 'Güncelle';
$_['text_success']           = 'Başarılı! MesChain Sync modülü kuruldu.';
$_['text_success_install']   = 'Başarılı! MesChain Sync modülü başarıyla kuruldu.';
$_['text_success_upgrade']   = 'Başarılı! MesChain Sync modülü başarıyla güncellendi.';

// Buton
$_['button_continue']        = 'Devam Et';
$_['button_back']            = 'Geri'; 