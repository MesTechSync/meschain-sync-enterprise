<?php
/**
 * trendyol.php
 *
 * Amaç: Trendyol modülünün OpenCart yönetici paneli (admin) tarafındaki controller dosyasıdır.
 *
 * Loglama: Tüm önemli işlemler ve hatalar hem trendyol_controller.log hem de trendyol_helper.log dosyasına kaydedilir.
 * Log formatı: [YYYY-MM-DD HH:MM:SS] [KULLANICI/ROL] [İŞLEM] [AÇIKLAMA]
 *
 * Hata yönetimi: Hatalar loglanmalı ve kullanıcıya açıklayıcı mesaj gösterilmelidir.
 *
 * Geliştirici: Kodun her fonksiyonunda açıklama ve log şablonu bulunmalıdır.
 */
// Trendyol modülünün OpenCart admin tarafındaki controller dosyası

class ControllerExtensionModuleTrendyol extends Controller {
    private $error = array();

    /**
     * Oturum güvenliği ve kullanıcı bilgisi kontrolü
     * Her panel yüklemesinde çağrılır. Hatalar loglanır.
     */
    private function sessionSecurity() {
        $now = time();
        $timeout = 60*60; // 60 dakika
        if (isset($this->session->data['last_activity']) && ($now - $this->session->data['last_activity'] > $timeout)) {
            $this->writeLog('system', 'SESSION_TIMEOUT', 'Oturum zaman aşımı.');
            $this->session->data = array();
            $this->response->redirect($this->url->link('common/login', '', true));
        }
        $this->session->data['last_activity'] = $now;
        $ip = $this->request->server['REMOTE_ADDR'] ?? '';
        $ua = substr($this->request->server['HTTP_USER_AGENT'] ?? '', 0, 32);
        if (!isset($this->session->data['ip'])) $this->session->data['ip'] = $ip;
        if (!isset($this->session->data['ua'])) $this->session->data['ua'] = $ua;
        if ($this->session->data['ip'] !== $ip || $this->session->data['ua'] !== $ua) {
            $this->writeLog('system', 'SESSION_HIJACK', 'IP veya User-Agent değişikliği.');
            $this->session->data = array();
            $this->response->redirect($this->url->link('common/login', '', true));
        }
    }

    /**
     * Kullanıcıya özel Trendyol ayarlarını yükle
     * @return array
     */
    private function getUserSettings($username) {
        $settingsFile = DIR_LOGS . 'trendyol_settings_' . $username . '.json';
        if (file_exists($settingsFile)) {
            $settings = json_decode(file_get_contents($settingsFile), true);
            if (is_array($settings)) return $settings;
        }
        return [
            'api_key' => '',
            'api_secret' => '',
            'token' => '',
            'cari_id' => '',
            'entegrasyon_ref' => ''
        ];
    }
    /**
     * Kullanıcıya özel Trendyol ayarlarını kaydet
     * @param string $username
     * @param array $settings
     */
    private function saveUserSettings($username, $settings) {
        $settingsFile = DIR_LOGS . 'trendyol_settings_' . $username . '.json';
        file_put_contents($settingsFile, json_encode($settings, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    }
    /**
     * Gizli anahtarları maskele
     */
    private function mask_secret($v) {
        $v = $this->decode_secret($v);
        if (strlen($v) <= 6) return str_repeat('*', strlen($v));
        return substr($v,0,3) . str_repeat('*', max(0,strlen($v)-6)) . substr($v,-3);
    }

    /**
     * OpenCart user_group_id -> role mapping
     */
    private function getRoleByGroupId($group_id) {
        // Mapping örneği, gerekirse özelleştirilebilir
        $map = [
            1 => 'süper_admin', // OpenCart default admin
            2 => 'admin',
            3 => 'bayi',
            4 => 'teknik',
            5 => 'muhasebe',
            6 => 'destek',
        ];
        return $map[$group_id] ?? 'kullanici';
    }
    /**
     * Rol ve yetki bilgilerini döndür (orjinal roles.json'dan alınan şablon)
     */
    private function getRoleData($role) {
        $roles = [
            'süper_admin' => [
                'can_manage_users' => true,
                'can_upload_modules' => true,
                'can_view_logs' => true,
                'can_edit_settings' => true,
                'modules' => ['*'],
                'trendyol_read' => true,
                'trendyol_write' => true,
                'finance_report' => true,
                'color' => '#8e44ad',
                'icon' => '👑',
                'theme' => 'default',
                'label' => 'Süper Admin',
            ],
            'admin' => [
                'can_manage_users' => true,
                'can_upload_modules' => true,
                'can_view_logs' => true,
                'can_edit_settings' => true,
                'modules' => ['*'],
                'trendyol_read' => true,
                'trendyol_write' => true,
                'finance_report' => true,
                'color' => '#e74c3c',
                'icon' => '🛡️',
                'theme' => 'default',
                'label' => 'Admin',
            ],
            'bayi' => [
                'can_manage_users' => false,
                'can_upload_modules' => false,
                'can_view_logs' => true,
                'can_edit_settings' => true,
                'modules' => ['trendyol', 'n11'],
                'trendyol_read' => true,
                'trendyol_write' => false,
                'finance_report' => false,
                'color' => '#3a8fd8',
                'icon' => '🏪',
                'theme' => 'default',
                'label' => 'Bayi',
            ],
            'teknik' => [
                'can_manage_users' => false,
                'can_upload_modules' => false,
                'can_view_logs' => true,
                'can_edit_settings' => false,
                'modules' => ['trendyol'],
                'trendyol_read' => true,
                'trendyol_write' => true,
                'finance_report' => false,
                'color' => '#888',
                'icon' => '🛠️',
                'theme' => 'default',
                'label' => 'Teknik',
            ],
            'muhasebe' => [
                'can_manage_users' => false,
                'can_upload_modules' => false,
                'can_view_logs' => false,
                'can_edit_settings' => false,
                'modules' => ['finance'],
                'trendyol_read' => false,
                'trendyol_write' => false,
                'finance_report' => true,
                'color' => '#27ae60',
                'icon' => '💰',
                'theme' => 'default',
                'label' => 'Muhasebe',
            ],
            'destek' => [
                'can_manage_users' => false,
                'can_upload_modules' => false,
                'can_view_logs' => false,
                'can_edit_settings' => false,
                'modules' => [],
                'trendyol_read' => true,
                'trendyol_write' => false,
                'finance_report' => false,
                'color' => '#f1c40f',
                'icon' => '🎧',
                'theme' => 'default',
                'label' => 'Destek',
            ],
            'kullanici' => [
                'can_manage_users' => false,
                'can_upload_modules' => false,
                'can_view_logs' => false,
                'can_edit_settings' => false,
                'modules' => [],
                'trendyol_read' => true,
                'trendyol_write' => false,
                'finance_report' => false,
                'color' => '#bbb',
                'icon' => '👤',
                'theme' => 'default',
                'label' => 'Kullanıcı',
            ],
        ];
        return $roles[$role] ?? $roles['kullanici'];
    }

    /**
     * Kullanıcıya özel görevleri yükle
     */
    private function getUserTasks($username) {
        $file = DIR_LOGS . 'trendyol_tasks_' . $username . '.json';
        if (file_exists($file)) {
            $tasks = json_decode(file_get_contents($file), true);
            if (is_array($tasks)) return $tasks;
        }
        return [];
    }
    /**
     * Kullanıcıya özel görevleri kaydet
     */
    private function saveUserTasks($username, $tasks) {
        $file = DIR_LOGS . 'trendyol_tasks_' . $username . '.json';
        file_put_contents($file, json_encode($tasks, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    }

    /**
     * Dashboard widget fonksiyonu
     * Kullanıcıya özel panel, tema ve API işlemleri. Tüm önemli işlemler loglanır.
     */
    public function dashboard() {
        $this->sessionSecurity();
        $this->load->language('extension/module/trendyol');
        
        $this->document->setTitle($this->language->get('heading_title'));
        
        $data['heading_title'] = $this->language->get('heading_title');
        
        $data['breadcrumbs'] = array();
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['test_connection'] = $this->url->link('extension/module/trendyol/test_connection', 'user_token=' . $this->session->data['user_token'], true);
        $data['sync_products'] = $this->url->link('extension/module/trendyol/sync_products', 'user_token=' . $this->session->data['user_token'], true);
        $data['get_orders'] = $this->url->link('extension/module/trendyol/get_orders', 'user_token=' . $this->session->data['user_token'], true);
        $data['update_stock'] = $this->url->link('extension/module/trendyol/update_stock', 'user_token=' . $this->session->data['user_token'], true);
        $data['update_prices'] = $this->url->link('extension/module/trendyol/update_prices', 'user_token=' . $this->session->data['user_token'], true);
        $data['settings'] = $this->url->link('extension/module/trendyol', 'user_token=' . $this->session->data['user_token'], true);
        $data['product_mapping_url'] = $this->url->link('extension/module/trendyol/product_mapping', 'user_token=' . $this->session->data['user_token'], true);
        
        // Get total products
        $this->load->model('catalog/product');
        $data['product_count'] = $this->model_catalog_product->getTotalProducts();
        
        // Get order count (placeholder for now)
        $data['order_count'] = 0;
        
        // Dashboard link urls
        $data['orders_url'] = $this->url->link('extension/module/trendyol/orders', 'user_token=' . $this->session->data['user_token'], true);
        $data['reports_url'] = $this->url->link('extension/module/trendyol/reports', 'user_token=' . $this->session->data['user_token'], true);
        $data['product_mapping_url'] = $this->url->link('extension/module/trendyol/product_mapping', 'user_token=' . $this->session->data['user_token'], true);
        
        // API bilgilerini view'a aktar
        $data['module_trendyol_api_key'] = $this->config->get('module_trendyol_api_key');
        $data['module_trendyol_api_secret'] = $this->mask_secret($this->config->get('module_trendyol_api_secret'));
        $data['module_trendyol_supplier_id'] = $this->config->get('module_trendyol_supplier_id');
        
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } elseif (isset($this->session->data['error_warning'])) {
            $data['error_warning'] = $this->session->data['error_warning'];
            unset($this->session->data['error_warning']);
            } else {
            $data['error_warning'] = '';
        }
        
        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }
        
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('extension/module/trendyol_dashboard', $data));
    }
    
    /**
     * API bağlantısını test etme metodu
     */
    public function test_connection() {
        $this->load->language('extension/module/trendyol');
        
        $json = array();
        
        if (isset($this->request->post['api_key']) && isset($this->request->post['api_secret']) && isset($this->request->post['supplier_id'])) {
            $api_key = $this->request->post['api_key'];
            $api_secret = $this->request->post['api_secret'];
            $supplier_id = $this->request->post['supplier_id'];
            } else {
            $api_key = $this->config->get('module_trendyol_api_key');
            $api_secret = $this->decode_secret($this->config->get('module_trendyol_api_secret'));
            $supplier_id = $this->config->get('module_trendyol_supplier_id');
        }
        
        try {
            // Doğru konumdaki helper sınıfını yükle
            require_once(DIR_SYSTEM . 'library/meschain/helper/trendyol_helper.php');
            
            // Yeni helper sınıfını kullan
            $trendyolHelper = new MeschainTrendyolHelper($api_key, $api_secret, $supplier_id);
            $result = $trendyolHelper->testConnection();
            
            if ($result) {
                $json['success'] = $this->language->get('text_test_success');
                $this->writeLog('admin', 'API_TEST', 'Trendyol API bağlantı testi başarılı.');
            } else {
                $json['error'] = $this->language->get('text_test_failed');
                $this->writeLog('admin', 'API_TEST', 'Trendyol API bağlantı testi başarısız.');
            }
        } catch (Exception $e) {
            $json['error'] = sprintf($this->language->get('text_test_error'), $e->getMessage());
            $this->writeLog('admin', 'API_TEST_HATA', 'Trendyol API bağlantı testi hatası: ' . $e->getMessage());
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    /**
     * Ürünleri Trendyol'a senkronize etme metodu
     */
    public function sync_products() {
        $this->load->language('extension/module/trendyol');
        
        if (!$this->validate()) {
            $this->session->data['error_warning'] = $this->language->get('error_permission');
            $this->response->redirect($this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        // Check API credentials
        if (!$this->config->get('module_trendyol_api_key') || !$this->config->get('module_trendyol_api_secret') || !$this->config->get('module_trendyol_supplier_id')) {
            $this->session->data['error_warning'] = $this->language->get('error_api_connect');
            $this->response->redirect($this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        // JSON response for AJAX
        $json = array();
        
        try {
            require_once(DIR_SYSTEM . 'helper/trendyol_helper.php');
            
            // Get OpenCart products
            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('catalog/manufacturer');
        $this->load->model('setting/setting');
            
            // Load mapping data
            $trendyol_product_mappings = $this->model_setting_setting->getSetting('trendyol_product_mapping');
            
            // Prepare API helper
            $helper = new TrendyolHelper(
                $this->config->get('module_trendyol_api_key'),
                $this->decode_secret($this->config->get('module_trendyol_api_secret')),
                $this->config->get('module_trendyol_supplier_id')
            );
            
            // Get selected products or all enabled products with mapping
            if (isset($this->request->post['selected']) && is_array($this->request->post['selected'])) {
                $product_ids = $this->request->post['selected'];
            } else {
                // Get all products that have mapping
                $filter_data = array(
                    'filter_status' => 1,
                    'start' => 0,
                    'limit' => 1000
                );
                
                $products = $this->model_catalog_product->getProducts($filter_data);
                $product_ids = array();
                
                foreach ($products as $product) {
                    // Only include products that have both category and brand mapped and status is active
                    $trendyol_category_id = isset($trendyol_product_mappings['trendyol_category_' . $product['product_id']]) ? 
                                           $trendyol_product_mappings['trendyol_category_' . $product['product_id']] : '';
                    
                    $trendyol_brand_id = isset($trendyol_product_mappings['trendyol_brand_' . $product['product_id']]) ? 
                                        $trendyol_product_mappings['trendyol_brand_' . $product['product_id']] : '';
                    
                    $trendyol_status = isset($trendyol_product_mappings['trendyol_status_' . $product['product_id']]) ? 
                                      $trendyol_product_mappings['trendyol_status_' . $product['product_id']] : 0;
                    
                    if ($trendyol_category_id && $trendyol_brand_id && $trendyol_status) {
                        $product_ids[] = $product['product_id'];
                    }
                }
            }
            
            $syncedCount = 0;
            $failedCount = 0;
            
            // Process each product
            foreach ($product_ids as $product_id) {
                $product = $this->model_catalog_product->getProduct($product_id);
                
                if ($product) {
                    // Get product's attributes
                    $product_attributes = $this->model_catalog_product->getProductAttributes($product_id);
                    
                    // Get product's images
                    $product_images = $this->model_catalog_product->getProductImages($product_id);
                    
                    // Get product's options
                    $product_options = $this->model_catalog_product->getProductOptions($product_id);
                    
                    // Get mapping data for this product
                    $trendyol_category_id = isset($trendyol_product_mappings['trendyol_category_' . $product_id]) ? 
                                          $trendyol_product_mappings['trendyol_category_' . $product_id] : '';
                    
                    $trendyol_brand_id = isset($trendyol_product_mappings['trendyol_brand_' . $product_id]) ? 
                                       $trendyol_product_mappings['trendyol_brand_' . $product_id] : '';
                    
                    // Skip if not mapped
                    if (!$trendyol_category_id || !$trendyol_brand_id) {
                        $failedCount++;
                        continue;
                    }
                    
                    // Prepare images
                    $images = array();
                    
                    // Add main image
                    if ($product['image']) {
                        $images[] = array(
                            'url' => HTTP_CATALOG . 'image/' . $product['image']
                        );
                    }
                    
                    // Add additional images
                    foreach ($product_images as $image) {
                        $images[] = array(
                            'url' => HTTP_CATALOG . 'image/' . $image['image']
                        );
                    }
                    
                    // Prepare attributes
                    $attributes = array();
                    
                    foreach ($product_attributes as $attribute_group) {
                        foreach ($attribute_group['attribute'] as $attribute) {
                            $attributes[] = array(
                                'attributeId' => 0, // Trendyol'un kendi attribute ID'si burada kullanılmalı
                                'attributeValueId' => 0, // Trendyol'un kendi attribute value ID'si burada kullanılmalı
                                'customAttributeValue' => $attribute['text']
                            );
                        }
                    }
                    
                    // Prepare variants if product has options
                    $variants = array();
                    
                    if (!empty($product_options)) {
                        // Product has variants, handle them
                        foreach ($product_options as $option) {
                            if ($option['type'] == 'select' || $option['type'] == 'radio' || $option['type'] == 'checkbox') {
                                foreach ($option['product_option_value'] as $option_value) {
                                    $variant = array(
                                        'barcode' => $product['model'] . '-' . $option_value['option_value_id'],
                                        'quantity' => $option_value['quantity'],
                                        'price' => $option_value['price'] > 0 ? $product['price'] + $option_value['price'] : $product['price'],
                                        'stockCode' => $product['model'] . '-' . $option_value['option_value_id'],
                                        'attributeId' => 0, // Trendyol'un kendi attribute ID'si burada kullanılmalı
                                        'attributeValueId' => 0 // Trendyol'un kendi attribute value ID'si burada kullanılmalı
                                    );
                                    
                                    $variants[] = $variant;
                                }
                            }
                        }
                    }
                    
                    // Prepare product data for Trendyol
                    $trendyol_product = array(
                        'barcode' => $product['model'],
                        'title' => $product['name'],
                        'productMainId' => 'OC' . $product['product_id'],
                        'brandId' => (int)$trendyol_brand_id,
                        'categoryId' => (int)$trendyol_category_id,
                        'quantity' => $product['quantity'],
                        'stockCode' => $product['model'],
                        'dimensionalWeight' => 1, // Örnek bir değer
                        'description' => $product['description'],
                        'currencyType' => 'TRY',
                        'listPrice' => $product['price'],
                        'salePrice' => $product['price'],
                        'vatRate' => 18, // Örnek bir değer
                        'cargoCompanyId' => 1, // Örnek bir değer
                        'images' => $images,
                        'attributes' => $attributes
                    );
                    
                    // Add variants if any
                    if (!empty($variants)) {
                        $trendyol_product['variants'] = $variants;
                    }
                    
                    // Send product to Trendyol
                    $result = $helper->sendProduct($trendyol_product);
                    
                    if ($result && isset($result['batchId'])) {
                        // Store the Trendyol product ID if returned
                        if (isset($result['productId'])) {
                            $trendyol_product_mappings['trendyol_product_id_' . $product_id] = $result['productId'];
                        }
                        
                        $syncedCount++;
            } else {
                        $failedCount++;
                    }
                }
            }
            
            // Save updated mapping data
            $this->model_setting_setting->editSetting('trendyol_product_mapping', $trendyol_product_mappings);
            
            // Return success message
            $json['success'] = sprintf($this->language->get('text_sync_success'), $syncedCount, $failedCount);
            $this->writeLog('admin', 'URUN_SYNC', sprintf('%d ürün başarıyla senkronize edildi, %d ürün başarısız.', $syncedCount, $failedCount));
            
        } catch (Exception $e) {
            $json['error'] = 'Ürün senkronizasyonu sırasında hata oluştu: ' . $e->getMessage();
            $this->writeLog('admin', 'URUN_SYNC_HATA', 'Ürün senkronizasyonu hatası: ' . $e->getMessage());
        }
        
        // Check if this is an AJAX request
        if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && $this->request->server['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') {
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
        } else {
            if (isset($json['error'])) {
                $this->session->data['error_warning'] = $json['error'];
            } else if (isset($json['success'])) {
                $this->session->data['success'] = $json['success'];
            }
            
                $this->response->redirect($this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true));
            }
        }
    
    /**
     * Siparişleri Trendyol'dan çekme metodu
     */
    public function get_orders() {
        $this->load->language('extension/module/trendyol');
        
        if (!$this->validate()) {
            $this->session->data['error_warning'] = $this->language->get('error_permission');
            $this->response->redirect($this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        // Check API credentials
        if (!$this->config->get('module_trendyol_api_key') || !$this->config->get('module_trendyol_api_secret') || !$this->config->get('module_trendyol_supplier_id')) {
            $this->session->data['error_warning'] = $this->language->get('error_api_connect');
            $this->response->redirect($this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        // JSON response for AJAX
        $json = array();
        
        try {
            // Doğru konumdaki helper sınıfını yükle
            require_once(DIR_SYSTEM . 'library/meschain/helper/trendyol_helper.php');
            
            // Yeni helper sınıfını kullan
            $trendyolHelper = new MeschainTrendyolHelper(
                $this->config->get('module_trendyol_api_key'),
                $this->decode_secret($this->config->get('module_trendyol_api_secret')),
                $this->config->get('module_trendyol_supplier_id')
            );
            
            // Get date range from request or use defaults (last 7 days)
            $startDate = isset($this->request->post['start_date']) ? $this->request->post['start_date'] : date('Y-m-d', strtotime('-7 days'));
            $endDate = isset($this->request->post['end_date']) ? $this->request->post['end_date'] : date('Y-m-d');
            
            // Get orders from Trendyol
            $orders = $trendyolHelper->getOrders($startDate, $endDate);
            
            if ($orders && isset($orders['content'])) {
                $importedCount = 0;
                
                // Process each order
                foreach ($orders['content'] as $order) {
                    // Check if order already exists in OpenCart
                    $trendyol_order_id = $order['id'];
                    $trendyol_order_number = $order['orderNumber'];
                    
                    $this->load->model('sale/order');
                    $existing_order = $this->model_sale_order->getOrdersByTrendyolOrderId($trendyol_order_id);
                    
                    if (empty($existing_order)) {
                        // Create a new OpenCart order from Trendyol order
                        $opencart_order_id = $this->createOrderFromTrendyol($order);
                        
                        if ($opencart_order_id) {
                            $importedCount++;
                            // Log success
                            $this->writeLog('admin', 'IMPORT_ORDER', 'Trendyol siparişi başarıyla içe aktarıldı: ' . $trendyol_order_number . ' -> OpenCart #' . $opencart_order_id);
            } else {
                            // Log error
                            $this->writeLog('admin', 'IMPORT_ERROR', 'Trendyol siparişi içe aktarılamadı: ' . $trendyol_order_number);
                        }
                    } else {
                        // Order already exists, just update status if needed
                        // This part can be implemented later
                    }
                }
                
                $json['success'] = sprintf($this->language->get('text_import_success'), $importedCount);
                $json['total'] = count($orders['content']);
                $json['imported'] = $importedCount;
                
                $this->writeLog('admin', 'IMPORT_ORDERS', 'Toplam ' . count($orders['content']) . ' sipariş bulundu, ' . $importedCount . ' sipariş içe aktarıldı.');
            } else {
                $json['error'] = $this->language->get('text_no_orders');
                $this->writeLog('admin', 'IMPORT_ORDERS', 'Hiç sipariş bulunamadı veya API hatası: ' . json_encode($orders));
            }
        } catch (Exception $e) {
            $json['error'] = sprintf($this->language->get('text_import_error'), $e->getMessage());
            $this->writeLog('admin', 'IMPORT_ERROR', 'Sipariş içe aktarma hatası: ' . $e->getMessage());
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    /**
     * Sipariş detayı sayfası
     */
    public function order_info() {
        $this->load->language('extension/module/trendyol');
        
        $this->document->setTitle($this->language->get('heading_title') . ' - ' . $this->language->get('text_order_detail'));
        
        // Validate
        if (!isset($this->request->get['order_id'])) {
            $this->session->data['error_warning'] = $this->language->get('error_order_not_found');
            $this->response->redirect($this->url->link('extension/module/trendyol/orders', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        $order_id = $this->request->get['order_id'];
        
        // Load model
        $this->load->model('extension/module/trendyol');
        $this->load->model('tool/image');
        
        // Get order details
        $order_info = $this->model_extension_module_trendyol->getOrder($order_id);
        
        if (!$order_info) {
            $this->session->data['error_warning'] = $this->language->get('error_order_not_found');
            $this->response->redirect($this->url->link('extension/module/trendyol/orders', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        // Get order products
        $order_products = $this->model_extension_module_trendyol->getOrderProducts($order_id);
        
        // Breadcrumbs
        $data['breadcrumbs'] = array();
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_orders'),
            'href' => $this->url->link('extension/module/trendyol/orders', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_order_detail'),
            'href' => $this->url->link('extension/module/trendyol/order_info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id, true)
        );
        
        // Check if converted to OpenCart
        $opencart_order_info = $this->model_extension_module_trendyol->getOpenCartOrderId($order_id);
        $opencart_order_id = $opencart_order_info ? $opencart_order_info['opencart_order_id'] : '';
        $opencart_order_url = $opencart_order_id ? $this->url->link('sale/order/info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $opencart_order_id, true) : '';
        
        // URLs
        $data['back'] = $this->url->link('extension/module/trendyol/orders', 'user_token=' . $this->session->data['user_token'], true);
        $data['convert_url'] = $this->url->link('extension/module/trendyol/convert_order', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id, true);
        
        // Order data
        $data['order'] = array(
            'order_id' => $order_info['order_id'],
            'order_number' => $order_info['order_number'],
            'date_added' => date($this->language->get('date_format_short'), strtotime($order_info['date_added'])),
            'status' => $this->getOrderStatusText($order_info['status']),
            'total' => $this->currency->format($order_info['total_price'], 'TRY'),
            'shipping_cost' => $this->currency->format($order_info['shipping_cost'], 'TRY'),
            'commission' => $this->currency->format($order_info['total_price'] * 0.12, 'TRY'), // %12 komisyon varsayımı
            'sub_total' => $this->currency->format($order_info['total_price'] - $order_info['shipping_cost'], 'TRY'),
            'customer_name' => $order_info['customer_name'],
            'customer_email' => $order_info['customer_email'],
            'customer_phone' => $order_info['customer_phone'],
            'shipping_address' => nl2br($order_info['shipping_address'] . "\n" . $order_info['shipping_district'] . "\n" . $order_info['shipping_city']),
            'opencart_order_id' => $opencart_order_id,
            'opencart_order_url' => $opencart_order_url,
            'products' => array()
        );
        
        // Order products
        foreach ($order_products as $product) {
            // Check for product image
            $this->load->model('catalog/product');
            $image = '';
            
            // Try to find product in OpenCart
            $opencart_product = $this->model_catalog_product->getProductByModel($product['barcode']);
            
            if ($opencart_product) {
                $image = $this->model_tool_image->resize($opencart_product['image'] ? $opencart_product['image'] : 'no_image.png', 50, 50);
            }
            
            $data['order']['products'][] = array(
                'name' => $product['name'],
                'barcode' => $product['barcode'],
                'quantity' => $product['quantity'],
                'price' => $this->currency->format($product['price'], 'TRY'),
                'total' => $this->currency->format($product['total'], 'TRY'),
                'image' => $image
            );
        }
        
        // Check for messages
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } elseif (isset($this->session->data['error_warning'])) {
            $data['error_warning'] = $this->session->data['error_warning'];
            unset($this->session->data['error_warning']);
        } else {
            $data['error_warning'] = '';
        }
        
        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];
        unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }
        
        // Common template
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('extension/module/trendyol_order_detail', $data));
    }
    
    /**
     * Stok güncelleme metodu
     */
    public function update_stock() {
        $this->load->language('extension/module/trendyol');
        
        if (!$this->validate()) {
            $this->session->data['error_warning'] = $this->language->get('error_permission');
                $this->response->redirect($this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true));
            }
        
        // Check API credentials
        if (!$this->config->get('module_trendyol_api_key') || !$this->config->get('module_trendyol_api_secret') || !$this->config->get('module_trendyol_supplier_id')) {
            $this->session->data['error_warning'] = $this->language->get('error_api_connect');
            $this->response->redirect($this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        // JSON response for AJAX
        $json = array();
        
        try {
            // Doğru konumdaki helper sınıfını yükle
            require_once(DIR_SYSTEM . 'library/meschain/helper/trendyol_helper.php');
            
            // Yeni helper sınıfını kullan
            $trendyolHelper = new MeschainTrendyolHelper(
                $this->config->get('module_trendyol_api_key'),
                $this->decode_secret($this->config->get('module_trendyol_api_secret')),
                $this->config->get('module_trendyol_supplier_id')
            );
            
            // Get OpenCart products with Trendyol mapping
            $this->load->model('catalog/product');
            $this->load->model('setting/setting');
            
            // Load Trendyol product mappings
            $trendyol_product_mappings = $this->model_setting_setting->getSetting('trendyol_product_mapping');
            
            // Get products to update (selected or all mapped)
            if (isset($this->request->post['selected']) && is_array($this->request->post['selected'])) {
                $product_ids = $this->request->post['selected'];
            } else {
                // Get all products that have mapping
                $filter_data = array(
                    'filter_status' => 1,
                    'start' => 0,
                    'limit' => 1000
                );
                
                $products = $this->model_catalog_product->getProducts($filter_data);
                $product_ids = array();
                
                foreach ($products as $product) {
                    // Only include products that are mapped to Trendyol
                    $trendyol_status = isset($trendyol_product_mappings['trendyol_status_' . $product['product_id']]) ? 
                                      $trendyol_product_mappings['trendyol_status_' . $product['product_id']] : 0;
                    
                    if ($trendyol_status) {
                        $product_ids[] = $product['product_id'];
                    }
                }
            }
            
            $updatedCount = 0;
            $failedCount = 0;
            
            // Process each product
            foreach ($product_ids as $product_id) {
                $product = $this->model_catalog_product->getProduct($product_id);
                
                if ($product) {
                    // Create stock update data
                    $stock_data = array(
                        'barcode' => $product['model'],
                        'quantity' => $product['quantity']
                    );
                    
                    // Update stock on Trendyol
                    $result = $trendyolHelper->updateStock($stock_data);
                    
                    if ($result) {
                        $updatedCount++;
                        $this->writeLog('admin', 'STOCK_UPDATE', 'Ürün stok bilgisi başarıyla güncellendi: ' . $product['model'] . ' -> ' . $product['quantity']);
                    } else {
                        $failedCount++;
                        $this->writeLog('admin', 'STOCK_UPDATE_ERROR', 'Ürün stok bilgisi güncellenemedi: ' . $product['model']);
                    }
                }
            }
            
            if ($updatedCount > 0) {
                $json['success'] = sprintf($this->language->get('text_stock_success'), $updatedCount);
            } else {
                $json['error'] = $this->language->get('text_stock_failed');
            }
            
            $json['total'] = count($product_ids);
            $json['updated'] = $updatedCount;
            $json['failed'] = $failedCount;
            
            $this->writeLog('admin', 'STOCK_UPDATE_SUMMARY', 'Toplam ' . count($product_ids) . ' ürün için stok güncelleme: ' . $updatedCount . ' başarılı, ' . $failedCount . ' başarısız.');
        } catch (Exception $e) {
            $json['error'] = sprintf($this->language->get('text_stock_error'), $e->getMessage());
            $this->writeLog('admin', 'STOCK_UPDATE_ERROR', 'Stok güncelleme hatası: ' . $e->getMessage());
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    /**
     * Ürün fiyatlarını Trendyol'a güncelleme metodu
     */
    public function update_prices() {
        $this->load->language('extension/module/trendyol');
        
        if (!$this->validate()) {
            $this->session->data['error_warning'] = $this->language->get('error_permission');
            $this->response->redirect($this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        // Check API credentials
        if (!$this->config->get('module_trendyol_api_key') || !$this->config->get('module_trendyol_api_secret') || !$this->config->get('module_trendyol_supplier_id')) {
            $this->session->data['error_warning'] = $this->language->get('error_api_connect');
            $this->response->redirect($this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        // JSON response for AJAX
        $json = array();
        
        try {
            // Doğru konumdaki helper sınıfını yükle
            require_once(DIR_SYSTEM . 'library/meschain/helper/trendyol_helper.php');
            
            // Yeni helper sınıfını kullan
            $trendyolHelper = new MeschainTrendyolHelper(
                $this->config->get('module_trendyol_api_key'),
                $this->decode_secret($this->config->get('module_trendyol_api_secret')),
                $this->config->get('module_trendyol_supplier_id')
            );
            
            // Get OpenCart products with Trendyol mapping
            $this->load->model('catalog/product');
            $this->load->model('setting/setting');
            
            // Load Trendyol product mappings
            $trendyol_product_mappings = $this->model_setting_setting->getSetting('trendyol_product_mapping');
            
            // Get products to update (selected or all mapped)
            if (isset($this->request->post['selected']) && is_array($this->request->post['selected'])) {
                $product_ids = $this->request->post['selected'];
            } else {
                // Get all products that have mapping
                $filter_data = array(
                    'filter_status' => 1,
                    'start' => 0,
                    'limit' => 1000
                );
                
                $products = $this->model_catalog_product->getProducts($filter_data);
                $product_ids = array();
                
                foreach ($products as $product) {
                    // Only include products that are mapped to Trendyol
                    $trendyol_status = isset($trendyol_product_mappings['trendyol_status_' . $product['product_id']]) ? 
                                      $trendyol_product_mappings['trendyol_status_' . $product['product_id']] : 0;
                    
                    if ($trendyol_status) {
                        $product_ids[] = $product['product_id'];
                    }
                }
            }
            
            $updatedCount = 0;
            $failedCount = 0;
            
            // Process each product
            foreach ($product_ids as $product_id) {
                $product = $this->model_catalog_product->getProduct($product_id);
                
                if ($product) {
                    // Fiyat bilgisini hazırla
                    $price_data = array(
                        'barcode' => $product['model'],
                        'price' => $product['price'],
                        'discountedPrice' => $product['special'] ? $product['special'] : $product['price']
                    );
                    
                    // Trendyol'a fiyat güncelleme
                    $result = $trendyolHelper->updatePrice($price_data);
                    
                    if ($result) {
                        $updatedCount++;
                        $this->writeLog('admin', 'PRICE_UPDATE', 'Ürün fiyat bilgisi başarıyla güncellendi: ' . $product['model'] . ' -> ' . $product['price']);
                    } else {
                        $failedCount++;
                        $this->writeLog('admin', 'PRICE_UPDATE_ERROR', 'Ürün fiyat bilgisi güncellenemedi: ' . $product['model']);
                    }
                }
            }
            
            if ($updatedCount > 0) {
                $json['success'] = sprintf($this->language->get('text_price_success'), $updatedCount);
            } else {
                $json['error'] = $this->language->get('text_price_failed');
            }
            
            $json['total'] = count($product_ids);
            $json['updated'] = $updatedCount;
            $json['failed'] = $failedCount;
            
            $this->writeLog('admin', 'PRICE_UPDATE_SUMMARY', 'Toplam ' . count($product_ids) . ' ürün için fiyat güncelleme: ' . $updatedCount . ' başarılı, ' . $failedCount . ' başarısız.');
        } catch (Exception $e) {
            $json['error'] = sprintf($this->language->get('text_price_error'), $e->getMessage());
            $this->writeLog('admin', 'PRICE_UPDATE_ERROR', 'Fiyat güncelleme hatası: ' . $e->getMessage());
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    /**
     * Rapor verilerini getirme metodu (AJAX ile çağrılır)
     */
    public function get_report_data() {
        $this->load->language('extension/module/trendyol');
        
        $json = array();
        
        if (!$this->validate()) {
            $json['error'] = $this->language->get('error_permission');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }
        
        // Filtre parametrelerini al
        $filter_date_start = isset($this->request->get['filter_date_start']) ? $this->request->get['filter_date_start'] : date('Y-m-d', strtotime('-30 days'));
        $filter_date_end = isset($this->request->get['filter_date_end']) ? $this->request->get['filter_date_end'] : date('Y-m-d');
        $report_type = isset($this->request->get['report_type']) ? $this->request->get['report_type'] : 'sales';
        
        // Tarih aralığı kontrolü
        if (strtotime($filter_date_start) > strtotime($filter_date_end)) {
            $json['error'] = $this->language->get('error_date_range');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }
        
        try {
            require_once(DIR_SYSTEM . 'helper/trendyol_helper.php');
            
            // Trendyol API'sine bağlan
            $helper = new TrendyolHelper(
                $this->config->get('module_trendyol_api_key'),
                $this->decode_secret($this->config->get('module_trendyol_api_secret')),
                $this->config->get('module_trendyol_supplier_id')
            );
            
            // Rapor tipine göre veri hazırla
            switch ($report_type) {
                case 'sales':
                    $data = $this->getSalesReportData($helper, $filter_date_start, $filter_date_end);
                    break;
                case 'products':
                    $data = $this->getProductReportData($helper, $filter_date_start, $filter_date_end);
                    break;
                case 'performance':
                    $data = $this->getPerformanceReportData($helper, $filter_date_start, $filter_date_end);
                    break;
                case 'comparison':
                    $data = $this->getComparisonReportData($helper, $filter_date_start, $filter_date_end);
                    break;
                default:
                    $data = array();
            }
            
            if (empty($data)) {
                $json['error'] = $this->language->get('error_no_data');
            } else {
                $json['success'] = $this->language->get('text_data_refreshed');
                $json['data'] = $data;
            }
            
        } catch (Exception $e) {
            $json['error'] = $e->getMessage();
            $this->writeLog('admin', 'RAPOR_HATA', 'Rapor oluşturma hatası: ' . $e->getMessage());
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    /**
     * Raporu dışa aktarma metodu
     */
    public function export_report() {
        $this->load->language('extension/module/trendyol');
        
        if (!$this->validate()) {
            $this->session->data['error_warning'] = $this->language->get('error_permission');
            $this->response->redirect($this->url->link('extension/module/trendyol/reports', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        // Filtre parametrelerini al
        $filter_date_start = isset($this->request->get['filter_date_start']) ? $this->request->get['filter_date_start'] : date('Y-m-d', strtotime('-30 days'));
        $filter_date_end = isset($this->request->get['filter_date_end']) ? $this->request->get['filter_date_end'] : date('Y-m-d');
        $report_type = isset($this->request->get['report_type']) ? $this->request->get['report_type'] : 'sales';
        
        try {
            require_once(DIR_SYSTEM . 'helper/trendyol_helper.php');
            
            // Trendyol API'sine bağlan
            $helper = new TrendyolHelper(
                $this->config->get('module_trendyol_api_key'),
                $this->decode_secret($this->config->get('module_trendyol_api_secret')),
                $this->config->get('module_trendyol_supplier_id')
            );
            
            // Rapor tipine göre veri hazırla
            switch ($report_type) {
                case 'sales':
                    $data = $this->getSalesReportData($helper, $filter_date_start, $filter_date_end);
                    $filename = 'trendyol_sales_' . $filter_date_start . '_' . $filter_date_end . '.csv';
                    $this->exportSalesReport($data, $filename);
                    break;
                case 'products':
                    $data = $this->getProductReportData($helper, $filter_date_start, $filter_date_end);
                    $filename = 'trendyol_products_' . $filter_date_start . '_' . $filter_date_end . '.csv';
                    $this->exportProductReport($data, $filename);
                    break;
                case 'performance':
                    $data = $this->getPerformanceReportData($helper, $filter_date_start, $filter_date_end);
                    $filename = 'trendyol_performance_' . $filter_date_start . '_' . $filter_date_end . '.csv';
                    $this->exportPerformanceReport($data, $filename);
                    break;
                case 'comparison':
                    $data = $this->getComparisonReportData($helper, $filter_date_start, $filter_date_end);
                    $filename = 'trendyol_comparison_' . $filter_date_start . '_' . $filter_date_end . '.csv';
                    $this->exportComparisonReport($data, $filename);
                    break;
                default:
                    throw new Exception($this->language->get('error_no_data'));
            }
            
        } catch (Exception $e) {
            $this->session->data['error_warning'] = $e->getMessage();
            $this->writeLog('admin', 'RAPOR_EXPORT_HATA', 'Rapor dışa aktarma hatası: ' . $e->getMessage());
            $this->response->redirect($this->url->link('extension/module/trendyol/reports', 'user_token=' . $this->session->data['user_token'], true));
        }
    }
    
    /**
     * Siparişler metodu
     */
    public function orders() {
        $this->load->language('extension/module/trendyol');
        
        $this->document->setTitle($this->language->get('heading_title') . ' - ' . $this->language->get('text_orders'));
        
        // Breadcrumbs
        $data['breadcrumbs'] = array();
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_orders'),
            'href' => $this->url->link('extension/module/trendyol/orders', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['get_orders'] = $this->url->link('extension/module/trendyol/get_orders', 'user_token=' . $this->session->data['user_token'], true);
        $data['convert_orders'] = $this->url->link('extension/module/trendyol/convert_orders', 'user_token=' . $this->session->data['user_token'], true);
        $data['back'] = $this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true);
        
        // Filtreleme
        if (isset($this->request->get['filter_order_id'])) {
            $filter_order_id = $this->request->get['filter_order_id'];
        } else {
            $filter_order_id = '';
        }
        
        if (isset($this->request->get['filter_status'])) {
            $filter_status = $this->request->get['filter_status'];
        } else {
            $filter_status = '';
        }
        
        if (isset($this->request->get['filter_convert_status'])) {
            $filter_convert_status = $this->request->get['filter_convert_status'];
        } else {
            $filter_convert_status = '';
        }
        
        if (isset($this->request->get['filter_date_start'])) {
            $filter_date_start = $this->request->get['filter_date_start'];
        } else {
            $filter_date_start = date('Y-m-d', strtotime('-7 days'));
        }
        
        if (isset($this->request->get['filter_date_end'])) {
            $filter_date_end = $this->request->get['filter_date_end'];
        } else {
            $filter_date_end = date('Y-m-d');
        }
        
        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }
        
        $data['filter_order_id'] = $filter_order_id;
        $data['filter_status'] = $filter_status;
        $data['filter_convert_status'] = $filter_convert_status;
        $data['filter_date_start'] = $filter_date_start;
        $data['filter_date_end'] = $filter_date_end;
        
        // Veritabanından Trendyol siparişlerini al
        $this->load->model('extension/module/trendyol');
        
        $filter_data = array(
            'filter_order_id' => $filter_order_id,
            'filter_status' => $filter_status,
            'filter_convert_status' => $filter_convert_status,
            'filter_date_start' => $filter_date_start,
            'filter_date_end' => $filter_date_end,
            'sort' => 'date_added',
            'order' => 'DESC',
            'start' => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit' => $this->config->get('config_limit_admin')
        );
        
        $order_total = $this->model_extension_module_trendyol->getTotalOrders($filter_data);
        $orders = $this->model_extension_module_trendyol->getOrders($filter_data);
        
        $data['orders'] = array();
        
        foreach ($orders as $order) {
            // OpenCart sipariş bilgisi
            $opencart_order_info = $this->model_extension_module_trendyol->getOpenCartOrderId($order['order_id']);
            $opencart_order_id = $opencart_order_info ? $opencart_order_info['opencart_order_id'] : '';
            $opencart_order_url = $opencart_order_id ? $this->url->link('sale/order/info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $opencart_order_id, true) : '';
            
            $data['orders'][] = array(
                'order_id' => $order['order_id'],
                'customer' => $order['customer_name'],
                'total' => $this->currency->format($order['total'], 'TRY'),
                'status' => $this->getOrderStatusText($order['status']),
                'date_added' => date($this->language->get('date_format_short'), strtotime($order['date_added'])),
                'opencart_order_id' => $opencart_order_id,
                'opencart_order_url' => $opencart_order_url,
                'view' => $this->url->link('extension/module/trendyol/order_info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order['order_id'], true),
                'convert' => $this->url->link('extension/module/trendyol/convert_order', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order['order_id'], true)
            );
        }
        
        // Pagination
        $pagination = new Pagination();
        $pagination->total = $order_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->url = $this->url->link('extension/module/trendyol/orders', 'user_token=' . $this->session->data['user_token'] . '&page={page}', true);
        
        $data['pagination'] = $pagination->render();
        $data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($order_total - $this->config->get('config_limit_admin'))) ? $order_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $order_total, ceil($order_total / $this->config->get('config_limit_admin')));
        
        // Messages
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } elseif (isset($this->session->data['error_warning'])) {
            $data['error_warning'] = $this->session->data['error_warning'];
            unset($this->session->data['error_warning']);
        } else {
            $data['error_warning'] = '';
        }
        
        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];
        unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }
        
        // Common template
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('extension/module/trendyol_orders', $data));
    }
    
    /**
     * Sipariş durumu metni
     * 
     * @param string $status
     * @return string
     */
    private function getOrderStatusText($status) {
        $status_text = '';
        
        switch ($status) {
            case 'Created':
                $status_text = $this->language->get('text_status_created');
                break;
            case 'Picking':
                $status_text = $this->language->get('text_status_picking');
                break;
            case 'Invoiced':
                $status_text = $this->language->get('text_status_invoiced');
                break;
            case 'Shipped':
                $status_text = $this->language->get('text_status_shipped');
                break;
            case 'Cancelled':
                $status_text = $this->language->get('text_status_cancelled');
                break;
            case 'Delivered':
                $status_text = $this->language->get('text_status_delivered');
                break;
            case 'UnDelivered':
                $status_text = $this->language->get('text_status_undelivered');
                break;
            case 'Returned':
                $status_text = $this->language->get('text_status_returned');
                break;
            default:
                $status_text = $status;
        }
        
        return $status_text;
    }

    /**
     * Raporlar metodu
     */
    public function reports() {
        $this->sessionSecurity();
        $this->load->language('extension/module/trendyol');
        
        $this->document->setTitle($this->language->get('heading_title') . ' - ' . $this->language->get('text_reports'));
        
        // Breadcrumbs
        $data['breadcrumbs'] = array();
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_reports'),
            'href' => $this->url->link('extension/module/trendyol/reports', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        // Default filter values
        $data['filter_date_start'] = date('Y-m-d', strtotime('-30 days'));
        $data['filter_date_end'] = date('Y-m-d');
        
        // Check for error or success messages
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } elseif (isset($this->session->data['error_warning'])) {
            $data['error_warning'] = $this->session->data['error_warning'];
            unset($this->session->data['error_warning']);
        } else {
            $data['error_warning'] = '';
        }
        
        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }
        
        $data['heading_title'] = $this->language->get('heading_title');
        
        // Common template parts
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        // Show the reports page
        $this->response->setOutput($this->load->view('extension/module/trendyol_reports', $data));
    }
    
    /**
     * Ürün eşleştirme sayfası
     */
    public function product_mapping() {
        $this->load->language('extension/module/trendyol');
        
        $this->document->setTitle($this->language->get('heading_title') . ' - ' . $this->language->get('text_product_mapping'));
        
        // API kimlik bilgilerini kontrol et
        if (!$this->config->get('module_trendyol_api_key') || !$this->config->get('module_trendyol_api_secret') || !$this->config->get('module_trendyol_supplier_id')) {
            $this->session->data['error_warning'] = $this->language->get('error_api_connect');
            $this->response->redirect($this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        // Trendyol helper sınıfını yükle
        require_once(DIR_SYSTEM . 'library/meschain/helper/trendyol_helper.php');
        
        // Modelleri yükle
        $this->load->model('catalog/product');
        $this->load->model('catalog/category');
        $this->load->model('catalog/manufacturer');
        $this->load->model('setting/setting');
        
        // Filtre değerlerini al
        if (isset($this->request->get['filter_name'])) {
            $filter_name = $this->request->get['filter_name'];
        } else {
            $filter_name = '';
        }
        
        if (isset($this->request->get['filter_model'])) {
            $filter_model = $this->request->get['filter_model'];
        } else {
            $filter_model = '';
        }
        
        if (isset($this->request->get['filter_status'])) {
            $filter_status = $this->request->get['filter_status'];
        } else {
            $filter_status = '';
        }
        
        if (isset($this->request->get['filter_category'])) {
            $filter_category = $this->request->get['filter_category'];
        } else {
            $filter_category = '';
        }
        
        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'pd.name';
        }
        
        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }
        
        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }
        
        $url = '';
        
        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }
        
        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
        }
        
        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }
        
        if (isset($this->request->get['filter_category'])) {
            $url .= '&filter_category=' . $this->request->get['filter_category'];
        }
        
        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }
        
        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }
        
        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }
        
        // Eşleştirme bilgilerini kaydet
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $trendyol_product_mappings = array();
            
            if (isset($this->request->post['product_mapping'])) {
                foreach ($this->request->post['product_mapping'] as $product_id => $mapping) {
                    if (!empty($mapping['category'])) {
                        $trendyol_product_mappings['trendyol_category_' . $product_id] = $mapping['category'];
                    }
                    
                    if (!empty($mapping['brand'])) {
                        $trendyol_product_mappings['trendyol_brand_' . $product_id] = $mapping['brand'];
                    }
                    
                    if (isset($mapping['status'])) {
                        $trendyol_product_mappings['trendyol_status_' . $product_id] = $mapping['status'];
                    } else {
                        $trendyol_product_mappings['trendyol_status_' . $product_id] = 0;
                    }
                }
            }
            
            // Ayarları kaydet
            $this->model_setting_setting->editSetting('trendyol_product_mapping', $trendyol_product_mappings);
            
            $this->session->data['success'] = $this->language->get('text_mapping_success');
            
            $this->response->redirect($this->url->link('extension/module/trendyol/product_mapping', 'user_token=' . $this->session->data['user_token'] . $url, true));
        }
        
        // Breadcrumbs
        $data['breadcrumbs'] = array();
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_product_mapping'),
            'href' => $this->url->link('extension/module/trendyol/product_mapping', 'user_token=' . $this->session->data['user_token'] . $url, true)
        );
        
        // Mevcut eşleştirme verilerini al
        $trendyol_product_mappings = $this->model_setting_setting->getSetting('trendyol_product_mapping');
        
        // Trendyol kategorileri ve markalarını al
        try {
            // Helper sınıfı ile Trendyol API'ya bağlan
            $trendyolHelper = new MeschainTrendyolHelper(
                $this->config->get('module_trendyol_api_key'),
                $this->decode_secret($this->config->get('module_trendyol_api_secret')),
                $this->config->get('module_trendyol_supplier_id')
            );
            
            // Trendyol kategorileri
            $trendyol_categories = $trendyolHelper->getCategories();
            
            // Trendyol markaları
            $trendyol_brands = $trendyolHelper->getBrands();
            
            // API hatası kontrolü
            if ($trendyol_categories === false || $trendyol_brands === false) {
                $this->session->data['error_warning'] = $this->language->get('error_api_connect');
                $trendyol_categories = array();
                $trendyol_brands = array();
            }
        } catch (Exception $e) {
            $this->session->data['error_warning'] = $e->getMessage();
            $trendyol_categories = array();
            $trendyol_brands = array();
        }
        
        // Ürünleri listele
        $filter_data = array(
            'filter_name'     => $filter_name,
            'filter_model'    => $filter_model,
            'filter_status'   => $filter_status,
            'filter_category' => $filter_category,
            'sort'            => $sort,
            'order'           => $order,
            'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit'           => $this->config->get('config_limit_admin')
        );
        
        $product_total = $this->model_catalog_product->getTotalProducts($filter_data);
        $products = $this->model_catalog_product->getProducts($filter_data);
        
        $data['products'] = array();
        
        foreach ($products as $product) {
            $product_id = $product['product_id'];
            
            // Mevcut eşleştirme değerlerini al
            $trendyol_category_id = isset($trendyol_product_mappings['trendyol_category_' . $product_id]) ? $trendyol_product_mappings['trendyol_category_' . $product_id] : '';
            $trendyol_brand_id = isset($trendyol_product_mappings['trendyol_brand_' . $product_id]) ? $trendyol_product_mappings['trendyol_brand_' . $product_id] : '';
            $trendyol_status = isset($trendyol_product_mappings['trendyol_status_' . $product_id]) ? $trendyol_product_mappings['trendyol_status_' . $product_id] : 0;
            
            // Ürün kategorisini al
            $product_category = '';
            $product_categories = $this->model_catalog_product->getProductCategories($product_id);
            
            if (!empty($product_categories)) {
                $category_info = $this->model_catalog_category->getCategory($product_categories[0]);
                if ($category_info) {
                    $product_category = $category_info['name'];
                }
            }
            
            // Ürün markasını al
            $product_manufacturer = '';
            if ($product['manufacturer_id']) {
                $manufacturer_info = $this->model_catalog_manufacturer->getManufacturer($product['manufacturer_id']);
                if ($manufacturer_info) {
                    $product_manufacturer = $manufacturer_info['name'];
                }
            }
            
            $data['products'][] = array(
                'product_id' => $product_id,
                'name' => $product['name'],
                'model' => $product['model'],
                'price' => $this->currency->format($product['price'], $this->config->get('config_currency')),
                'status' => $product['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
                'category' => $product_category,
                'manufacturer' => $product_manufacturer,
                'trendyol_category_id' => $trendyol_category_id,
                'trendyol_brand_id' => $trendyol_brand_id,
                'trendyol_status' => $trendyol_status
            );
        }
        
        // Kategorileri ve markaları dropdown için hazırla
        $data['trendyol_categories'] = array();
        $data['trendyol_brands'] = array();
        
        // Kategorileri işle
        if (!empty($trendyol_categories) && isset($trendyol_categories['categories'])) {
            foreach ($trendyol_categories['categories'] as $category) {
                $data['trendyol_categories'][] = array(
                    'category_id' => $category['id'],
                    'name' => $category['name']
                );
                
                // Alt kategorileri işle (Trendyol API yapısına göre ayarla)
                if (isset($category['subCategories']) && !empty($category['subCategories'])) {
                    $this->processSubCategories($category['subCategories'], $data['trendyol_categories'], 1);
                }
            }
        }
        
        // Markaları işle
        if (!empty($trendyol_brands) && isset($trendyol_brands['brands'])) {
            foreach ($trendyol_brands['brands'] as $brand) {
                $data['trendyol_brands'][] = array(
                    'brand_id' => $brand['id'],
                    'name' => $brand['name']
                );
            }
        }
        
        // OpenCart kategorilerini hazırla
        $data['opencart_categories'] = array();
        $categories = $this->model_catalog_category->getCategories(array('sort' => 'name'));
        
        foreach ($categories as $category) {
            $data['opencart_categories'][] = array(
                'category_id' => $category['category_id'],
                'name' => $category['name']
            );
        }
        
        // Linkler
        $data['action'] = $this->url->link('extension/module/trendyol/product_mapping', 'user_token=' . $this->session->data['user_token'] . $url, true);
        $data['cancel'] = $this->url->link('extension/module/trendyol/dashboard', 'user_token=' . $this->session->data['user_token'], true);
        $data['sync_products'] = $this->url->link('extension/module/trendyol/sync_products', 'user_token=' . $this->session->data['user_token'], true);
        
        // Form değerleri
        $data['user_token'] = $this->session->data['user_token'];
        $data['filter_name'] = $filter_name;
        $data['filter_model'] = $filter_model;
        $data['filter_status'] = $filter_status;
        $data['filter_category'] = $filter_category;
        
        // Sort ve order
        $url = '';
        
        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }
        
        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
        }
        
        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }
        
        if (isset($this->request->get['filter_category'])) {
            $url .= '&filter_category=' . $this->request->get['filter_category'];
        }
        
        $data['sort_name'] = $this->url->link('extension/module/trendyol/product_mapping', 'user_token=' . $this->session->data['user_token'] . '&sort=pd.name' . ($sort == 'pd.name' && $order == 'ASC' ? '&order=DESC' : '') . $url, true);
        $data['sort_model'] = $this->url->link('extension/module/trendyol/product_mapping', 'user_token=' . $this->session->data['user_token'] . '&sort=p.model' . ($sort == 'p.model' && $order == 'ASC' ? '&order=DESC' : '') . $url, true);
        $data['sort_price'] = $this->url->link('extension/module/trendyol/product_mapping', 'user_token=' . $this->session->data['user_token'] . '&sort=p.price' . ($sort == 'p.price' && $order == 'ASC' ? '&order=DESC' : '') . $url, true);
        $data['sort_status'] = $this->url->link('extension/module/trendyol/product_mapping', 'user_token=' . $this->session->data['user_token'] . '&sort=p.status' . ($sort == 'p.status' && $order == 'ASC' ? '&order=DESC' : '') . $url, true);
        
        $url = '';
        
        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }
        
        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
        }
        
        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }
        
        if (isset($this->request->get['filter_category'])) {
            $url .= '&filter_category=' . $this->request->get['filter_category'];
        }
        
        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }
        
        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }
        
        // Pagination
        $pagination = new Pagination();
        $pagination->total = $product_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->url = $this->url->link('extension/module/trendyol/product_mapping', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
        
        $data['pagination'] = $pagination->render();
        $data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));
        
        // Error messages
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } elseif (isset($this->session->data['error_warning'])) {
            $data['error_warning'] = $this->session->data['error_warning'];
            unset($this->session->data['error_warning']);
        } else {
            $data['error_warning'] = '';
        }
        
        // Success messages
        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }
        
        // Templates
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('extension/module/trendyol_product_mapping', $data));
    }

    /**
     * Alt kategorileri işleme fonksiyonu
     * @param array $subcategories Alt kategori listesi
     * @param array &$result Sonuç listesi
     * @param int $level Seviye
     */
    private function processSubCategories($subcategories, &$result, $level) {
        $indent = str_repeat('&nbsp;&nbsp;&nbsp;', $level);
        
        foreach ($subcategories as $category) {
            $result[] = array(
                'category_id' => $category['id'],
                'name' => $indent . $category['name']
            );
            
            if (isset($category['subCategories']) && !empty($category['subCategories'])) {
                $this->processSubCategories($category['subCategories'], $result, $level + 1);
            }
        }
    }

    /**
     * Base64 ile encode
     * @param string $value
     * @return string
     */
    private function encode_secret($value) {
        return base64_encode($value);
    }
    /**
     * Base64 ile decode
     * @param string $value
     * @return string
     */
    private function decode_secret($value) {
        return base64_decode($value);
    }

    /**
     * Modül kurulum işlemi
     */
    public function install() {
        // Kullanıcı izinlerini ekle
        $this->load->model('user/user_group');
        
        // Trendyol modülüne erişim ve düzenleme izni ver
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/trendyol');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/module/trendyol');
        
        // Dashboard, orders ve diğer alt sayfalar için izinler
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/dashboard');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/orders');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/test_connection');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/sync_products');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/get_orders');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/update_stock');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/update_prices');
        
        // Log dosyasını oluştur
        $log_file = DIR_LOGS . 'trendyol_controller.log';
        $date = date('Y-m-d H:i:s');
        $log = "[$date] [SYSTEM] [INSTALL] Trendyol modülü kuruldu.\n";
        file_put_contents($log_file, $log, FILE_APPEND);
        
        $this->writeLog('admin', 'KURULUM', 'Trendyol modülü kuruldu.');
    }

    /**
     * Modül kaldırma işlemi
     */
    public function uninstall() {
        // Kullanıcı izinlerini kaldır
        $this->load->model('user/user_group');
        
        // Trendyol modülü izinlerini kaldır
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'extension/module/trendyol');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'extension/module/trendyol');
        
        // Alt sayfa izinlerini kaldır
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/dashboard');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/orders');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/test_connection');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/sync_products');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/get_orders');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/update_stock');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'extension/module/trendyol/update_prices');
        
        // Ayarları temizle
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('module_trendyol');
        
        $this->writeLog('admin', 'KALDIRMA', 'Trendyol modülü kaldırıldı.');
    }

    /**
     * Ayar doğrulama
     * Yetki yoksa loglar ve hata döner.
     */
    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/trendyol')) {
            $this->error['warning'] = $this->language->get('error_permission');
            $this->writeLog('admin', 'HATA', 'İzin yok.');
            return false;
        }
        return true;
    }

    /**
     * Loglama fonksiyonu (atomik)
     * Tüm önemli işlemler ve hatalar hem controller hem helper loguna kaydedilir.
     * @param string $user
     * @param string $action
     * @param string $message
     */
    private function writeLog($user, $action, $message) {
        $log_file1 = DIR_LOGS . 'trendyol_controller.log';
        $log_file2 = DIR_LOGS . 'trendyol_helper.log';
        $date = date('Y-m-d H:i:s');
        $log = "[$date] [$user] [$action] $message\n";
        file_put_contents($log_file1, $log, FILE_APPEND);
        file_put_contents($log_file2, $log, FILE_APPEND);
    }

    /**
     * Satış raporu verilerini oluşturma
     * @param TrendyolHelper $helper
     * @param string $startDate
     * @param string $endDate
     * @return array
     */
    private function getSalesReportData($helper, $startDate, $endDate) {
        // Siparişleri getir
        $orders = $this->getOrdersInDateRange($helper, $startDate, $endDate);
        
        if (empty($orders)) {
            return array();
        }
        
        // Satış verileri
        $salesData = array();
        
        // Grafik verileri
        $chartLabels = array();
        $chartValues = array();
        
        // Pasta grafiği verileri
        $pieLabels = array('Ürünler', 'Kargo', 'Vergi', 'Komisyon');
        $pieValues = array(0, 0, 0, 0);
        
        // Tarih aralığındaki her gün için veri oluştur
        $currentDate = strtotime($startDate);
        $endTimestamp = strtotime($endDate);
        
        while ($currentDate <= $endTimestamp) {
            $dateFormatted = date('Y-m-d', $currentDate);
            $dateDisplay = date('d.m.Y', $currentDate);
            
            // O gün için toplam değerleri hesapla
            $dailyOrders = 0;
            $dailyProducts = 0;
            $dailyTotal = 0;
            $dailyShipping = 0;
            $dailyTax = 0;
            $dailyCommission = 0;
            $dailyNet = 0;
            
            foreach ($orders as $order) {
                $orderDate = substr($order['orderDate'], 0, 10);
                
                if ($orderDate == $dateFormatted) {
                    $dailyOrders++;
                    $dailyProducts += count($order['lines']);
                    $dailyTotal += $order['totalPrice'];
                    $dailyShipping += isset($order['cargoPrice']) ? $order['cargoPrice'] : 0;
                    
                    // Trendyol API'sinde vergi ve komisyon bilgisi olmayabilir, tahmin et
                    $tax = $dailyTotal * 0.18; // %18 KDV varsayımı
                    $commission = $dailyTotal * 0.12; // %12 komisyon varsayımı
                    
                    $dailyTax += $tax;
                    $dailyCommission += $commission;
                    $dailyNet += ($dailyTotal - $dailyCommission);
                }
            }
            
            // Pasta grafiği verilerini güncelle
            $pieValues[0] += ($dailyTotal - $dailyShipping - $dailyTax);
            $pieValues[1] += $dailyShipping;
            $pieValues[2] += $dailyTax;
            $pieValues[3] += $dailyCommission;
            
            // Sonuçları ekle
            if ($dailyOrders > 0) {
                $salesData[] = array(
                    'date' => $dateDisplay,
                    'orders' => $dailyOrders,
                    'products' => $dailyProducts,
                    'total' => number_format($dailyTotal, 2) . ' ₺',
                    'shipping' => number_format($dailyShipping, 2) . ' ₺',
                    'tax' => number_format($dailyTax, 2) . ' ₺',
                    'commission' => number_format($dailyCommission, 2) . ' ₺',
                    'net' => number_format($dailyNet, 2) . ' ₺'
                );
                
                $chartLabels[] = $dateDisplay;
                $chartValues[] = $dailyTotal;
            }
            
            // Sonraki güne geç
            $currentDate = strtotime('+1 day', $currentDate);
        }
        
        return array(
            'sales' => $salesData,
            'chart' => array(
                'labels' => $chartLabels,
                'values' => $chartValues
            ),
            'pie' => array(
                'labels' => $pieLabels,
                'values' => $pieValues
            )
        );
    }
    
    /**
     * Ürün raporu verilerini oluşturma
     * @param TrendyolHelper $helper
     * @param string $startDate
     * @param string $endDate
     * @return array
     */
    private function getProductReportData($helper, $startDate, $endDate) {
        // Siparişleri getir
        $orders = $this->getOrdersInDateRange($helper, $startDate, $endDate);
        
        if (empty($orders)) {
            return array();
        }
        
        // Ürün verileri
        $productData = array();
        
        // Ürünleri grupla
        $products = array();
        
        foreach ($orders as $order) {
            foreach ($order['lines'] as $line) {
                $productId = $line['productId'];
                
                if (!isset($products[$productId])) {
                    $products[$productId] = array(
                        'name' => $line['productName'],
                        'model' => $line['barcode'],
                        'quantity' => 0,
                        'total' => 0,
                        'commission' => 0,
                        'net' => 0
                    );
                }
                
                $products[$productId]['quantity'] += $line['quantity'];
                $products[$productId]['total'] += $line['price'];
                $products[$productId]['commission'] += ($line['price'] * 0.12); // %12 komisyon varsayımı
                $products[$productId]['net'] += ($line['price'] - ($line['price'] * 0.12));
            }
        }
        
        // En çok satılan ürünlere göre sırala
        uasort($products, function($a, $b) {
            return $b['quantity'] - $a['quantity'];
        });
        
        // En çok satan 20 ürünü al
        $products = array_slice($products, 0, 20, true);
        
        // Grafik verileri
        $chartLabels = array();
        $chartValues = array();
        
        foreach ($products as $product) {
            $productData[] = array(
                'name' => $product['name'],
                'model' => $product['model'],
                'quantity' => $product['quantity'],
                'total' => number_format($product['total'], 2) . ' ₺',
                'commission' => number_format($product['commission'], 2) . ' ₺',
                'net' => number_format($product['net'], 2) . ' ₺'
            );
            
            $chartLabels[] = $product['name'];
            $chartValues[] = $product['total'];
        }
        
        return array(
            'products' => $productData,
            'chart' => array(
                'labels' => $chartLabels,
                'values' => $chartValues
            )
        );
    }
    
    /**
     * Performans raporu verilerini oluşturma
     * @param TrendyolHelper $helper
     * @param string $startDate
     * @param string $endDate
     * @return array
     */
    private function getPerformanceReportData($helper, $startDate, $endDate) {
        // Siparişleri getir
        $orders = $this->getOrdersInDateRange($helper, $startDate, $endDate);
        
        if (empty($orders)) {
            return array();
        }
        
        // Performans metrikleri
        $totalOrders = count($orders);
        $totalVisits = $totalOrders * 20; // Tahmini ziyaret sayısı (gerçek API'den alınmalı)
        $conversionRate = ($totalOrders / $totalVisits) * 100;
        
        $totalAmount = 0;
        $returnCount = 0;
        
        foreach ($orders as $order) {
            $totalAmount += $order['totalPrice'];
            
            // İade durumu (gerçek API'den alınmalı)
            if (isset($order['status']) && $order['status'] === 'Returned') {
                $returnCount++;
            }
        }
        
        $averageOrder = $totalOrders > 0 ? $totalAmount / $totalOrders : 0;
        $returnRate = $totalOrders > 0 ? ($returnCount / $totalOrders) * 100 : 0;
        
        // Grafik verileri - Performans trendi
        $chartLabels = array();
        $chartDataSets = array(
            array(
                'label' => 'Sipariş Sayısı',
                'data' => array(),
                'backgroundColor' => 'rgba(54, 162, 235, 0.2)',
                'borderColor' => 'rgba(54, 162, 235, 1)',
                'borderWidth' => 1,
                'fill' => false
            ),
            array(
                'label' => 'Ortalama Sipariş Tutarı (₺)',
                'data' => array(),
                'backgroundColor' => 'rgba(255, 99, 132, 0.2)',
                'borderColor' => 'rgba(255, 99, 132, 1)',
                'borderWidth' => 1,
                'fill' => false
            )
        );
        
        // Haftaya göre grupla
        $weeklyData = array();
        
        foreach ($orders as $order) {
            $orderDate = substr($order['orderDate'], 0, 10);
            $weekNumber = date('W', strtotime($orderDate));
            $weekYear = date('Y', strtotime($orderDate));
            $weekKey = $weekYear . '-W' . $weekNumber;
            
            if (!isset($weeklyData[$weekKey])) {
                $weeklyData[$weekKey] = array(
                    'orderCount' => 0,
                    'totalAmount' => 0,
                    'display' => 'Hafta ' . $weekNumber . ', ' . $weekYear
                );
            }
            
            $weeklyData[$weekKey]['orderCount']++;
            $weeklyData[$weekKey]['totalAmount'] += $order['totalPrice'];
        }
        
        // Haftalık verileri sırala
        ksort($weeklyData);
        
        foreach ($weeklyData as $week => $data) {
            $chartLabels[] = $data['display'];
            $chartDataSets[0]['data'][] = $data['orderCount'];
            $chartDataSets[1]['data'][] = $data['totalAmount'] / $data['orderCount']; // Ortalama sipariş tutarı
        }
        
        return array(
            'performance' => array(
                'conversion_rate' => number_format($conversionRate, 2),
                'average_order' => number_format($averageOrder, 2) . ' ₺',
                'return_rate' => number_format($returnRate, 2)
            ),
            'chart' => array(
                'labels' => $chartLabels,
                'datasets' => $chartDataSets
            )
        );
    }
    
    /**
     * Karşılaştırma raporu verilerini oluşturma
     * @param TrendyolHelper $helper
     * @param string $startDate
     * @param string $endDate
     * @return array
     */
    private function getComparisonReportData($helper, $startDate, $endDate) {
        // Trendyol siparişlerini getir
        $trendyolOrders = $this->getOrdersInDateRange($helper, $startDate, $endDate);
        
        // N11 siparişlerini getir (eğer n11 modülü entegre edilmişse)
        $n11Orders = array(); // Gerçek entegrasyonda doldurulmalı
        
        // OpenCart siparişlerini getir
        $this->load->model('sale/order');
        $opencartOrdersFilter = array(
            'filter_date_added' => $startDate,
            'filter_date_modified' => $endDate,
            'start' => 0,
            'limit' => 1000
        );
        $opencartOrders = $this->model_sale_order->getOrders($opencartOrdersFilter);
        
        // Metrikler
        $comparisonData = array(
            array(
                'metric' => 'Toplam Sipariş',
                'trendyol' => count($trendyolOrders),
                'n11' => count($n11Orders),
                'opencart' => count($opencartOrders),
                'other' => 0
            ),
            array(
                'metric' => 'Toplam Ürün',
                'trendyol' => $this->countTotalProducts($trendyolOrders),
                'n11' => 0, // N11 için ürün sayısı
                'opencart' => $this->countTotalProductsOpenCart($opencartOrders),
                'other' => 0
            ),
            array(
                'metric' => 'Toplam Ciro (₺)',
                'trendyol' => number_format($this->calculateTotalRevenue($trendyolOrders), 2),
                'n11' => 0, // N11 için toplam ciro
                'opencart' => number_format($this->calculateTotalRevenueOpenCart($opencartOrders), 2),
                'other' => 0
            ),
            array(
                'metric' => 'Ortalama Sipariş (₺)',
                'trendyol' => number_format($this->calculateAverageOrder($trendyolOrders), 2),
                'n11' => 0, // N11 için ortalama sipariş
                'opencart' => number_format($this->calculateAverageOrderOpenCart($opencartOrders), 2),
                'other' => 0
            ),
            array(
                'metric' => 'Pazar Payı (%)',
                'trendyol' => $this->calculateMarketShare($trendyolOrders, $n11Orders, $opencartOrders),
                'n11' => $this->calculateMarketShareN11($trendyolOrders, $n11Orders, $opencartOrders),
                'opencart' => $this->calculateMarketShareOpenCart($trendyolOrders, $n11Orders, $opencartOrders),
                'other' => 0
            )
        );
        
        // Grafik verileri
        $chartLabels = array('Toplam Sipariş', 'Toplam Ürün', 'Toplam Ciro (₺ / 100)', 'Pazar Payı (%)');
        $chartDataSets = array(
            array(
                'label' => 'Trendyol',
                'data' => array(
                    count($trendyolOrders),
                    $this->countTotalProducts($trendyolOrders),
                    $this->calculateTotalRevenue($trendyolOrders) / 100,
                    $this->calculateMarketShare($trendyolOrders, $n11Orders, $opencartOrders)
                ),
                'backgroundColor' => 'rgba(255, 99, 132, 0.2)',
                'borderColor' => 'rgba(255, 99, 132, 1)',
                'borderWidth' => 1
            ),
            array(
                'label' => 'N11',
                'data' => array(
                    count($n11Orders),
                    0, // N11 için ürün sayısı
                    0, // N11 için toplam ciro / 100
                    $this->calculateMarketShareN11($trendyolOrders, $n11Orders, $opencartOrders)
                ),
                'backgroundColor' => 'rgba(54, 162, 235, 0.2)',
                'borderColor' => 'rgba(54, 162, 235, 1)',
                'borderWidth' => 1
            ),
            array(
                'label' => 'OpenCart',
                'data' => array(
                    count($opencartOrders),
                    $this->countTotalProductsOpenCart($opencartOrders),
                    $this->calculateTotalRevenueOpenCart($opencartOrders) / 100,
                    $this->calculateMarketShareOpenCart($trendyolOrders, $n11Orders, $opencartOrders)
                ),
                'backgroundColor' => 'rgba(255, 206, 86, 0.2)',
                'borderColor' => 'rgba(255, 206, 86, 1)',
                'borderWidth' => 1
            )
        );
        
        return array(
            'comparison' => $comparisonData,
            'chart' => array(
                'labels' => $chartLabels,
                'datasets' => $chartDataSets
            )
        );
    }
    
    /**
     * Belirli tarih aralığındaki siparişleri getir
     * @param TrendyolHelper $helper
     * @param string $startDate
     * @param string $endDate
     * @return array
     */
    private function getOrdersInDateRange($helper, $startDate, $endDate) {
        // Trendyol API'sinden siparişleri al (tarih formatını API'ye uygun formata dönüştür)
        $startDateISO = date('c', strtotime($startDate . ' 00:00:00'));
        $endDateISO = date('c', strtotime($endDate . ' 23:59:59'));
        
        $orders = $helper->getOrders('Created', 0, 100, $startDateISO, $endDateISO);
        
        // API yanıtını kontrol et
        if (!$orders || !isset($orders['content']) || empty($orders['content'])) {
            return array();
        }
        
        return $orders['content'];
    }
    
    /**
     * Toplam ürün sayısını hesapla (Trendyol)
     * @param array $orders
     * @return int
     */
    private function countTotalProducts($orders) {
        $count = 0;
        
        foreach ($orders as $order) {
            if (isset($order['lines'])) {
                foreach ($order['lines'] as $line) {
                    $count += $line['quantity'];
                }
            }
        }
        
        return $count;
    }
    
    /**
     * Toplam ürün sayısını hesapla (OpenCart)
     * @param array $orders
     * @return int
     */
    private function countTotalProductsOpenCart($orders) {
        $count = 0;
        
        foreach ($orders as $order) {
            $this->load->model('sale/order');
            $products = $this->model_sale_order->getOrderProducts($order['order_id']);
            
            foreach ($products as $product) {
                $count += $product['quantity'];
            }
        }
        
        return $count;
    }
    
    /**
     * Toplam ciroyu hesapla (Trendyol)
     * @param array $orders
     * @return float
     */
    private function calculateTotalRevenue($orders) {
        $total = 0;
        
        foreach ($orders as $order) {
            $total += $order['totalPrice'];
        }
        
        return $total;
    }
    
    /**
     * Toplam ciroyu hesapla (OpenCart)
     * @param array $orders
     * @return float
     */
    private function calculateTotalRevenueOpenCart($orders) {
        $total = 0;
        
        foreach ($orders as $order) {
            $total += $order['total'];
        }
        
        return $total;
    }
    
    /**
     * Ortalama sipariş tutarını hesapla (Trendyol)
     * @param array $orders
     * @return float
     */
    private function calculateAverageOrder($orders) {
        $totalOrders = count($orders);
        
        if ($totalOrders == 0) {
            return 0;
        }
        
        return $this->calculateTotalRevenue($orders) / $totalOrders;
    }
    
    /**
     * Ortalama sipariş tutarını hesapla (OpenCart)
     * @param array $orders
     * @return float
     */
    private function calculateAverageOrderOpenCart($orders) {
        $totalOrders = count($orders);
        
        if ($totalOrders == 0) {
            return 0;
        }
        
        return $this->calculateTotalRevenueOpenCart($orders) / $totalOrders;
    }
    
    /**
     * Trendyol pazar payını hesapla
     * @param array $trendyolOrders
     * @param array $n11Orders
     * @param array $opencartOrders
     * @return float
     */
    private function calculateMarketShare($trendyolOrders, $n11Orders, $opencartOrders) {
        $trendyolTotal = $this->calculateTotalRevenue($trendyolOrders);
        $n11Total = 0; // N11 için toplam ciro
        $opencartTotal = $this->calculateTotalRevenueOpenCart($opencartOrders);
        
        $total = $trendyolTotal + $n11Total + $opencartTotal;
        
        if ($total == 0) {
            return 0;
        }
        
        return number_format(($trendyolTotal / $total) * 100, 2);
    }
    
    /**
     * N11 pazar payını hesapla
     * @param array $trendyolOrders
     * @param array $n11Orders
     * @param array $opencartOrders
     * @return float
     */
    private function calculateMarketShareN11($trendyolOrders, $n11Orders, $opencartOrders) {
        $trendyolTotal = $this->calculateTotalRevenue($trendyolOrders);
        $n11Total = 0; // N11 için toplam ciro
        $opencartTotal = $this->calculateTotalRevenueOpenCart($opencartOrders);
        
        $total = $trendyolTotal + $n11Total + $opencartTotal;
        
        if ($total == 0) {
            return 0;
        }
        
        return number_format(($n11Total / $total) * 100, 2);
    }
    
    /**
     * OpenCart pazar payını hesapla
     * @param array $trendyolOrders
     * @param array $n11Orders
     * @param array $opencartOrders
     * @return float
     */
    private function calculateMarketShareOpenCart($trendyolOrders, $n11Orders, $opencartOrders) {
        $trendyolTotal = $this->calculateTotalRevenue($trendyolOrders);
        $n11Total = 0; // N11 için toplam ciro
        $opencartTotal = $this->calculateTotalRevenueOpenCart($opencartOrders);
        
        $total = $trendyolTotal + $n11Total + $opencartTotal;
        
        if ($total == 0) {
            return 0;
        }
        
        return number_format(($opencartTotal / $total) * 100, 2);
    }
    
    /**
     * Satış raporunu CSV olarak dışa aktar
     * @param array $data
     * @param string $filename
     */
    private function exportSalesReport($data, $filename) {
        $this->exportCSV($filename, array(
            $this->language->get('column_date'),
            $this->language->get('column_orders'),
            $this->language->get('column_products'),
            $this->language->get('column_total'),
            $this->language->get('column_shipping'),
            $this->language->get('column_tax'),
            $this->language->get('column_commission'),
            $this->language->get('column_net')
        ), $data['sales']);
    }
    
    /**
     * Ürün raporunu CSV olarak dışa aktar
     * @param array $data
     * @param string $filename
     */
    private function exportProductReport($data, $filename) {
        $this->exportCSV($filename, array(
            $this->language->get('column_product'),
            $this->language->get('column_model'),
            $this->language->get('column_quantity'),
            $this->language->get('column_total'),
            $this->language->get('column_commission'),
            $this->language->get('column_net')
        ), $data['products']);
    }
    
    /**
     * Performans raporunu CSV olarak dışa aktar
     * @param array $data
     * @param string $filename
     */
    private function exportPerformanceReport($data, $filename) {
        $this->exportCSV($filename, array(
            $this->language->get('text_conversion_rate'),
            $this->language->get('text_average_order'),
            $this->language->get('text_return_rate')
        ), array($data['performance']));
    }
    
    /**
     * Karşılaştırma raporunu CSV olarak dışa aktar
     * @param array $data
     * @param string $filename
     */
    private function exportComparisonReport($data, $filename) {
        $this->exportCSV($filename, array(
            $this->language->get('column_metric'),
            $this->language->get('column_trendyol'),
            $this->language->get('column_n11'),
            $this->language->get('column_opencart'),
            $this->language->get('column_other')
        ), $data['comparison']);
    }
    
    /**
     * CSV dosyasını oluştur ve indir
     * @param string $filename
     * @param array $headers
     * @param array $data
     */
    private function exportCSV($filename, $headers, $data) {
        // CSV başlıkları
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        
        // Çıktı tamponu
        $output = fopen('php://output', 'w');
        
        // UTF-8 BOM
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Başlıkları yaz
        fputcsv($output, $headers);
        
        // Verileri yaz
        foreach ($data as $row) {
            // TL işaretini kaldır ve sayısal değerleri temizle
            foreach ($row as &$value) {
                if (is_string($value) && strpos($value, '₺') !== false) {
                    $value = str_replace('₺', '', $value);
                    $value = str_replace('.', '', $value);
                    $value = str_replace(',', '.', $value);
                    $value = trim($value);
                }
            }
            
            fputcsv($output, $row);
        }
        
        fclose($output);
        exit();
    }
    
    /**
     * Bir siparişi OpenCart'a dönüştürme metodu
     */
    public function convert_order() {
        $this->load->language('extension/module/trendyol');
        
        if (!$this->validate()) {
            $this->session->data['error_warning'] = $this->language->get('error_permission');
            $this->response->redirect($this->url->link('extension/module/trendyol/orders', 'user_token=' . $this->session->data['user_token'], true));
        }
        
        $json = array();
        
        // Sipariş ID kontrolü
        if (!isset($this->request->get['order_id'])) {
            $json['error'] = $this->language->get('error_order_not_found');
            
            if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && $this->request->server['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') {
                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
                return;
            } else {
                $this->session->data['error_warning'] = $json['error'];
                $this->response->redirect($this->url->link('extension/module/trendyol/orders', 'user_token=' . $this->session->data['user_token'], true));
            }
        }
        
        $order_id = $this->request->get['order_id'];
        
        // Modelleri yükle
        $this->load->model('extension/module/trendyol');
        $this->load->model('sale/order');
        $this->load->model('catalog/product');
        $this->load->model('customer/customer');
        
        // Sipariş bilgilerini al
        $order_info = $this->model_extension_module_trendyol->getOrder($order_id);
        
        if (!$order_info) {
            $json['error'] = $this->language->get('error_order_not_found');
            
            if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && $this->request->server['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') {
                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
                return;
            } else {
                $this->session->data['error_warning'] = $json['error'];
                $this->response->redirect($this->url->link('extension/module/trendyol/orders', 'user_token=' . $this->session->data['user_token'], true));
            }
        }
        
        // Siparişin zaten dönüştürülüp dönüştürülmediğini kontrol et
        $opencart_order_info = $this->model_extension_module_trendyol->getOpenCartOrderId($order_id);
        
        if ($opencart_order_info && $opencart_order_info['opencart_order_id']) {
            $json['error'] = $this->language->get('error_already_converted');
            
            if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && $this->request->server['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') {
                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
                return;
            } else {
                $this->session->data['error_warning'] = $json['error'];
                $this->response->redirect($this->url->link('extension/module/trendyol/order_info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id, true));
            }
        }
        
        try {
            // Ürünleri al
            $order_products = $this->model_extension_module_trendyol->getOrderProducts($order_id);
            
            // Müşteri bilgilerini hazırla
            $customer_name_parts = explode(' ', $order_info['customer_name']);
            $customer_firstname = $customer_name_parts[0];
            $customer_lastname = count($customer_name_parts) > 1 ? implode(' ', array_slice($customer_name_parts, 1)) : '';
            
            // Adresi ayır
            $address_parts = explode("\n", $order_info['shipping_address']);
            $address_1 = isset($address_parts[0]) ? $address_parts[0] : '';
            $address_2 = isset($address_parts[1]) ? $address_parts[1] : '';
            
            // Müşteri var mı kontrol et
            $customer_id = 0;
            $email = !empty($order_info['customer_email']) ? $order_info['customer_email'] : 'trendyol_' . $order_id . '@example.com';
            $telephone = !empty($order_info['customer_phone']) ? $order_info['customer_phone'] : '';
            
            if (!empty($email)) {
                $customer_info = $this->model_customer_customer->getCustomers(array('filter_email' => $email, 'start' => 0, 'limit' => 1));
                
                if (!empty($customer_info)) {
                    $customer_id = $customer_info[0]['customer_id'];
                }
            }
            
            // OpenCart sipariş verilerini hazırla
            $opencart_order_data = array(
                'invoice_prefix' => 'TR',
                'store_id' => 0,
                'store_name' => $this->config->get('config_name'),
                'store_url' => $this->config->get('config_url'),
                'customer_id' => $customer_id,
                'customer_group_id' => $this->config->get('config_customer_group_id'),
                'firstname' => $customer_firstname,
                'lastname' => $customer_lastname,
                'email' => $email,
                'telephone' => $telephone,
                'custom_field' => array(),
                'payment_firstname' => $customer_firstname,
                'payment_lastname' => $customer_lastname,
                'payment_company' => '',
                'payment_address_1' => $address_1,
                'payment_address_2' => $address_2,
                'payment_city' => $order_info['shipping_city'],
                'payment_postcode' => '',
                'payment_zone' => $order_info['shipping_district'],
                'payment_zone_id' => 0,
                'payment_country' => 'Türkiye',
                'payment_country_id' => 215,
                'payment_address_format' => '',
                'payment_custom_field' => array(),
                'payment_method' => 'Trendyol',
                'payment_code' => 'trendyol',
                'shipping_firstname' => $customer_firstname,
                'shipping_lastname' => $customer_lastname,
                'shipping_company' => '',
                'shipping_address_1' => $address_1,
                'shipping_address_2' => $address_2,
                'shipping_city' => $order_info['shipping_city'],
                'shipping_postcode' => '',
                'shipping_zone' => $order_info['shipping_district'],
                'shipping_zone_id' => 0,
                'shipping_country' => 'Türkiye',
                'shipping_country_id' => 215,
                'shipping_address_format' => '',
                'shipping_custom_field' => array(),
                'shipping_method' => 'Trendyol Kargo',
                'shipping_code' => 'trendyol.trendyol',
                'comment' => 'Trendyol siparişinden dönüştürülmüştür. Trendyol Sipariş ID: ' . $order_id,
                'total' => $order_info['total_price'],
                'affiliate_id' => 0,
                'commission' => 0,
                'marketing_id' => 0,
                'tracking' => '',
                'language_id' => $this->config->get('config_language_id'),
                'currency_id' => $this->currency->getId('TRY'),
                'currency_code' => 'TRY',
                'currency_value' => $this->currency->getValue('TRY'),
                'ip' => $this->request->server['REMOTE_ADDR'],
                'forwarded_ip' => '',
                'user_agent' => '',
                'accept_language' => '',
                'products' => array(),
                'vouchers' => array(),
                'totals' => array()
            );
            
            // Ürünleri ekle
            $sub_total = 0;
            
            foreach ($order_products as $product) {
                // OpenCart'ta ürünü ara
                $opencart_product = $this->model_catalog_product->getProductByModel($product['barcode']);
                
                $product_id = 0;
                $product_name = $product['name'];
                
                if ($opencart_product) {
                    $product_id = $opencart_product['product_id'];
                    $product_name = $opencart_product['name'];
                }
                
                $product_total = $product['price'] * $product['quantity'];
                $sub_total += $product_total;
                
                $opencart_order_data['products'][] = array(
                    'product_id' => $product_id,
                    'name' => $product_name,
                    'model' => $product['barcode'],
                    'quantity' => $product['quantity'],
                    'price' => $product['price'],
                    'total' => $product_total,
                    'tax' => 0,
                    'reward' => 0
                );
            }
            
            // Totalleri ekle
            $shipping_cost = $order_info['shipping_cost'];
            $total = $sub_total + $shipping_cost;
            
            $opencart_order_data['totals'] = array(
                array(
                    'code' => 'sub_total',
                    'title' => 'Ara Toplam',
                    'value' => $sub_total,
                    'sort_order' => 1
                ),
                array(
                    'code' => 'shipping',
                    'title' => 'Trendyol Kargo',
                    'value' => $shipping_cost,
                    'sort_order' => 3
                ),
                array(
                    'code' => 'total',
                    'title' => 'Toplam',
                    'value' => $total,
                    'sort_order' => 9
                )
            );
            
            // OpenCart siparişi oluştur
            $opencart_order_id = $this->model_sale_order->addOrder($opencart_order_data);
            
            // İlişki tablosuna kaydet
            $this->model_extension_module_trendyol->addOrderRelation($order_id, $opencart_order_id);
            
            // Sipariş durumunu güncelle
            $this->model_sale_order->addOrderHistory($opencart_order_id, $this->config->get('config_order_status_id'), 'Trendyol siparişinden dönüştürülmüştür', true);
            
            // Başarı mesajı
            $json['success'] = $this->language->get('text_convert_success');
            $this->writeLog('admin', 'SIPARIS_DONUSTUR', 'Trendyol siparişi OpenCart\'a dönüştürüldü. Trendyol ID: ' . $order_id . ', OpenCart ID: ' . $opencart_order_id);
            
            // Yönlendirme URL'si
            $json['redirect'] = $this->url->link('extension/module/trendyol/order_info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id, true);
            
        } catch (Exception $e) {
            $json['error'] = $this->language->get('error_convert_failed') . ': ' . $e->getMessage();
            $this->writeLog('admin', 'SIPARIS_DONUSTUR_HATA', 'Dönüştürme hatası: ' . $e->getMessage());
        }
        
        // AJAX isteği veya normal istek kontrolü
        if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && $this->request->server['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') {
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
        } else {
            if (isset($json['error'])) {
                $this->session->data['error_warning'] = $json['error'];
            } else if (isset($json['success'])) {
                $this->session->data['success'] = $json['success'];
            }
            
            if (isset($json['redirect'])) {
                $this->response->redirect($json['redirect']);
            } else {
                $this->response->redirect($this->url->link('extension/module/trendyol/orders', 'user_token=' . $this->session->data['user_token'], true));
            }
        }
    }
    
    /**
     * Seçili siparişleri OpenCart'a dönüştürme metodu
     */
    public function convert_orders() {
        $this->load->language('extension/module/trendyol');
        
        $json = array();
        
        if (!$this->validate()) {
            $json['error'] = $this->language->get('error_permission');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }
        
        if (!isset($this->request->post['selected']) || !is_array($this->request->post['selected'])) {
            $json['error'] = $this->language->get('error_no_selection');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }
        
        $this->load->model('extension/module/trendyol');
        
        $order_ids = $this->request->post['selected'];
        $converted_count = 0;
        
        foreach ($order_ids as $order_id) {
            // Siparişin zaten dönüştürülüp dönüştürülmediğini kontrol et
            $opencart_order_info = $this->model_extension_module_trendyol->getOpenCartOrderId($order_id);
            
            if ($opencart_order_info && $opencart_order_info['opencart_order_id']) {
                continue;
            }
            
            // Internal URL request to convert each order
            $curl = curl_init();
            
            // Set curl options
            curl_setopt_array($curl, array(
                CURLOPT_URL => HTTPS_SERVER . 'index.php?route=extension/module/trendyol/convert_order&user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => false,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_COOKIE => 'OCSESSID=' . $this->session->getId()
            ));
            
            $response = curl_exec($curl);
            $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            
            curl_close($curl);
            
            if ($httpcode == 200) {
                $converted_count++;
            }
        }
        
        if ($converted_count > 0) {
            $json['success'] = sprintf($this->language->get('text_batch_convert_success'), $converted_count);
            $this->writeLog('admin', 'SIPARIS_TOPLU_DONUSTUR', sprintf('%d sipariş toplu olarak OpenCart\'a dönüştürüldü.', $converted_count));
        } else {
            $json['error'] = $this->language->get('error_convert_failed');
            $this->writeLog('admin', 'SIPARIS_TOPLU_DONUSTUR_HATA', 'Hiçbir sipariş dönüştürülemedi.');
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /**
     * Trendyol siparişini OpenCart'a dönüştürme fonksiyonu
     * @param array $trendyol_order Trendyol sipariş verisi
     * @return int|bool Oluşturulan OpenCart sipariş ID'si veya başarısızlık durumunda false
     */
    private function createOrderFromTrendyol($trendyol_order) {
        try {
            // Modelleri yükle
            $this->load->model('sale/order');
            $this->load->model('catalog/product');
            $this->load->model('customer/customer');
            
            // Müşteri bilgilerini hazırla
            $customer_name = isset($trendyol_order['customerFirstName']) && isset($trendyol_order['customerLastName']) 
                ? $trendyol_order['customerFirstName'] . ' ' . $trendyol_order['customerLastName'] 
                : 'Trendyol Müşterisi';
                
            $customer_name_parts = explode(' ', $customer_name);
            $customer_firstname = $customer_name_parts[0];
            $customer_lastname = count($customer_name_parts) > 1 ? implode(' ', array_slice($customer_name_parts, 1)) : '';
            
            // E-posta ve telefon bilgisini al
            $email = isset($trendyol_order['customerEmail']) ? $trendyol_order['customerEmail'] : 'trendyol_' . $trendyol_order['id'] . '@example.com';
            $telephone = isset($trendyol_order['customerPhone']) ? $trendyol_order['customerPhone'] : '';
            
            // Adres bilgilerini hazırla
            $shipping_address = isset($trendyol_order['shipmentAddress']) ? $trendyol_order['shipmentAddress'] : [];
            
            $address_1 = isset($shipping_address['fullAddress']) ? $shipping_address['fullAddress'] : '';
            $city = isset($shipping_address['city']) ? $shipping_address['city'] : '';
            $district = isset($shipping_address['district']) ? $shipping_address['district'] : '';
            
            // Müşteri var mı kontrol et
            $customer_id = 0;
            
            if (!empty($email)) {
                $customer_info = $this->model_customer_customer->getCustomers([
                    'filter_email' => $email,
                    'start' => 0,
                    'limit' => 1
                ]);
                
                if (!empty($customer_info)) {
                    $customer_id = $customer_info[0]['customer_id'];
                }
            }
            
            // Sipariş tutarını ve kargo ücretini hesapla
            $order_total = isset($trendyol_order['totalPrice']) ? $trendyol_order['totalPrice'] : 0;
            $shipping_cost = isset($trendyol_order['cargoPrice']) ? $trendyol_order['cargoPrice'] : 0;
            $sub_total = $order_total - $shipping_cost;
            
            // OpenCart sipariş verilerini hazırla
            $opencart_order_data = [
                'invoice_prefix' => 'TR',
                'store_id' => 0,
                'store_name' => $this->config->get('config_name'),
                'store_url' => $this->config->get('config_url'),
                'customer_id' => $customer_id,
                'customer_group_id' => $this->config->get('config_customer_group_id'),
                'firstname' => $customer_firstname,
                'lastname' => $customer_lastname,
                'email' => $email,
                'telephone' => $telephone,
                'custom_field' => [],
                'payment_firstname' => $customer_firstname,
                'payment_lastname' => $customer_lastname,
                'payment_company' => '',
                'payment_address_1' => $address_1,
                'payment_address_2' => '',
                'payment_city' => $city,
                'payment_postcode' => '',
                'payment_zone' => $district,
                'payment_zone_id' => 0,
                'payment_country' => 'Türkiye',
                'payment_country_id' => 215, // Türkiye ülke ID'si
                'payment_address_format' => '',
                'payment_custom_field' => [],
                'payment_method' => 'Trendyol',
                'payment_code' => 'trendyol',
                'shipping_firstname' => $customer_firstname,
                'shipping_lastname' => $customer_lastname,
                'shipping_company' => '',
                'shipping_address_1' => $address_1,
                'shipping_address_2' => '',
                'shipping_city' => $city,
                'shipping_postcode' => '',
                'shipping_zone' => $district,
                'shipping_zone_id' => 0,
                'shipping_country' => 'Türkiye',
                'shipping_country_id' => 215, // Türkiye ülke ID'si
                'shipping_address_format' => '',
                'shipping_custom_field' => [],
                'shipping_method' => 'Trendyol Kargo',
                'shipping_code' => 'trendyol.trendyol',
                'comment' => 'Trendyol siparişinden içe aktarılmıştır. Trendyol Sipariş ID: ' . $trendyol_order['id'] . ', Sipariş No: ' . $trendyol_order['orderNumber'],
                'total' => $order_total,
                'affiliate_id' => 0,
                'commission' => 0,
                'marketing_id' => 0,
                'tracking' => '',
                'language_id' => $this->config->get('config_language_id'),
                'currency_id' => $this->currency->getId('TRY'),
                'currency_code' => 'TRY',
                'currency_value' => $this->currency->getValue('TRY'),
                'ip' => $this->request->server['REMOTE_ADDR'],
                'forwarded_ip' => '',
                'user_agent' => '',
                'accept_language' => '',
                'products' => [],
                'vouchers' => [],
                'totals' => []
            ];
            
            // Ürünleri ekle
            if (isset($trendyol_order['lines']) && is_array($trendyol_order['lines'])) {
                foreach ($trendyol_order['lines'] as $line) {
                    // OpenCart'ta ürünü ara
                    $product_barcode = isset($line['barcode']) ? $line['barcode'] : '';
                    $opencart_product = $this->model_catalog_product->getProductByModel($product_barcode);
                    
                    $product_id = 0;
                    $product_name = isset($line['productName']) ? $line['productName'] : 'Trendyol Ürünü';
                    
                    if ($opencart_product) {
                        $product_id = $opencart_product['product_id'];
                        $product_name = $opencart_product['name'];
                    }
                    
                    $product_price = isset($line['price']) ? $line['price'] : 0;
                    $product_quantity = isset($line['quantity']) ? $line['quantity'] : 1;
                    $product_total = $product_price * $product_quantity;
                    
                    $opencart_order_data['products'][] = [
                        'product_id' => $product_id,
                        'name' => $product_name,
                        'model' => $product_barcode,
                        'quantity' => $product_quantity,
                        'price' => $product_price,
                        'total' => $product_total,
                        'tax' => 0,
                        'reward' => 0
                    ];
                }
            }
            
            // Totalleri ekle
            $opencart_order_data['totals'] = [
                [
                    'code' => 'sub_total',
                    'title' => 'Ara Toplam',
                    'value' => $sub_total,
                    'sort_order' => 1
                ],
                [
                    'code' => 'shipping',
                    'title' => 'Trendyol Kargo',
                    'value' => $shipping_cost,
                    'sort_order' => 3
                ],
                [
                    'code' => 'total',
                    'title' => 'Toplam',
                    'value' => $order_total,
                    'sort_order' => 9
                ]
            ];
            
            // OpenCart siparişi oluştur
            $opencart_order_id = $this->model_sale_order->addOrder($opencart_order_data);
            
            // Siparişi ilişkilendir
            $this->load->model('extension/module/trendyol');
            $this->model_extension_module_trendyol->addOrderRelation($trendyol_order['id'], $opencart_order_id);
            
            // Sipariş durumunu güncelle
            $order_status_id = $this->config->get('config_order_status_id'); // Varsayılan sipariş durumu
            
            // Trendyol sipariş durumuna göre OpenCart sipariş durumunu ayarla
            if (isset($trendyol_order['status'])) {
                switch ($trendyol_order['status']) {
                    case 'Created':
                        $order_status_id = 1; // Bekliyor
                        break;
                    case 'Picking':
                        $order_status_id = 2; // İşleniyor
                        break;
                    case 'Invoiced':
                        $order_status_id = 3; // Gönderildi
                        break;
                    case 'Shipped':
                        $order_status_id = 3; // Gönderildi
                        break;
                    case 'Delivered':
                        $order_status_id = 5; // Tamamlandı
                        break;
                    case 'Cancelled':
                        $order_status_id = 7; // İptal Edildi
                        break;
                }
            }
            
            $this->model_sale_order->addOrderHistory($opencart_order_id, $order_status_id, 'Trendyol siparişinden içe aktarılmıştır.', true);
            
            // Log oluştur
            $this->writeLog('admin', 'ORDER_IMPORT', 'Trendyol siparişi başarıyla içe aktarıldı. Trendyol ID: ' . $trendyol_order['id'] . ', OpenCart ID: ' . $opencart_order_id);
            
            return $opencart_order_id;
        } catch (Exception $e) {
            $this->writeLog('admin', 'ORDER_IMPORT_ERROR', 'Sipariş içe aktarma hatası: ' . $e->getMessage());
            return false;
        }
    }

    // Ana sayfa içerisindeki dashboard linklerine webhook ekleyeceğim
    protected function getCommonLinks() {
        $data = [];
        
        $user_token = $this->session->data['user_token'];
        
        $data['dashboard'] = $this->url->link('extension/module/trendyol_dashboard', 'user_token=' . $user_token, true);
        $data['settings'] = $this->url->link('extension/module/trendyol', 'user_token=' . $user_token, true);
        $data['products'] = $this->url->link('extension/module/trendyol_products', 'user_token=' . $user_token, true);
        $data['orders'] = $this->url->link('extension/module/trendyol_orders', 'user_token=' . $user_token, true);
        $data['reports'] = $this->url->link('extension/module/trendyol_reports', 'user_token=' . $user_token, true);
        $data['webhooks'] = $this->url->link('extension/module/trendyol_webhooks', 'user_token=' . $user_token, true);
        $data['logs'] = $this->url->link('extension/module/trendyol_logs', 'user_token=' . $user_token, true);
        
        return $data;
    }

    public function index() {
        // ... existing code ...
        
        // Webhook URL'ini oluştur
        $data['store_url'] = HTTPS_CATALOG . 'index.php?route=extension/module/trendyol_webhook';
        
        // Webhook yönetim linki
        $data['webhooks_link'] = $this->url->link('extension/module/trendyol_webhooks', 'user_token=' . $this->session->data['user_token'], true);
        
        // Tüm menü linklerini getir
        $common_links = $this->getCommonLinks();
        foreach ($common_links as $key => $value) {
            $data[$key] = $value;
        }
        
        // Post ile gönderilen veriler
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_module->editSetting('module_trendyol', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
        }
        
        // ... existing code ...
    }
}

// ... OpenCart controller fonksiyonları buraya eklenecek ... 