<?php
// Heading
$_['heading_title']    = 'MesChain Sync - Multi Marketplace Integration';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified MesChain Sync module!';
$_['text_edit']        = 'Edit MesChain Sync Module';
$_['text_dashboard']   = 'Dashboard';
$_['text_settings']    = 'Settings';
$_['text_marketplaces']= 'Marketplaces';
$_['text_products']    = 'Products';
$_['text_orders']      = 'Orders';
$_['text_reports']     = 'Reports';
$_['text_logs']        = 'Logs';
$_['text_help']        = 'Help & Support';
$_['text_active']      = 'Active';
$_['text_inactive']    = 'Inactive';
$_['text_connected']   = 'Connected';
$_['text_disconnected']= 'Disconnected';
$_['text_sync_now']    = 'Sync Now';
$_['text_last_sync']   = 'Last Sync';
$_['text_never']       = 'Never';
$_['text_today']       = 'Today';
$_['text_this_week']   = 'This Week';
$_['text_this_month']  = 'This Month';
$_['text_total']       = 'Total';

// Entry
$_['entry_status']     = 'Status';
$_['entry_marketplace']= 'Marketplace';
$_['entry_api_key']    = 'API Key';
$_['entry_api_secret'] = 'API Secret';
$_['entry_merchant_id']= 'Merchant ID';
$_['entry_store_id']   = 'Store ID';

// Tab
$_['tab_general']      = 'General';
$_['tab_trendyol']     = 'Trendyol';
$_['tab_n11']          = 'N11';
$_['tab_amazon']       = 'Amazon';
$_['tab_hepsiburada']  = 'Hepsiburada';
$_['tab_ozon']         = 'Ozon';
$_['tab_ebay']         = 'eBay';

// Column
$_['column_marketplace']= 'Marketplace';
$_['column_status']     = 'Status';
$_['column_products']   = 'Products';
$_['column_orders']     = 'Orders';
$_['column_last_sync']  = 'Last Sync';
$_['column_action']     = 'Action';

// Button
$_['button_sync']       = 'Sync';
$_['button_settings']   = 'Settings';
$_['button_connect']    = 'Connect';
$_['button_disconnect'] = 'Disconnect';
$_['button_export']     = 'Export Products';
$_['button_import']     = 'Import Orders';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify MesChain Sync module!';
$_['error_api_key']     = 'API Key required!';
$_['error_api_secret']  = 'API Secret required!';
$_['error_merchant_id'] = 'Merchant ID required!';
$_['error_connection']  = 'Could not connect to marketplace. Please check your credentials.';

// Success
$_['success_connection']= 'Successfully connected to marketplace!';
$_['success_sync']      = 'Synchronization completed successfully!';
$_['success_export']    = 'Products exported successfully!';
$_['success_import']    = 'Orders imported successfully!'; 