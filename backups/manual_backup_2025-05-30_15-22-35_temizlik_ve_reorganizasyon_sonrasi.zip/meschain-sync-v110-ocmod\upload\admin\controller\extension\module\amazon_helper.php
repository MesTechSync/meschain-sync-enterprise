<?php
/**
 * amazon_helper.php
 *
 * Amaç: Amazon modülünde ürün gönderme, sipariş çekme gibi yardımcı fonksiyonları içerir.
 *
 * Loglama: Tüm önemli işlemler ve hatalar amazon_helper.log dosyasına kaydedilmelidir.
 * Log formatı: [YYYY-MM-DD HH:MM:SS] [KULLANICI/ROL] [İŞLEM] [AÇIKLAMA]
 *
 * Hata yönetimi: Hatalar loglanmalı ve kullanıcıya açıklayıcı mesaj gösterilmelidir.
 */
// Amazon'a ürün gönderme, sipariş çekme gibi fonksiyonlar buraya yazılır

/**
 * Amazon API'ye bağlantı kurar
 * @param string $api_key Amazon API Key
 * @param string $api_secret Amazon API Secret
 * @param string $region Amazon region (e.g., eu, na, fe)
 * @return bool Başarı durumu
 */
function amazon_baglan($api_key, $api_secret, $region = 'eu') {
    $result = false;
    try {
        // Amazon Selling Partner API endpoint
        $endpoint = 'https://sellingpartnerapi-' . $region . '.amazon.com';
        
        // LWA (Login with Amazon) token alma
        $token_endpoint = 'https://api.amazon.com/auth/o2/token';
        $token_data = [
            'grant_type' => 'refresh_token',
            'refresh_token' => $api_secret,
            'client_id' => $api_key
        ];
        
        $ch = curl_init($token_endpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($token_data));
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            $token_response = json_decode($response, true);
            if (isset($token_response['access_token'])) {
                // Token alındı, API bağlantısı test edilecek
                // Satıcı profili API'si çağrılarak test edilir
                $headers = [
                    'Authorization: Bearer ' . $token_response['access_token'],
                    'Content-Type: application/json',
                    'x-amz-access-token: ' . $token_response['access_token']
                ];
                
                $ch = curl_init($endpoint . '/sellers/v1/marketplaceParticipations');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                $seller_response = curl_exec($ch);
                $seller_httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                
                if ($seller_httpcode == 200) {
                    $result = true;
                    amazon_logla('SISTEM', 'BAGLAN', 'Amazon API bağlantısı başarılı.');
                } else {
                    amazon_logla('SISTEM', 'HATA', 'Satıcı profili erişim hatası: HTTP ' . $seller_httpcode . ' - ' . $seller_response);
                }
            } else {
                amazon_logla('SISTEM', 'HATA', 'Token alınamadı: ' . $response);
            }
        } else {
            amazon_logla('SISTEM', 'HATA', 'Token endpoint hatası: HTTP ' . $httpcode . ' - ' . $response);
        }
    } catch (Exception $e) {
        amazon_logla('SISTEM', 'HATA', 'Bağlantı hatası: ' . $e->getMessage());
    }
    return $result;
}

/**
 * Amazon API'den token alır
 * @param string $api_key Amazon API Key
 * @param string $api_secret Amazon API Secret
 * @return string|false Token veya hata durumunda false
 */
function amazon_get_token($api_key, $api_secret) {
    try {
        $token_endpoint = 'https://api.amazon.com/auth/o2/token';
        $token_data = [
            'grant_type' => 'refresh_token',
            'refresh_token' => $api_secret,
            'client_id' => $api_key
        ];
        
        $ch = curl_init($token_endpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($token_data));
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            $token_response = json_decode($response, true);
            if (isset($token_response['access_token'])) {
                amazon_logla('SISTEM', 'TOKEN', 'Amazon API token başarıyla alındı.');
                return $token_response['access_token'];
            } else {
                amazon_logla('SISTEM', 'HATA', 'Token alınamadı: ' . $response);
            }
        } else {
            amazon_logla('SISTEM', 'HATA', 'Token endpoint hatası: HTTP ' . $httpcode . ' - ' . $response);
        }
    } catch (Exception $e) {
        amazon_logla('SISTEM', 'HATA', 'Token alma hatası: ' . $e->getMessage());
    }
    return false;
}

/**
 * Amazon'a ürün gönderir
 * @param array $urun Ürün verileri
 * @param string $api_key Amazon API Key
 * @param string $api_secret Amazon API Secret
 * @param string $region Amazon region
 * @param string $marketplace_id Amazon Marketplace ID
 * @return bool Başarı durumu
 */
function amazon_urun_gonder($urun, $api_key, $api_secret, $region = 'eu', $marketplace_id = '') {
    try {
        $token = amazon_get_token($api_key, $api_secret);
        if (!$token) {
            amazon_logla('SISTEM', 'HATA', 'Ürün gönderme için token alınamadı.');
            return false;
        }
        
        $endpoint = 'https://sellingpartnerapi-' . $region . '.amazon.com';
        
        // JSON formatında ürün verisi hazırla
        $product_data = [
            'marketplaceIds' => [$marketplace_id],
            'productType' => $urun['product_type'],
            'requirements' => 'LISTING',
            'attributes' => $urun['attributes']
        ];
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'x-amz-access-token: ' . $token
        ];
        
        // Ürün oluşturma API'sini çağır
        $ch = curl_init($endpoint . '/listings/2021-08-01/items');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($product_data));
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode >= 200 && $httpcode < 300) {
            amazon_logla('SISTEM', 'URUN_GONDER', 'Ürün başarıyla gönderildi: ' . json_encode($urun));
            return true;
        } else {
            amazon_logla('SISTEM', 'HATA', 'Ürün gönderme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return false;
        }
    } catch (Exception $e) {
        amazon_logla('SISTEM', 'HATA', 'Ürün gönderme hatası: ' . $e->getMessage());
        return false;
    }
}

/**
 * Amazon'dan sipariş çeker
 * @param string $tarih_araligi Başlangıç ve bitiş tarihi (format: YYYY-MM-DD,YYYY-MM-DD)
 * @param string $api_key Amazon API Key
 * @param string $api_secret Amazon API Secret
 * @param string $region Amazon region
 * @param string $marketplace_id Amazon Marketplace ID
 * @return array Siparişler dizisi
 */
function amazon_siparis_cek($tarih_araligi, $api_key, $api_secret, $region = 'eu', $marketplace_id = '') {
    try {
        $token = amazon_get_token($api_key, $api_secret);
        if (!$token) {
            amazon_logla('SISTEM', 'HATA', 'Sipariş çekme için token alınamadı.');
            return [];
        }
        
        // Tarih aralığını parçala (format: YYYY-MM-DD,YYYY-MM-DD)
        $dates = explode(',', $tarih_araligi);
        $startDate = isset($dates[0]) ? $dates[0] . 'T00:00:00Z' : date('Y-m-d', strtotime('-7 days')) . 'T00:00:00Z';
        $endDate = isset($dates[1]) ? $dates[1] . 'T23:59:59Z' : date('Y-m-d') . 'T23:59:59Z';
        
        $endpoint = 'https://sellingpartnerapi-' . $region . '.amazon.com';
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'x-amz-access-token: ' . $token
        ];
        
        // Sipariş çekme API'sini çağır
        $url = $endpoint . '/orders/v0/orders';
        $url .= '?MarketplaceIds=' . $marketplace_id;
        $url .= '&CreatedAfter=' . urlencode($startDate);
        $url .= '&CreatedBefore=' . urlencode($endDate);
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            $orders_response = json_decode($response, true);
            $siparisler = isset($orders_response['Orders']) ? $orders_response['Orders'] : [];
            amazon_logla('SISTEM', 'SIPARIS_CEK', 'Siparişler başarıyla çekildi: ' . $tarih_araligi . ', Toplam: ' . count($siparisler));
            return $siparisler;
        } else {
            amazon_logla('SISTEM', 'HATA', 'Sipariş çekme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return [];
        }
    } catch (Exception $e) {
        amazon_logla('SISTEM', 'HATA', 'Sipariş çekme hatası: ' . $e->getMessage());
        return [];
    }
}

/**
 * Loglama fonksiyonu
 */
function amazon_logla($user, $action, $message) {
    $log_file = DIR_LOGS . 'amazon_helper.log';
    $date = date('Y-m-d H:i:s');
    $log = "[$date] [$user] [$action] $message\n";
    file_put_contents($log_file, $log, FILE_APPEND);
}

/**
 * Amazon stok güncelleme fonksiyonu
 * @param array $stok_bilgisi Stok bilgisi (sku, quantity)
 * @param string $api_key Amazon API Key
 * @param string $api_secret Amazon API Secret
 * @param string $region Amazon region
 * @param string $marketplace_id Amazon Marketplace ID
 * @return bool Başarı durumu
 */
function amazon_stok_guncelle($stok_bilgisi, $api_key, $api_secret, $region = 'eu', $marketplace_id = '') {
    try {
        $token = amazon_get_token($api_key, $api_secret);
        if (!$token) {
            amazon_logla('SISTEM', 'HATA', 'Stok güncelleme için token alınamadı.');
            return false;
        }
        
        $endpoint = 'https://sellingpartnerapi-' . $region . '.amazon.com';
        
        // JSON formatında stok verisi hazırla
        $inventory_data = [
            'marketplaceIds' => [$marketplace_id],
            'issues' => [],
            'listings' => [
                [
                    'sku' => $stok_bilgisi['sku'],
                    'inventory' => [
                        'fulfillmentType' => 'MFN',
                        'quantity' => (int)$stok_bilgisi['quantity']
                    ]
                ]
            ]
        ];
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'x-amz-access-token: ' . $token
        ];
        
        // Stok güncelleme API'sini çağır
        $ch = curl_init($endpoint . '/listings/2021-08-01/inventory');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($inventory_data));
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode >= 200 && $httpcode < 300) {
            amazon_logla('SISTEM', 'STOK_GUNCELLE', 'Stok başarıyla güncellendi: ' . json_encode($stok_bilgisi));
            return true;
        } else {
            amazon_logla('SISTEM', 'HATA', 'Stok güncelleme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return false;
        }
    } catch (Exception $e) {
        amazon_logla('SISTEM', 'HATA', 'Stok güncelleme hatası: ' . $e->getMessage());
        return false;
    }
}

/**
 * Amazon fiyat güncelleme fonksiyonu
 * @param array $fiyat_bilgisi Fiyat bilgisi (sku, price, currency)
 * @param string $api_key Amazon API Key
 * @param string $api_secret Amazon API Secret
 * @param string $region Amazon region
 * @param string $marketplace_id Amazon Marketplace ID
 * @return bool Başarı durumu
 */
function amazon_fiyat_guncelle($fiyat_bilgisi, $api_key, $api_secret, $region = 'eu', $marketplace_id = '') {
    try {
        $token = amazon_get_token($api_key, $api_secret);
        if (!$token) {
            amazon_logla('SISTEM', 'HATA', 'Fiyat güncelleme için token alınamadı.');
            return false;
        }
        
        $endpoint = 'https://sellingpartnerapi-' . $region . '.amazon.com';
        
        // JSON formatında fiyat verisi hazırla
        $price_data = [
            'marketplaceIds' => [$marketplace_id],
            'issues' => [],
            'listings' => [
                [
                    'sku' => $fiyat_bilgisi['sku'],
                    'price' => [
                        'value' => (float)$fiyat_bilgisi['price'],
                        'currency' => $fiyat_bilgisi['currency'] ?? 'EUR'
                    ]
                ]
            ]
        ];
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'x-amz-access-token: ' . $token
        ];
        
        // Fiyat güncelleme API'sini çağır
        $ch = curl_init($endpoint . '/listings/2021-08-01/price');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($price_data));
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode >= 200 && $httpcode < 300) {
            amazon_logla('SISTEM', 'FIYAT_GUNCELLE', 'Fiyat başarıyla güncellendi: ' . json_encode($fiyat_bilgisi));
            return true;
        } else {
            amazon_logla('SISTEM', 'HATA', 'Fiyat güncelleme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return false;
        }
    } catch (Exception $e) {
        amazon_logla('SISTEM', 'HATA', 'Fiyat güncelleme hatası: ' . $e->getMessage());
        return false;
    }
}

/**
 * Amazon sipariş durumu güncelleme fonksiyonu
 * @param string $siparis_no Amazon sipariş numarası
 * @param string $durum Yeni durum (Shipped, Canceled)
 * @param string $api_key Amazon API Key
 * @param string $api_secret Amazon API Secret
 * @param string $region Amazon region
 * @return bool Başarı durumu
 */
function amazon_siparis_durum_guncelle($siparis_no, $durum, $api_key, $api_secret, $region = 'eu') {
    try {
        $token = amazon_get_token($api_key, $api_secret);
        if (!$token) {
            amazon_logla('SISTEM', 'HATA', 'Sipariş durumu güncelleme için token alınamadı.');
            return false;
        }
        
        $endpoint = 'https://sellingpartnerapi-' . $region . '.amazon.com';
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'x-amz-access-token: ' . $token
        ];
        
        // Durum tipine göre API çağrısı yap
        if ($durum === 'Shipped') {
            // Kargo bilgisi güncellemesi
            $shipping_data = [
                'marketplaceId' => 'A21TJRUUN4KGV', // Default, değiştirilebilir
                'shipmentStatus' => 'SHIPPED',
                'carrierCode' => 'OTHER',
                'shippingServiceOptions' => [
                    'carrierName' => 'Default Carrier',
                    'shippingServiceName' => 'Standard',
                ],
                'shippingServiceOptions' => [
                    'deliveryExperience' => 'DeliveryConfirmationWithoutSignature',
                    'carrierWillPickUp' => false
                ],
                'shipmentTrackingInfo' => [
                    'carrierCode' => 'OTHER',
                    'trackingNumber' => 'TRACK' . time()
                ]
            ];
            
            $url = $endpoint . '/orders/v0/orders/' . $siparis_no . '/shipment';
            $method = 'POST';
            $data = $shipping_data;
        } elseif ($durum === 'Canceled') {
            // İptal işlemi
            $cancel_data = [
                'cancelReason' => [
                    'reasonCode' => 'NoInventory',
                    'reasonDescription' => 'Out of stock'
                ]
            ];
            
            $url = $endpoint . '/orders/v0/orders/' . $siparis_no . '/cancel';
            $method = 'POST';
            $data = $cancel_data;
        } else {
            amazon_logla('SISTEM', 'HATA', 'Geçersiz sipariş durumu: ' . $durum);
            return false;
        }
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode >= 200 && $httpcode < 300) {
            amazon_logla('SISTEM', 'SIPARIS_DURUM', 'Sipariş durumu başarıyla güncellendi: ' . $siparis_no . ' -> ' . $durum);
            return true;
        } else {
            amazon_logla('SISTEM', 'HATA', 'Sipariş durumu güncelleme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return false;
        }
    } catch (Exception $e) {
        amazon_logla('SISTEM', 'HATA', 'Sipariş durumu güncelleme hatası: ' . $e->getMessage());
        return false;
    }
}

/**
 * Amazon kategori listesini çeker
 * @param string $api_key Amazon API Key
 * @param string $api_secret Amazon API Secret
 * @param string $region Amazon region
 * @param string $marketplace_id Amazon Marketplace ID
 * @return array Kategoriler dizisi
 */
function amazon_kategorileri_cek($api_key, $api_secret, $region = 'eu', $marketplace_id = '') {
    try {
        $token = amazon_get_token($api_key, $api_secret);
        if (!$token) {
            amazon_logla('SISTEM', 'HATA', 'Kategori çekme için token alınamadı.');
            return [];
        }
        
        $endpoint = 'https://sellingpartnerapi-' . $region . '.amazon.com';
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'x-amz-access-token: ' . $token
        ];
        
        // Kategori çekme API'sini çağır
        $url = $endpoint . '/definitions/2020-09-01/productTypes';
        $url .= '?marketplaceIds=' . $marketplace_id;
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            $response_data = json_decode($response, true);
            $kategoriler = isset($response_data['productTypes']) ? $response_data['productTypes'] : [];
            amazon_logla('SISTEM', 'KATEGORI_CEK', 'Kategoriler başarıyla çekildi. Toplam: ' . count($kategoriler));
            return $kategoriler;
        } else {
            amazon_logla('SISTEM', 'HATA', 'Kategori çekme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return [];
        }
    } catch (Exception $e) {
        amazon_logla('SISTEM', 'HATA', 'Kategori çekme hatası: ' . $e->getMessage());
        return [];
    }
}

/**
 * OpenCart ürününü Amazon formatına dönüştürür
 * @param array $opencart_product OpenCart ürün verisi
 * @return array Amazon formatında ürün
 */
function amazon_urun_formatla($opencart_product) {
    // Amazon ürün verisi
    $amazon_product = [
        'product_type' => 'PRODUCT', // Varsayılan, kategori eşleştirmesine göre değişmeli
        'attributes' => [
            'title' => $opencart_product['name'],
            'brand' => $opencart_product['manufacturer'],
            'description' => $opencart_product['description'],
            'bullet_point' => explode("\n", $opencart_product['meta_description']),
            'generic_keyword' => explode(',', $opencart_product['tag']),
            'model' => $opencart_product['model'],
            'part_number' => $opencart_product['sku'],
            'item_package_quantity' => 1,
            'standard_price' => $opencart_product['price'],
            'quantity' => $opencart_product['quantity'],
            'manufacturer' => $opencart_product['manufacturer'],
            'item_dimensions' => [
                'length' => [
                    'value' => $opencart_product['length'],
                    'unit' => 'CM'
                ],
                'width' => [
                    'value' => $opencart_product['width'],
                    'unit' => 'CM'
                ],
                'height' => [
                    'value' => $opencart_product['height'],
                    'unit' => 'CM'
                ],
                'weight' => [
                    'value' => $opencart_product['weight'],
                    'unit' => 'KG'
                ]
            ]
        ]
    ];
    
    // Ürün resimleri
    if (!empty($opencart_product['image'])) {
        $amazon_product['attributes']['main_image_url'] = HTTPS_CATALOG . 'image/' . $opencart_product['image'];
    }
    
    // Ek resimler
    if (isset($opencart_product['product_image']) && is_array($opencart_product['product_image'])) {
        $other_images = [];
        $image_index = 1;
        foreach ($opencart_product['product_image'] as $image) {
            $other_images['other_image_url' . $image_index] = HTTPS_CATALOG . 'image/' . $image['image'];
            $image_index++;
            if ($image_index > 8) break; // Amazon maksimum 8 ek resim kabul eder
        }
        $amazon_product['attributes'] = array_merge($amazon_product['attributes'], $other_images);
    }
    
    // Özellikler
    if (isset($opencart_product['product_attribute']) && is_array($opencart_product['product_attribute'])) {
        foreach ($opencart_product['product_attribute'] as $attribute) {
            $amazon_product['attributes'][$attribute['amazon_attribute_name']] = $attribute['text'];
        }
    }
    
    return $amazon_product;
}

// ... Yardımcı fonksiyonlar buraya eklenecek ... 