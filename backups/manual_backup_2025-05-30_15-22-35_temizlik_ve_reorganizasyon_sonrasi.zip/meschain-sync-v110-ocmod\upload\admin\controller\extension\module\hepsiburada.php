<?php
/**
 * hepsiburada.php
 *
 * Amaç: Hepsiburada modülünün OpenCart yönetici paneli (admin) tarafındaki controller dosyasıdır.
 *
 * Loglama: Tüm önemli işlemler ve hatalar hepsiburada_controller.log dosyasına kaydedilmelidir.
 * Log formatı: [YYYY-MM-DD HH:MM:SS] [KULLANICI/ROL] [İŞLEM] [AÇIKLAMA]
 *
 * Hata yönetimi: Hatalar loglanmalı ve kullanıcıya açıklayıcı mesaj gösterilmelidir.
 */

class ControllerExtensionModuleHepsiburada extends Controller {
    private $error = array();

    public function index() {
        $this->load->language('extension/module/hepsiburada');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('module_hepsiburada', $this->request->post);
            $this->writeLog('admin', 'AYAR_GUNCELLEME', 'Hepsiburada ayarları güncellendi.');
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('extension/module/hepsiburada', 'user_token=' . $this->session->data['user_token'], true));
        }

        // Heading
        $data['heading_title'] = $this->language->get('heading_title');
        
        // Text
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_api_settings'] = $this->language->get('text_api_settings');
        $data['text_api_info'] = $this->language->get('text_api_info');
        $data['text_api_info_desc'] = $this->language->get('text_api_info_desc');
        $data['text_status'] = $this->language->get('text_status');
        $data['text_test_connection'] = $this->language->get('text_test_connection');
        $data['tab_orders'] = $this->language->get('tab_orders');
        $data['tab_logs'] = $this->language->get('tab_logs');
        
        // Entry
        $data['entry_username'] = $this->language->get('entry_username');
        $data['entry_password'] = $this->language->get('entry_password');
        $data['entry_merchant_id'] = $this->language->get('entry_merchant_id');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_debug'] = $this->language->get('entry_debug');
        $data['entry_api_test'] = $this->language->get('entry_api_test');
        
        // Button
        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['button_test'] = $this->language->get('button_test');
        
        // URLs
        $data['action'] = $this->url->link('extension/module/hepsiburada', 'user_token=' . $this->session->data['user_token'], true);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
        $data['dashboard_url'] = $this->url->link('extension/module/hepsiburada/dashboard', 'user_token=' . $this->session->data['user_token'], true);
        $data['test_connection_url'] = $this->url->link('extension/module/hepsiburada/test_connection', 'user_token=' . $this->session->data['user_token'], true);
        
        // Form values
        if (isset($this->request->post['module_hepsiburada_username'])) {
            $data['module_hepsiburada_username'] = $this->request->post['module_hepsiburada_username'];
        } else {
            $data['module_hepsiburada_username'] = $this->config->get('module_hepsiburada_username');
        }
        
        if (isset($this->request->post['module_hepsiburada_password'])) {
            $data['module_hepsiburada_password'] = $this->request->post['module_hepsiburada_password'];
        } else {
            $data['module_hepsiburada_password'] = $this->config->get('module_hepsiburada_password');
        }
        
        if (isset($this->request->post['module_hepsiburada_merchant_id'])) {
            $data['module_hepsiburada_merchant_id'] = $this->request->post['module_hepsiburada_merchant_id'];
        } else {
            $data['module_hepsiburada_merchant_id'] = $this->config->get('module_hepsiburada_merchant_id');
        }
        
        if (isset($this->request->post['module_hepsiburada_status'])) {
            $data['module_hepsiburada_status'] = $this->request->post['module_hepsiburada_status'];
        } else {
            $data['module_hepsiburada_status'] = $this->config->get('module_hepsiburada_status');
        }
        
        if (isset($this->request->post['module_hepsiburada_debug'])) {
            $data['module_hepsiburada_debug'] = $this->request->post['module_hepsiburada_debug'];
        } else {
            $data['module_hepsiburada_debug'] = $this->config->get('module_hepsiburada_debug');
        }
        
        // Errors
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }
        
        if (isset($this->error['username'])) {
            $data['error_username'] = $this->error['username'];
        } else {
            $data['error_username'] = '';
        }
        
        if (isset($this->error['password'])) {
            $data['error_password'] = $this->error['password'];
        } else {
            $data['error_password'] = '';
        }
        
        if (isset($this->error['merchant_id'])) {
            $data['error_merchant_id'] = $this->error['merchant_id'];
        } else {
            $data['error_merchant_id'] = '';
        }
        
        // Success message
        $data['success'] = isset($this->session->data['success']) ? $this->session->data['success'] : '';
        unset($this->session->data['success']);
        
        // Breadcrumbs
        $data['breadcrumbs'] = array();
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/hepsiburada', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        // Load common template
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('extension/module/hepsiburada', $data));
    }

    public function dashboard() {
        $this->load->language('extension/module/hepsiburada');
        
        $this->document->setTitle($this->language->get('heading_title'));
        
        $data['heading_title'] = $this->language->get('heading_title');
        
        $data['breadcrumbs'] = array();
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/hepsiburada/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['test_connection'] = $this->url->link('extension/module/hepsiburada/test_connection', 'user_token=' . $this->session->data['user_token'], true);
        $data['sync_products'] = $this->url->link('extension/module/hepsiburada/sync_products', 'user_token=' . $this->session->data['user_token'], true);
        $data['get_orders'] = $this->url->link('extension/module/hepsiburada/get_orders', 'user_token=' . $this->session->data['user_token'], true);
        $data['update_stock'] = $this->url->link('extension/module/hepsiburada/update_stock', 'user_token=' . $this->session->data['user_token'], true);
        $data['update_prices'] = $this->url->link('extension/module/hepsiburada/update_prices', 'user_token=' . $this->session->data['user_token'], true);
        $data['settings'] = $this->url->link('extension/module/hepsiburada', 'user_token=' . $this->session->data['user_token'], true);
        
        // Get total products
        $this->load->model('catalog/product');
        $data['product_count'] = $this->model_catalog_product->getTotalProducts();
        
        // Get order count
        $data['order_count'] = 0;
        
        // Dashboard link urls
        $data['orders_url'] = $this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'], true);
        
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } elseif (isset($this->session->data['error_warning'])) {
            $data['error_warning'] = $this->session->data['error_warning'];
            unset($this->session->data['error_warning']);
        } else {
            $data['error_warning'] = '';
        }
        
        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }
        
        // Load common template
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('extension/module/hepsiburada_dashboard', $data));
    }

    public function test_connection() {
        $this->load->language('extension/module/hepsiburada');
        
        $json = array();
        
        $username = $this->config->get('module_hepsiburada_username');
        $password = $this->config->get('module_hepsiburada_password');
        $merchant_id = $this->config->get('module_hepsiburada_merchant_id');
        
        if (!$username || !$password || !$merchant_id) {
            $json['error'] = $this->language->get('error_credentials');
        } else {
            require_once(DIR_SYSTEM . 'library/hepsiburada/hepsiburada_api.php');
            
            $result = hepsiburada_baglan($username, $password);
            
            if ($result) {
                $json['success'] = $this->language->get('text_connection_success');
                $this->writeLog('admin', 'API_TEST', 'Hepsiburada API bağlantı testi başarılı.');
            } else {
                $json['error'] = $this->language->get('error_connection');
                $this->writeLog('admin', 'API_TEST_HATA', 'Hepsiburada API bağlantı testi başarısız.');
            }
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function sync_products() {
        $this->load->language('extension/module/hepsiburada');
        
        $json = array();
        
        if (!$this->validate()) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            $this->load->model('extension/module/hepsiburada');
            
            $result = $this->model_extension_module_hepsiburada->syncProducts();
            
            if ($result) {
                $json['success'] = sprintf($this->language->get('text_sync_success'), $result);
                $this->writeLog('admin', 'URUN_SYNC', 'Hepsiburada ürün senkronizasyonu başarılı: ' . $result . ' ürün');
            } else {
                $json['error'] = $this->language->get('error_sync');
                $this->writeLog('admin', 'URUN_SYNC_HATA', 'Hepsiburada ürün senkronizasyonu başarısız.');
            }
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function get_orders() {
        $this->load->language('extension/module/hepsiburada');
        
        $json = array();
        
        if (!$this->validate()) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            $this->load->model('extension/module/hepsiburada');
            
            $filter_data = array(
                'filter_date_start' => date('Y-m-d', strtotime('-7 days')),
                'filter_date_end' => date('Y-m-d'),
                'filter_status' => ''
            );
            
            $result = $this->model_extension_module_hepsiburada->getOrders($filter_data);
            
            if ($result !== false) {
                $json['success'] = sprintf($this->language->get('text_orders_success'), $result);
                $this->writeLog('admin', 'SIPARIS_CEK', 'Hepsiburada siparişleri başarıyla çekildi: ' . $result . ' sipariş');
            } else {
                $json['error'] = $this->language->get('error_orders');
                $this->writeLog('admin', 'SIPARIS_CEK_HATA', 'Hepsiburada siparişleri çekilemedi.');
            }
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function update_stock() {
        $this->load->language('extension/module/hepsiburada');
        
        $json = array();
        
        if (!$this->validate()) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            $this->load->model('extension/module/hepsiburada');
            
            $result = $this->model_extension_module_hepsiburada->updateStock();
            
            if ($result !== false) {
                $json['success'] = sprintf($this->language->get('text_stock_success'), $result);
                $this->writeLog('admin', 'STOK_GUNCELLE', 'Hepsiburada stok bilgileri güncellendi: ' . $result . ' ürün');
            } else {
                $json['error'] = $this->language->get('error_stock');
                $this->writeLog('admin', 'STOK_GUNCELLE_HATA', 'Hepsiburada stok güncellemesi başarısız.');
            }
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function update_prices() {
        $this->load->language('extension/module/hepsiburada');
        
        $json = array();
        
        if (!$this->validate()) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            $this->load->model('extension/module/hepsiburada');
            
            $result = $this->model_extension_module_hepsiburada->updatePrices();
            
            if ($result !== false) {
                $json['success'] = sprintf($this->language->get('text_price_success'), $result);
                $this->writeLog('admin', 'FIYAT_GUNCELLE', 'Hepsiburada fiyat bilgileri güncellendi: ' . $result . ' ürün');
            } else {
                $json['error'] = $this->language->get('error_price');
                $this->writeLog('admin', 'FIYAT_GUNCELLE_HATA', 'Hepsiburada fiyat güncellemesi başarısız.');
            }
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install() {
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting('module_hepsiburada', array(
            'module_hepsiburada_status' => 0,
            'module_hepsiburada_debug' => 1
        ));
        
        $this->writeLog('admin', 'KURULUM', 'Hepsiburada modülü kuruldu.');
    }

    public function uninstall() {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('module_hepsiburada');
        
        $this->writeLog('admin', 'KALDIRMA', 'Hepsiburada modülü kaldırıldı.');
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/hepsiburada')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        
        if ((utf8_strlen($this->request->post['module_hepsiburada_username'] ?? '') < 3)) {
            $this->error['username'] = $this->language->get('error_username');
        }
        
        if ((utf8_strlen($this->request->post['module_hepsiburada_password'] ?? '') < 5)) {
            $this->error['password'] = $this->language->get('error_password');
        }
        
        if (empty($this->request->post['module_hepsiburada_merchant_id'] ?? '')) {
            $this->error['merchant_id'] = $this->language->get('error_merchant_id');
        }
        
        return !$this->error;
    }

    private function writeLog($user, $action, $message) {
        $log_file = DIR_LOGS . 'hepsiburada_controller.log';
        $date = date('Y-m-d H:i:s');
        $log = "[$date] [$user] [$action] $message\n";
        file_put_contents($log_file, $log, FILE_APPEND);
    }

    public function orders() {
        $this->load->language('extension/module/hepsiburada');
        
        $this->document->setTitle($this->language->get('heading_title_orders'));
        
        if (isset($this->request->get['filter_order_id'])) {
            $filter_order_id = $this->request->get['filter_order_id'];
        } else {
            $filter_order_id = '';
        }
        
        if (isset($this->request->get['filter_customer'])) {
            $filter_customer = $this->request->get['filter_customer'];
        } else {
            $filter_customer = '';
        }
        
        if (isset($this->request->get['filter_status'])) {
            $filter_status = $this->request->get['filter_status'];
        } else {
            $filter_status = '';
        }
        
        if (isset($this->request->get['filter_date_start'])) {
            $filter_date_start = $this->request->get['filter_date_start'];
        } else {
            $filter_date_start = date('Y-m-d', strtotime('-7 days'));
        }
        
        if (isset($this->request->get['filter_date_end'])) {
            $filter_date_end = $this->request->get['filter_date_end'];
        } else {
            $filter_date_end = date('Y-m-d');
        }
        
        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'o.date_added';
        }
        
        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'DESC';
        }
        
        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }
        
        $url = '';
        
        if (isset($this->request->get['filter_order_id'])) {
            $url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
        }
        
        if (isset($this->request->get['filter_customer'])) {
            $url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
        }
        
        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }
        
        if (isset($this->request->get['filter_date_start'])) {
            $url .= '&filter_date_start=' . $this->request->get['filter_date_start'];
        }
        
        if (isset($this->request->get['filter_date_end'])) {
            $url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
        }
        
        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }
        
        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }
        
        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }
        
        $data['breadcrumbs'] = array();
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/hepsiburada', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title_orders'),
            'href' => $this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'] . $url, true)
        );
        
        $data['refresh'] = $this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'] . $url, true);
        $data['sync'] = $this->url->link('extension/module/hepsiburada/get_orders', 'user_token=' . $this->session->data['user_token'], true);
        
        $filter_data = array(
            'filter_order_id'        => $filter_order_id,
            'filter_customer'        => $filter_customer,
            'filter_status'          => $filter_status,
            'filter_date_start'      => $filter_date_start,
            'filter_date_end'        => $filter_date_end,
            'sort'                   => $sort,
            'order'                  => $order,
            'start'                  => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit'                  => $this->config->get('config_limit_admin')
        );
        
        $this->load->model('extension/module/hepsiburada');
        
        $order_total = $this->model_extension_module_hepsiburada->getTotalOrders($filter_data);
        $results = $this->model_extension_module_hepsiburada->getOrders($filter_data);
        
        $data['orders'] = array();
        
        foreach ($results as $result) {
            $data['orders'][] = array(
                'order_id'      => $result['order_id'],
                'customer'      => $result['customer'],
                'status'        => $result['status'],
                'total'         => $result['total'],
                'date_added'    => $result['date_added'],
                'view'          => $this->url->link('extension/module/hepsiburada/order_detail', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $result['order_id'] . $url, true),
                'convert'       => $this->url->link('extension/module/hepsiburada/convert_order', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $result['order_id'] . $url, true)
            );
        }
        
        $data['heading_title'] = $this->language->get('heading_title_orders');
        
        $data['text_list'] = $this->language->get('text_list');
        $data['text_no_results'] = $this->language->get('text_no_results');
        $data['text_confirm'] = $this->language->get('text_confirm');
        
        $data['column_order_id'] = $this->language->get('column_order_id');
        $data['column_customer'] = $this->language->get('column_customer');
        $data['column_status'] = $this->language->get('column_status');
        $data['column_total'] = $this->language->get('column_total');
        $data['column_date_added'] = $this->language->get('column_date_added');
        $data['column_action'] = $this->language->get('column_action');
        
        $data['entry_order_id'] = $this->language->get('entry_order_id');
        $data['entry_customer'] = $this->language->get('entry_customer');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_date_start'] = $this->language->get('entry_date_start');
        $data['entry_date_end'] = $this->language->get('entry_date_end');
        
        $data['button_view'] = $this->language->get('button_view');
        $data['button_convert'] = $this->language->get('button_convert');
        $data['button_filter'] = $this->language->get('button_filter');
        $data['button_sync'] = $this->language->get('button_sync');
        
        $data['user_token'] = $this->session->data['user_token'];
        
        if (isset($this->session->data['error_warning'])) {
            $data['error_warning'] = $this->session->data['error_warning'];
            unset($this->session->data['error_warning']);
        } else {
            $data['error_warning'] = '';
        }
        
        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }
        
        $url = '';
        
        if (isset($this->request->get['filter_order_id'])) {
            $url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
        }
        
        if (isset($this->request->get['filter_customer'])) {
            $url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
        }
        
        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }
        
        if (isset($this->request->get['filter_date_start'])) {
            $url .= '&filter_date_start=' . $this->request->get['filter_date_start'];
        }
        
        if (isset($this->request->get['filter_date_end'])) {
            $url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
        }
        
        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }
        
        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }
        
        $data['sort_order'] = $this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'] . '&sort=o.order_id' . $url, true);
        $data['sort_customer'] = $this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'] . '&sort=customer' . $url, true);
        $data['sort_status'] = $this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url, true);
        $data['sort_total'] = $this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'] . '&sort=total' . $url, true);
        $data['sort_date_added'] = $this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_added' . $url, true);
        
        $url = '';
        
        if (isset($this->request->get['filter_order_id'])) {
            $url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
        }
        
        if (isset($this->request->get['filter_customer'])) {
            $url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
        }
        
        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }
        
        if (isset($this->request->get['filter_date_start'])) {
            $url .= '&filter_date_start=' . $this->request->get['filter_date_start'];
        }
        
        if (isset($this->request->get['filter_date_end'])) {
            $url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
        }
        
        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }
        
        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }
        
        $pagination = new Pagination();
        $pagination->total = $order_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->url = $this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
        
        $data['pagination'] = $pagination->render();
        
        $data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($order_total - $this->config->get('config_limit_admin'))) ? $order_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $order_total, ceil($order_total / $this->config->get('config_limit_admin')));
        
        $data['filter_order_id'] = $filter_order_id;
        $data['filter_customer'] = $filter_customer;
        $data['filter_status'] = $filter_status;
        $data['filter_date_start'] = $filter_date_start;
        $data['filter_date_end'] = $filter_date_end;
        
        $data['sort'] = $sort;
        $data['order'] = $order;
        
        // Get order statuses
        $data['order_statuses'] = array();
        $data['order_statuses'][] = array(
            'text' => $this->language->get('text_all_status'),
            'value' => ''
        );
        
        $statuses = array('Open', 'Picking', 'Invoiced', 'Shipped', 'Delivered', 'Canceled');
        foreach ($statuses as $status) {
            $data['order_statuses'][] = array(
                'text' => $status,
                'value' => $status
            );
        }
        
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('extension/module/hepsiburada_orders', $data));
    }

    public function order_detail() {
        $this->load->language('extension/module/hepsiburada');
        
        $this->document->setTitle($this->language->get('heading_title_orders'));
        
        if (isset($this->request->get['order_id'])) {
            $order_id = $this->request->get['order_id'];
        } else {
            $order_id = 0;
        }
        
        $data['breadcrumbs'] = array();
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/hepsiburada', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title_orders'),
            'href' => $this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $order_id,
            'href' => $this->url->link('extension/module/hepsiburada/order_detail', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id, true)
        );
        
        $this->load->model('extension/module/hepsiburada');
        
        $order_info = $this->model_extension_module_hepsiburada->getOrder($order_id);
        
        if ($order_info) {
            $data['heading_title'] = $this->language->get('heading_title_order_detail');
            
            $data['text_order_detail'] = $this->language->get('text_order_detail');
            $data['text_order_id'] = $this->language->get('text_order_id');
            $data['text_customer'] = $this->language->get('text_customer');
            $data['text_status'] = $this->language->get('text_status');
            $data['text_date_added'] = $this->language->get('text_date_added');
            $data['text_products'] = $this->language->get('text_products');
            $data['text_history'] = $this->language->get('text_history');
            $data['text_no_results'] = $this->language->get('text_no_results');
            
            $data['column_product'] = $this->language->get('column_product');
            $data['column_model'] = $this->language->get('column_model');
            $data['column_quantity'] = $this->language->get('column_quantity');
            $data['column_price'] = $this->language->get('column_price');
            $data['column_total'] = $this->language->get('column_total');
            $data['column_date_added'] = $this->language->get('column_date_added');
            $data['column_status'] = $this->language->get('column_status');
            $data['column_comment'] = $this->language->get('column_comment');
            
            $data['button_back'] = $this->language->get('button_back');
            $data['button_convert'] = $this->language->get('button_convert');
            
            $data['back'] = $this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'], true);
            $data['convert'] = $this->url->link('extension/module/hepsiburada/convert_order', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id, true);
            
            $data['order_id'] = $order_id;
            $data['customer'] = $order_info['customer'];
            $data['status'] = $order_info['status'];
            $data['date_added'] = $order_info['date_added'];
            $data['total'] = $order_info['total'];
            
            $data['products'] = array();
            
            if (isset($order_info['products'])) {
                foreach ($order_info['products'] as $product) {
                    $data['products'][] = array(
                        'name'     => $product['name'],
                        'model'    => $product['model'],
                        'quantity' => $product['quantity'],
                        'price'    => $this->currency->format($product['price'], 'TRY'),
                        'total'    => $this->currency->format($product['total'], 'TRY')
                    );
                }
            }
            
            $data['history'] = array();
            
            if (isset($order_info['history'])) {
                foreach ($order_info['history'] as $history) {
                    $data['history'][] = array(
                        'date_added' => $history['date_added'],
                        'status'     => $history['status'],
                        'comment'    => $history['comment']
                    );
                }
            }
            
            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');
            
            $this->response->setOutput($this->load->view('extension/module/hepsiburada_order_detail', $data));
        } else {
            $this->session->data['error_warning'] = $this->language->get('error_order_not_found');
            
            $this->response->redirect($this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'], true));
        }
    }
    
    public function convert_order() {
        $this->load->language('extension/module/hepsiburada');
        
        if (isset($this->request->get['order_id'])) {
            $order_id = $this->request->get['order_id'];
        } else {
            $order_id = 0;
        }
        
        $this->load->model('extension/module/hepsiburada');
        
        $result = $this->model_extension_module_hepsiburada->convertToOrder($order_id);
        
        if ($result) {
            $this->session->data['success'] = sprintf($this->language->get('text_convert_success'), $order_id, $result);
            $this->writeLog('admin', 'SIPARIS_DONUSTUR', 'Hepsiburada siparişi OpenCart siparişine dönüştürüldü: ' . $order_id . ' -> ' . $result);
        } else {
            $this->session->data['error_warning'] = $this->language->get('error_convert');
            $this->writeLog('admin', 'SIPARIS_DONUSTUR_HATA', 'Hepsiburada siparişi dönüştürülemedi: ' . $order_id);
        }
        
        $this->response->redirect($this->url->link('extension/module/hepsiburada/orders', 'user_token=' . $this->session->data['user_token'], true));
    }
    
    public function getLogs() {
        $json = array();
        
        if (isset($this->request->get['type'])) {
            $type = $this->request->get['type'];
        } else {
            $type = 'controller';
        }
        
        switch ($type) {
            case 'controller':
                $file = DIR_LOGS . 'hepsiburada_controller.log';
                break;
            case 'helper':
                $file = DIR_LOGS . 'hepsiburada_helper.log';
                break;
            case 'model':
                $file = DIR_LOGS . 'hepsiburada_model.log';
                break;
            default:
                $file = DIR_LOGS . 'hepsiburada_controller.log';
        }
        
        if (file_exists($file)) {
            $json['log'] = file_get_contents($file, FILE_USE_INCLUDE_PATH, null);
        } else {
            $json['log'] = '';
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    public function clearLogs() {
        $json = array();
        
        file_put_contents(DIR_LOGS . 'hepsiburada_controller.log', '');
        file_put_contents(DIR_LOGS . 'hepsiburada_helper.log', '');
        file_put_contents(DIR_LOGS . 'hepsiburada_model.log', '');
        
        $json['success'] = $this->language->get('text_logs_cleared');
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
} 