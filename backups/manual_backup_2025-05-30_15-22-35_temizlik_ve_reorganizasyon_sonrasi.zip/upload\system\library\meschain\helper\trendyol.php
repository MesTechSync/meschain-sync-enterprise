<?php
/**
 * MeschainTrendyolHelper
 * 
 * Trendyol API entegrasyonu için yardımcı sınıf.
 * Bu sınıf Trendyol API'si ile iletişim kurma, sipariş oluşturma ve ürün senkronizasyonu gibi işlemleri yönetir.
 */
class MeschainTrendyolHelper {
    private $registry;
    private $config;
    private $log;
    private $db;
    private $session;
    private $currency;
    private $apiUrl = 'https://api.trendyol.com/sapigw/';
    private $apiSupplierId;
    private $apiKey;
    private $apiSecret;
    private $apiAuthorization;
    
    /**
     * Kurucu metod
     * 
     * @param object $registry OpenCart registry objesi
     */
    public function __construct($registry) {
        $this->registry = $registry;
        $this->config = $registry->get('config');
        $this->log = $registry->get('log');
        $this->db = $registry->get('db');
        $this->session = $registry->get('session');
        $this->currency = $registry->get('currency');
        
        $this->apiSupplierId = $this->config->get('module_trendyol_supplier_id');
        $this->apiKey = $this->config->get('module_trendyol_api_key');
        $this->apiSecret = $this->config->get('module_trendyol_api_secret');
        
        // Base64 kimlik doğrulama bilgilerini oluştur
        $this->apiAuthorization = base64_encode($this->apiKey . ':' . $this->apiSecret);
    }
    
    /**
     * API isteği gönder
     * 
     * @param string $endpoint API endpointi
     * @param array $data İstek verileri
     * @param string $method HTTP metodu (GET, POST, PUT, DELETE)
     * @return array Yanıt
     */
    public function apiRequest($endpoint, $data = array(), $method = 'GET') {
        $url = $this->apiUrl . $endpoint;
        
        // Supplier ID'yi URL'ye ekle (gerekiyorsa)
        if (strpos($url, '{supplierId}') !== false) {
            $url = str_replace('{supplierId}', $this->apiSupplierId, $url);
        }
        
        // URL parametrelerini ekle (GET istekleri için)
        if ($method == 'GET' && !empty($data)) {
            $url .= '?' . http_build_query($data);
        }
        
        $headers = array(
            'Authorization: Basic ' . $this->apiAuthorization,
            'Content-Type: application/json',
            'User-Agent: MesTech-Sync/1.0'
        );
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        if ($method == 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method == 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method == 'DELETE') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            $this->log->write('TRENDYOL API ERROR: ' . curl_error($ch));
            curl_close($ch);
            return array(
                'status' => false,
                'code' => 0,
                'message' => curl_error($ch)
            );
        }
        
        curl_close($ch);
        
        $responseData = json_decode($response, true);
        
        // API hata kontrolü
        if ($httpCode >= 400) {
            $errorMessage = isset($responseData['errors'][0]['message']) ? $responseData['errors'][0]['message'] : 'Unknown error';
            $this->log->write('TRENDYOL API ERROR: ' . $errorMessage . ' (' . $httpCode . ')');
            return array(
                'status' => false,
                'code' => $httpCode,
                'message' => $errorMessage,
                'data' => $responseData
            );
        }
        
        return array(
            'status' => true,
            'code' => $httpCode,
            'data' => $responseData
        );
    }
    
    /**
     * Bağlantıyı test et
     * 
     * @return array Test sonucu
     */
    public function testConnection() {
        // Supplier bilgilerini getirerek API bağlantısını test et
        $response = $this->apiRequest('suppliers/' . $this->apiSupplierId);
        
        if ($response['status']) {
            return array(
                'status' => true,
                'message' => 'API connection successful!',
                'data' => $response['data']
            );
        } else {
            return array(
                'status' => false,
                'message' => 'API connection failed: ' . $response['message']
            );
        }
    }
    
    /**
     * Trendyol siparişlerini getir
     * 
     * @param string $startDate Başlangıç tarihi (YYYY-MM-DD)
     * @param string $endDate Bitiş tarihi (YYYY-MM-DD)
     * @param int $page Sayfa numarası
     * @param int $size Sayfa başına sonuç sayısı
     * @return array Siparişler
     */
    public function getOrders($startDate = '', $endDate = '', $page = 0, $size = 100) {
        if (empty($startDate)) {
            $startDate = date('Y-m-d', strtotime('-7 days'));
        }
        
        if (empty($endDate)) {
            $endDate = date('Y-m-d');
        }
        
        $params = array(
            'startDate' => strtotime($startDate) * 1000, // Milisaniye cinsinden
            'endDate' => strtotime($endDate . ' 23:59:59') * 1000, // Milisaniye cinsinden
            'page' => $page,
            'size' => $size
        );
        
        $response = $this->apiRequest('suppliers/' . $this->apiSupplierId . '/orders', $params);
        
        return $response;
    }
    
    /**
     * Sipariş detaylarını getir
     * 
     * @param string $orderId Sipariş ID
     * @return array Sipariş detayları
     */
    public function getOrderDetails($orderId) {
        $response = $this->apiRequest('suppliers/' . $this->apiSupplierId . '/orders/' . $orderId);
        return $response;
    }
    
    /**
     * Stok güncelle
     * 
     * @param array $products Ürünler
     * @return array Güncelleme sonucu
     */
    public function updateStock($products) {
        $items = array();
        
        foreach ($products as $product) {
            $items[] = array(
                'barcode' => $product['barcode'],
                'quantity' => (int)$product['quantity']
            );
        }
        
        $data = array(
            'items' => $items
        );
        
        $response = $this->apiRequest('suppliers/' . $this->apiSupplierId . '/products/price-and-inventory', $data, 'PUT');
        
        return $response;
    }
    
    /**
     * Fiyat güncelle
     * 
     * @param array $products Ürünler
     * @return array Güncelleme sonucu
     */
    public function updatePrice($products) {
        $items = array();
        
        foreach ($products as $product) {
            $items[] = array(
                'barcode' => $product['barcode'],
                'price' => (float)$product['price']
            );
        }
        
        $data = array(
            'items' => $items
        );
        
        $response = $this->apiRequest('suppliers/' . $this->apiSupplierId . '/products/price-and-inventory', $data, 'PUT');
        
        return $response;
    }
    
    /**
     * Kategori listesini getir
     * 
     * @return array Kategoriler
     */
    public function getCategories() {
        $response = $this->apiRequest('product-categories');
        return $response;
    }
    
    /**
     * Marka listesini getir
     * 
     * @return array Markalar
     */
    public function getBrands() {
        $response = $this->apiRequest('brands');
        return $response;
    }
    
    /**
     * Trendyol siparişini OpenCart siparişine dönüştür
     * 
     * @param array $trendyolOrder Trendyol sipariş verileri
     * @return array OpenCart sipariş verileri
     */
    public function createOrderFromTrendyol($trendyolOrder) {
        // Registry'den gerekli sınıfları al
        $this->load = $this->registry->get('load');
        $this->load->model('checkout/order');
        $this->load->model('catalog/product');
        $this->load->model('localisation/country');
        $this->load->model('localisation/zone');
        $this->load->model('customer/customer');
        
        // Temel sipariş bilgileri
        $orderId = $trendyolOrder['id'];
        $orderNumber = $trendyolOrder['orderNumber'];
        $status = $trendyolOrder['status'];
        $totalPrice = $trendyolOrder['totalPrice'];
        $customerName = $trendyolOrder['customerFirstName'] . ' ' . $trendyolOrder['customerLastName'];
        
        // Adres bilgileri
        $address = '';
        $district = '';
        $city = '';
        $postalCode = '';
        
        if (isset($trendyolOrder['shipmentAddress'])) {
            $address = $trendyolOrder['shipmentAddress']['address'];
            $district = $trendyolOrder['shipmentAddress']['district'];
            $city = $trendyolOrder['shipmentAddress']['city'];
            $postalCode = isset($trendyolOrder['shipmentAddress']['postalCode']) ? $trendyolOrder['shipmentAddress']['postalCode'] : '';
        }
        
        // Müşteri e-posta ve telefon
        $customerEmail = isset($trendyolOrder['customerEmail']) ? $trendyolOrder['customerEmail'] : '';
        $customerPhone = isset($trendyolOrder['shipmentAddress']['phoneNumber']) ? $trendyolOrder['shipmentAddress']['phoneNumber'] : '';
        
        // E-posta veya telefon yoksa geçici oluştur
        if (empty($customerEmail)) {
            $customerEmail = 'trendyol_' . $orderNumber . '@example.com';
        }
        
        // Müşteri kontrolü yap, yoksa oluştur
        $customer_id = 0;
        $customer_group_id = $this->config->get('config_customer_group_id');
        
        $customer_info = $this->db->query("SELECT * FROM " . DB_PREFIX . "customer WHERE email = '" . $this->db->escape($customerEmail) . "'")->row;
        
        if ($customer_info) {
            $customer_id = $customer_info['customer_id'];
            $customer_group_id = $customer_info['customer_group_id'];
        }
        
        // Ülke ve bölge bilgilerini ayarla (Türkiye için)
        $country_id = 0;
        $zone_id = 0;
        
        $country_info = $this->model_localisation_country->getCountryByName('Turkey');
        if ($country_info) {
            $country_id = $country_info['country_id'];
            
            // Şehir adına göre bölge arama
            $zone_info = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone WHERE country_id = '" . (int)$country_id . "' AND (name = '" . $this->db->escape($city) . "' OR name LIKE '" . $this->db->escape($city) . "%')")->row;
            if ($zone_info) {
                $zone_id = $zone_info['zone_id'];
            }
        }
        
        // Sipariş ürünlerini hazırla
        $products = array();
        $subtotal = 0;
        
        if (isset($trendyolOrder['lines']) && is_array($trendyolOrder['lines'])) {
            foreach ($trendyolOrder['lines'] as $line) {
                $barcode = $line['barcode'];
                $productName = $line['productName'];
                $quantity = $line['quantity'];
                $price = $line['price'];
                $totalLineAmount = $line['amount'];
                
                // Ürünü barkoda göre ara
                $product_id = 0;
                $product_info = null;
                
                $product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product WHERE sku = '" . $this->db->escape($barcode) . "' OR upc = '" . $this->db->escape($barcode) . "' OR ean = '" . $this->db->escape($barcode) . "' OR jan = '" . $this->db->escape($barcode) . "' OR isbn = '" . $this->db->escape($barcode) . "' OR mpn = '" . $this->db->escape($barcode) . "'");
                
                if ($product_query->num_rows) {
                    $product_info = $product_query->row;
                    $product_id = $product_info['product_id'];
                }
                
                $subtotal += $totalLineAmount;
                
                $products[] = array(
                    'product_id' => $product_id,
                    'name' => $productName,
                    'model' => $barcode,
                    'quantity' => $quantity,
                    'price' => $price,
                    'total' => $totalLineAmount,
                    'tax' => 0,
                    'reward' => 0
                );
            }
        }
        
        // Kargo bedeli
        $shipping_cost = isset($trendyolOrder['cargoPrice']) ? $trendyolOrder['cargoPrice'] : 0;
        
        // Sipariş toplamları
        $order_data = array();
        
        $order_data['invoice_prefix'] = $this->config->get('config_invoice_prefix');
        $order_data['store_id'] = $this->config->get('config_store_id');
        $order_data['store_name'] = $this->config->get('config_name');
        
        $order_data['customer_id'] = $customer_id;
        $order_data['customer_group_id'] = $customer_group_id;
        $order_data['firstname'] = $trendyolOrder['customerFirstName'];
        $order_data['lastname'] = $trendyolOrder['customerLastName'];
        $order_data['email'] = $customerEmail;
        $order_data['telephone'] = $customerPhone;
        
        // Fatura adresi
        $order_data['payment_firstname'] = $trendyolOrder['customerFirstName'];
        $order_data['payment_lastname'] = $trendyolOrder['customerLastName'];
        $order_data['payment_company'] = '';
        $order_data['payment_address_1'] = $address;
        $order_data['payment_address_2'] = '';
        $order_data['payment_city'] = $city;
        $order_data['payment_postcode'] = $postalCode;
        $order_data['payment_zone'] = $city;
        $order_data['payment_zone_id'] = $zone_id;
        $order_data['payment_country'] = 'Turkey';
        $order_data['payment_country_id'] = $country_id;
        $order_data['payment_address_format'] = '';
        $order_data['payment_method'] = 'Trendyol';
        $order_data['payment_code'] = 'trendyol';
        
        // Teslimat adresi
        $order_data['shipping_firstname'] = $trendyolOrder['customerFirstName'];
        $order_data['shipping_lastname'] = $trendyolOrder['customerLastName'];
        $order_data['shipping_company'] = '';
        $order_data['shipping_address_1'] = $address;
        $order_data['shipping_address_2'] = '';
        $order_data['shipping_city'] = $city;
        $order_data['shipping_postcode'] = $postalCode;
        $order_data['shipping_zone'] = $city;
        $order_data['shipping_zone_id'] = $zone_id;
        $order_data['shipping_country'] = 'Turkey';
        $order_data['shipping_country_id'] = $country_id;
        $order_data['shipping_address_format'] = '';
        $order_data['shipping_method'] = 'Trendyol';
        $order_data['shipping_code'] = 'trendyol';
        
        // Ürünler
        $order_data['products'] = $products;
        
        // Toplam bilgileri
        $order_data['comment'] = 'Trendyol Order #' . $orderNumber;
        $order_data['total'] = $totalPrice;
        $order_data['affiliate_id'] = 0;
        $order_data['commission'] = 0;
        $order_data['marketing_id'] = 0;
        $order_data['tracking'] = '';
        $order_data['language_id'] = $this->config->get('config_language_id');
        $order_data['currency_id'] = $this->currency->getId($this->config->get('config_currency'));
        $order_data['currency_code'] = $this->config->get('config_currency');
        $order_data['currency_value'] = $this->currency->getValue($this->config->get('config_currency'));
        $order_data['ip'] = '';
        $order_data['forwarded_ip'] = '';
        $order_data['user_agent'] = 'Trendyol API';
        $order_data['accept_language'] = 'tr-tr';
        
        $order_data['totals'] = array(
            array(
                'code' => 'sub_total',
                'title' => 'Sub-Total',
                'value' => $subtotal,
                'sort_order' => 1
            ),
            array(
                'code' => 'shipping',
                'title' => 'Shipping',
                'value' => $shipping_cost,
                'sort_order' => 3
            ),
            array(
                'code' => 'total',
                'title' => 'Total',
                'value' => $totalPrice,
                'sort_order' => 9
            )
        );
        
        // Sipariş durumu
        $order_status_id = $this->config->get('config_order_status_id');
        
        // Trendyol sipariş durumuna göre OpenCart sipariş durumunu ayarla
        switch ($status) {
            case 'Created':
                $order_status_id = 1; // Pending
                break;
            case 'Picking':
                $order_status_id = 2; // Processing
                break;
            case 'Invoiced':
                $order_status_id = 2; // Processing
                break;
            case 'Shipped':
                $order_status_id = 3; // Shipped
                break;
            case 'Cancelled':
                $order_status_id = 7; // Canceled
                break;
            case 'Delivered':
                $order_status_id = 5; // Complete
                break;
            case 'UnDelivered':
                $order_status_id = 10; // Failed
                break;
            case 'Returned':
                $order_status_id = 11; // Refunded
                break;
            default:
                $order_status_id = 1; // Pending
                break;
        }
        
        $order_data['order_status_id'] = $order_status_id;
        
        return $order_data;
    }
} 