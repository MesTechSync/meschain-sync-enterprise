# Klasör: admin/language/en-gb/module

## Amaç
Bu klasör, OpenCart modülleri için İngilizce dil dosyalarını barındırır.

## İçerik
- Her modül için ayrı bir dil dosyası (ör: entegrator.php)
- Dil dosyaları, modül arayüzündeki metinleri içerir.

## Standartlar
- Dosya isimleri: <modül_adı>.php
- Her dosyanın başında açıklama bloğu bulunmalı.

## Örnek Dosya
- entegrator.php

---
Her dil dosyası, ilgili modülün arayüz metinlerini ve açıklamalarını içermelidir. 