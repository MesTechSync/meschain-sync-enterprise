<?php
/**
 * Security Helper Class
 * Tüm güvenlik işlemlerini merkezi olarak yönetir
 */
class SecurityHelper {
    
    /**
     * CSRF token oluşturur
     */
    public static function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    /**
     * CSRF token doğrular
     */
    public static function validateCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * Input sanitization
     */
    public static function sanitizeInput($data, $type = 'string') {
        switch ($type) {
            case 'int':
                return (int) filter_var($data, FILTER_SANITIZE_NUMBER_INT);
            case 'email':
                return filter_var($data, FILTER_SANITIZE_EMAIL);
            case 'url':
                return filter_var($data, FILTER_SANITIZE_URL);
            case 'html':
                return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
            default:
                return filter_var($data, FILTER_SANITIZE_STRING);
        }
    }
    
    /**
     * API key şifreleme
     */
    public static function encryptApiKey($key) {
        $method = 'AES-256-CBC';
        $secret_key = hash('sha256', 'MESCHAIN_SECRET_KEY');
        $secret_iv = substr(hash('sha256', 'MESCHAIN_SECRET_IV'), 0, 16);
        
        return base64_encode(openssl_encrypt($key, $method, $secret_key, 0, $secret_iv));
    }
    
    /**
     * API key şifre çözme
     */
    public static function decryptApiKey($encrypted_key) {
        $method = 'AES-256-CBC';
        $secret_key = hash('sha256', 'MESCHAIN_SECRET_KEY');
        $secret_iv = substr(hash('sha256', 'MESCHAIN_SECRET_IV'), 0, 16);
        
        return openssl_decrypt(base64_decode($encrypted_key), $method, $secret_key, 0, $secret_iv);
    }
    
    /**
     * Rate limiting kontrolü
     */
    public static function checkRateLimit($user_id, $action, $limit = 60, $window = 60) {
        $cache_key = "rate_limit_{$user_id}_{$action}";
        $current_count = Cache::get($cache_key) ?: 0;
        
        if ($current_count >= $limit) {
            return false;
        }
        
        Cache::set($cache_key, $current_count + 1, $window);
        return true;
    }
    
    /**
     * IP validasyonu
     */
    public static function validateIP($ip) {
        return filter_var($ip, FILTER_VALIDATE_IP) !== false;
    }
    
    /**
     * SQL injection koruması
     */
    public static function escapeSQL($db, $value) {
        return $db->escape($value);
    }
} 