-- MesChain Sync Kaldırma SQL Dosyası
-- Versiyon: 1.0.1
-- Tarih: 2023-11-20

-- Tabloları kaldır
DROP TABLE IF EXISTS `oc_meschain_announcement`;
DROP TABLE IF EXISTS `oc_meschain_announcement_user`;
DROP TABLE IF EXISTS `oc_meschain_user_setting`;
DROP TABLE IF EXISTS `oc_meschain_marketplace`;
DROP TABLE IF EXISTS `oc_meschain_product_mapping`;
DROP TABLE IF EXISTS `oc_meschain_order_mapping`;
DROP TABLE IF EXISTS `oc_meschain_theme`;