# Klasör: system/library/entegrator

## Amaç
Bu klasör, OpenCart modülünün çekirdek entegrasyon dosyalarını barındırır.

## İçerik
- api/: Dış sistemlerle entegrasyon için API dosyaları
- helper/: Yardımcı fonksiyonlar ve veri tabanı sürücüleri
- config.php: Modülün ana ayar dosyası

## Standartlar
- Her alt klasör ve dosya için açıklama ve log şablonu bulunmalı.

---
Bu klasör, modülün çekirdek entegrasyon işlevlerini içerir ve her dosya açıkça belgelenmelidir. 