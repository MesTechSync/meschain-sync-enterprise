# CHANGELOG (ozon)

## 2025-05-29
- Ozon modülü için OpenCart şablon dosyaları oluşturuldu.
- Loglama ve hata yönetimi standartları uygulandı. 