# CHANGELOG (n11)

## 2025-05-29
- n11 modülü için OpenCart şablon dosyaları oluşturuldu.
- Loglama ve hata yönetimi standartları uygulandı. 