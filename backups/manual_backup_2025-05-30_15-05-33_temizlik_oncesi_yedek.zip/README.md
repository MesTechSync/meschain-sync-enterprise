# MesChain-Sync: Trendyol Entegrasyon Modülü

## Genel Bakış

MesChain-Sync, OpenCart e-ticaret platformu için geliştirilmiş kapsamlı bir Trendyol pazaryeri entegrasyon modülüdür. Bu modül, OpenCart mağazaları ile Trendyol pazaryeri arasında ürün, stok, fiyat ve sipariş senkronizasyonu sağlayarak satıcıların çoklu pazaryeri yönetimini kolaylaştırır.

## Özellikler

- **Ürün Yönetimi**: OpenCart ürünlerini Trendyol'a aktarma ve senkronize etme
- **Stok ve Fiyat Yönetimi**: Gerçek zamanlı stok ve fiyat güncellemeleri
- **Sipariş Yönetimi**: Trendyol siparişlerini otomatik çekme ve OpenCart'a dönüştürme
- **Ürün Eşleştirme**: Trendyol kategorileri ve markaları ile OpenCart ürünlerini eşleştirme
- **Kapsamlı Raporlama**: Satış, ürün performansı ve platform karşılaştırma raporları
- **Çoklu Dil Desteği**: Türkçe ve İngilizce arayüz

## Kurulum

### Gereksinimler

- OpenCart 3.0.0 veya üzeri
- PHP 7.3 veya üzeri
- cURL ve JSON PHP eklentileri
- Geçerli Trendyol API bilgileri

### Kurulum Adımları

1. Dosyaları OpenCart dizinine yükleyin
2. Yönetici panelinde Extensions > Extensions sayfasına gidin
3. "Modules" tipini seçin ve "Trendyol Entegrasyonu" modülünü bulun
4. "Install" butonuna tıklayın
5. "Edit" butonuna tıklayarak ayarları yapılandırın
6. API bilgilerinizi girin ve bağlantıyı test edin

## Kullanım

### Dashboard

Dashboard, modülün ana kontrol merkezidir ve şunları içerir:
- Özet istatistikler
- Hızlı erişim butonları (Siparişleri Al, Ürün Senkronizasyonu, Stok/Fiyat Güncelleme)
- API bağlantı durumu

### Ürün Eşleştirme

Ürünlerinizi Trendyol'a göndermeden önce:
1. "Ürün Eşleştirme" sayfasına gidin
2. OpenCart ürünlerinizi Trendyol kategorileri ve markalarıyla eşleştirin
3. Toplu eşleştirme özelliğini kullanarak çok sayıda ürünü hızlıca eşleştirin

### Sipariş Yönetimi

1. "Siparişler" sayfasında Trendyol siparişlerini görüntüleyin
2. "Siparişleri Al" butonu ile en son siparişleri çekin
3. Detayları görüntülemek için bir siparişe tıklayın
4. "OpenCart'a Dönüştür" butonu ile siparişi OpenCart'a aktarın

### Raporlar

Raporlar bölümünde şu bilgilere erişebilirsiniz:
- Günlük/haftalık/aylık satış istatistikleri
- En çok satan ürünler
- Pazar payı ve büyüme oranı
- Trendyol ve diğer platformlar arasında karşılaştırmalar

## Teknik Mimari

MesChain-Sync, MVC (Model-View-Controller) mimarisi üzerine inşa edilmiştir:

- **Controller**: Kullanıcı isteklerini yönetir ve uygun işlemleri çağırır
- **Model**: Veritabanı işlemlerini gerçekleştirir
- **View**: Kullanıcı arayüzünü oluşturur
- **Helper**: Trendyol API entegrasyonu için yardımcı sınıflar içerir

API istekleri güvenli bir şekilde yönetilir ve hassas veriler şifrelenir. Tüm işlemler ayrıntılı olarak loglanır.

## Sürüm Geçmişi

### v1.0.0 (Mevcut)
- Temel Trendyol API entegrasyonu
- Ürün, stok ve fiyat senkronizasyonu
- Sipariş yönetimi ve dönüştürme
- Ürün eşleştirme sistemi
- Temel raporlama özellikleri

## İletişim ve Destek

Modül hakkında sorularınız için:
- E-posta: destek@meschain-sync.com
- Destek sayfası: https://meschain-sync.com/support
- GitHub: https://github.com/meschain-sync/trendyol-integration 