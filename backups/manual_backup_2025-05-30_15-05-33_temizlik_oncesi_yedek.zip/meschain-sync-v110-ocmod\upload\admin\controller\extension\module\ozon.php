<?php
/**
 * Ozon Marketplace Controller
 * MesChain-Sync entegrasyonu için Ozon pazaryeri controller sınıfı.
 */
require_once(DIR_APPLICATION . 'controller/extension/module/base_marketplace.php');

class ControllerExtensionModuleOzon extends ControllerExtensionModuleBaseMarketplace {
    
    public function __construct($registry) {
        parent::__construct($registry);
        $this->marketplace_name = 'ozon';
    }
    
    /**
     * Ana dashboard
     */
    public function index() {
        $this->load->language('extension/module/ozon');
        $this->document->setTitle($this->language->get('heading_title'));
        
        // Güvenlik kontrolü
        if (!$this->validateAccess()) {
            $this->response->redirect($this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true));
            return;
        }
        
        // POST işlemi
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->saveSettings($this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->getCurrentUrl());
        }
        
        $data = $this->prepareCommonData();
        $data = array_merge($data, $this->prepareMarketplaceData());
        
        $this->renderView('ozon', $data);
    }
    
    /**
     * Dashboard
     */
    public function dashboard() {
        if (!$this->checkApiCredentials()) {
            $this->session->data['error_warning'] = $this->language->get('error_api_connect');
            $this->response->redirect($this->getConfigUrl());
            return;
        }
        
        $data = $this->prepareCommonData();
        $data['statistics'] = $this->getStatistics();
        $data['recent_activities'] = $this->getRecentActivities();
        
        $this->renderView('ozon_dashboard', $data);
    }
    
    /**
     * Ürün yönetimi
     */
    public function products() {
        if (!$this->validateOperation()) {
            return;
        }
        
        $this->load->language('extension/module/ozon');
        $this->document->setTitle($this->language->get('heading_title') . ' - ' . $this->language->get('text_products'));
        
        $user_id = $this->user->getId();
        
        // API Helper
        $credentials = $this->getApiCredentials();
        $this->initializeApiHelper($credentials);
        
        $data = $this->prepareCommonData();
        
        // Ürün listesi
        $page = isset($this->request->get['page']) ? (int)$this->request->get['page'] : 1;
        $pageSize = 20;
        
        $products = $this->api_helper->getProducts($page, $pageSize);
        
        if ($products) {
            $data['products'] = $products['items'];
            $data['total_products'] = $products['total'];
        } else {
            $data['products'] = array();
            $data['total_products'] = 0;
        }
        
        // Pagination
        $pagination = new Pagination();
        $pagination->total = $data['total_products'];
        $pagination->page = $page;
        $pagination->limit = $pageSize;
        $pagination->url = $this->url->link('extension/module/ozon/products', 'user_token=' . $this->session->data['user_token'] . '&page={page}', true);
        
        $data['pagination'] = $pagination->render();
        $data['results'] = sprintf($this->language->get('text_pagination'), ($data['total_products']) ? (($page - 1) * $pageSize) + 1 : 0, ((($page - 1) * $pageSize) > ($data['total_products'] - $pageSize)) ? $data['total_products'] : ((($page - 1) * $pageSize) + $pageSize), $data['total_products'], ceil($data['total_products'] / $pageSize));
        
        $this->renderView('ozon_products', $data);
    }
    
    /**
     * Siparişler
     */
    public function orders() {
        if (!$this->validateOperation()) {
            return;
        }
        
        $this->load->language('extension/module/ozon');
        $this->document->setTitle($this->language->get('heading_title') . ' - ' . $this->language->get('text_orders'));
        
        $user_id = $this->user->getId();
        
        // API Helper
        $credentials = $this->getApiCredentials();
        $this->initializeApiHelper($credentials);
        
        $data = $this->prepareCommonData();
        
        // Sipariş listesi
        $page = isset($this->request->get['page']) ? (int)$this->request->get['page'] : 1;
        $pageSize = 20;
        $status = isset($this->request->get['status']) ? $this->request->get['status'] : null;
        
        $orders = $this->api_helper->getOrders(null, null, $status, $page, $pageSize);
        
        if ($orders) {
            $data['orders'] = $orders['postings'];
            $data['total_orders'] = $orders['total'];
        } else {
            $data['orders'] = array();
            $data['total_orders'] = 0;
        }
        
        // Pagination
        $pagination = new Pagination();
        $pagination->total = $data['total_orders'];
        $pagination->page = $page;
        $pagination->limit = $pageSize;
        $pagination->url = $this->url->link('extension/module/ozon/orders', 'user_token=' . $this->session->data['user_token'] . '&page={page}' . ($status ? '&status=' . $status : ''), true);
        
        $data['pagination'] = $pagination->render();
        $data['results'] = sprintf($this->language->get('text_pagination'), ($data['total_orders']) ? (($page - 1) * $pageSize) + 1 : 0, ((($page - 1) * $pageSize) > ($data['total_orders'] - $pageSize)) ? $data['total_orders'] : ((($page - 1) * $pageSize) + $pageSize), $data['total_orders'], ceil($data['total_orders'] / $pageSize));
        
        // Sipariş durumları
        $data['order_statuses'] = array(
            'awaiting_packaging' => $this->language->get('status_awaiting_packaging'),
            'awaiting_deliver' => $this->language->get('status_awaiting_deliver'),
            'delivering' => $this->language->get('status_delivering'),
            'delivered' => $this->language->get('status_delivered'),
            'cancelled' => $this->language->get('status_cancelled')
        );
        
        $data['current_status'] = $status;
        
        $this->renderView('ozon_orders', $data);
    }
    
    /**
     * Ozon'a özgü veri hazırlama
     */
    protected function prepareMarketplaceData() {
        $user_id = $this->user->getId();
        $data = array();
        
        // Kullanıcı API ayarları
        $api_settings = $this->getUserApiSettings($user_id);
        
        foreach (array('client_id', 'api_key') as $field) {
            $key = 'module_ozon_' . $field;
            $data[$key] = isset($api_settings[$field]) ? $api_settings[$field] : '';
        }
        
        // Ozon'a özel URL'ler
        $data['products_url'] = $this->url->link('extension/module/ozon/products', 'user_token=' . $this->session->data['user_token'], true);
        $data['orders_url'] = $this->url->link('extension/module/ozon/orders', 'user_token=' . $this->session->data['user_token'], true);
        $data['settings_url'] = $this->url->link('extension/module/ozon/settings', 'user_token=' . $this->session->data['user_token'], true);
        
        return $data;
    }
    
    /**
     * Ürün hazırlama (Ozon formatı)
     */
    protected function prepareProductForMarketplace($product) {
        // Ozon ürün formatı
        $images = array();
        if ($product['image']) {
            $images[] = HTTPS_CATALOG . 'image/' . $product['image'];
        }
        
        // Ürün özelliklerini al
        $this->load->model('catalog/product');
        $attributes = $this->model_catalog_product->getProductAttributes($product['product_id']);
        
        $ozon_attributes = array();
        foreach ($attributes as $attribute_group) {
            foreach ($attribute_group['attribute'] as $attribute) {
                $ozon_attributes[] = array(
                    'attribute_id' => 0, // Ozon öznitelik ID'si burada mapping edilmeli
                    'value' => $attribute['text']
                );
            }
        }
        
        return array(
            'offer_id' => $product['model'],
            'name' => $product['name'],
            'description' => $this->sanitizeDescription($product['description']),
            'category_id' => $this->getOzonCategoryId($product['category_id']),
            'images' => $images,
            'price' => $product['price'],
            'old_price' => $product['price'] * 1.1, // Örnek indirimli fiyat
            'quantity' => $product['quantity'],
            'barcode' => $product['ean'] ?: $product['jan'] ?: $product['isbn'] ?: $product['upc'],
            'attributes' => $ozon_attributes
        );
    }
    
    /**
     * Sipariş import (Ozon)
     */
    protected function importOrder($ozon_order) {
        $user_id = $this->user->getId();
        
        // Sipariş kontrolü
        if ($this->orderExists($user_id, $ozon_order['posting_number'])) {
            return false;
        }
        
        // Sipariş ürünleri
        $products = array();
        foreach ($ozon_order['products'] as $product) {
            $products[] = array(
                'product_id' => $this->getProductIdByModel($product['offer_id']),
                'name' => $product['name'],
                'quantity' => $product['quantity'],
                'price' => $product['price'],
                'total' => $product['price'] * $product['quantity']
            );
        }
        
        // Müşteri bilgileri
        $customer_info = array(
            'firstname' => $ozon_order['addressee']['name'],
            'lastname' => '',
            'email' => 'customer@ozon.ru', // Ozon müşteri e-posta adresini sağlamıyor
            'telephone' => $ozon_order['addressee']['phone'],
            'address' => $ozon_order['address']['address_tail']
        );
        
        // OpenCart siparişi oluştur
        $order_data = array(
            'customer_id' => 0,
            'firstname' => $customer_info['firstname'],
            'lastname' => $customer_info['lastname'],
            'email' => $customer_info['email'],
            'telephone' => $customer_info['telephone'],
            'payment_firstname' => $customer_info['firstname'],
            'payment_lastname' => $customer_info['lastname'],
            'payment_address_1' => $customer_info['address'],
            'payment_city' => $ozon_order['address']['city'],
            'payment_country_id' => $this->getCountryIdByName('Russia'),
            'shipping_firstname' => $customer_info['firstname'],
            'shipping_lastname' => $customer_info['lastname'],
            'shipping_address_1' => $customer_info['address'],
            'shipping_city' => $ozon_order['address']['city'],
            'shipping_country_id' => $this->getCountryIdByName('Russia'),
            'comment' => 'Ozon Order: ' . $ozon_order['posting_number'],
            'total' => $ozon_order['order_total'],
            'order_status_id' => $this->getOpenCartOrderStatus($ozon_order['status']),
            'currency_id' => $this->getCurrencyId('RUB'),
            'products' => $products
        );
        
        $opencart_order_id = $this->createOrder($order_data);
        
        if ($opencart_order_id) {
            // Ozon sipariş bilgilerini kaydet
            $this->saveOzonOrder($user_id, $ozon_order, $opencart_order_id);
            return true;
        }
        
        return false;
    }
    
    /**
     * API Helper başlatma
     */
    protected function initializeApiHelper($credentials) {
        require_once(DIR_SYSTEM . 'helper/ozon_helper.php');
        $this->api_helper = new OzonHelper(
            $credentials['client_id'] ?? '',
            $credentials['api_key'] ?? ''
        );
    }
    
    /**
     * OpenCart ürün ID'sini model kodu ile bul
     */
    private function getProductIdByModel($model) {
        $this->load->model('catalog/product');
        $query = $this->db->query("SELECT product_id FROM " . DB_PREFIX . "product WHERE model = '" . $this->db->escape($model) . "'");
        
        if ($query->num_rows) {
            return $query->row['product_id'];
        }
        
        return 0;
    }
    
    /**
     * Ülke ID'sini isimle bul
     */
    private function getCountryIdByName($name) {
        $query = $this->db->query("SELECT country_id FROM " . DB_PREFIX . "country WHERE name LIKE '%" . $this->db->escape($name) . "%'");
        
        if ($query->num_rows) {
            return $query->row['country_id'];
        }
        
        return 0;
    }
    
    /**
     * Para birimi ID'sini kodu ile bul
     */
    private function getCurrencyId($code) {
        $query = $this->db->query("SELECT currency_id FROM " . DB_PREFIX . "currency WHERE code = '" . $this->db->escape($code) . "'");
        
        if ($query->num_rows) {
            return $query->row['currency_id'];
        }
        
        return $this->config->get('config_currency_id');
    }
    
    /**
     * Ozon sipariş durumunu OpenCart sipariş durumuna çevir
     */
    private function getOpenCartOrderStatus($ozon_status) {
        $status_map = array(
            'awaiting_packaging' => 1, // Beklemede
            'awaiting_deliver' => 2,   // İşleniyor
            'delivering' => 3,         // Gönderildi
            'delivered' => 5,          // Tamamlandı
            'cancelled' => 7           // İptal Edildi
        );
        
        return isset($status_map[$ozon_status]) ? $status_map[$ozon_status] : 1;
    }
    
    /**
     * Ozon sipariş verilerini kaydet
     */
    private function saveOzonOrder($user_id, $ozon_order, $opencart_order_id) {
        $this->db->query("
            INSERT INTO " . DB_PREFIX . "user_ozon_orders SET
                user_id = '" . (int)$user_id . "',
                ozon_order_id = '" . $this->db->escape($ozon_order['posting_number']) . "',
                opencart_order_id = '" . (int)$opencart_order_id . "',
                status = '" . $this->db->escape($ozon_order['status']) . "',
                total = '" . (float)$ozon_order['order_total'] . "',
                buyer_name = '" . $this->db->escape($ozon_order['addressee']['name']) . "',
                buyer_phone = '" . $this->db->escape($ozon_order['addressee']['phone']) . "',
                shipping_address = '" . $this->db->escape($ozon_order['address']['address_tail']) . "',
                order_data = '" . $this->db->escape(json_encode($ozon_order)) . "',
                date_added = NOW(),
                date_modified = NOW()
        ");
    }
    
    /**
     * Sipariş daha önce alındı mı kontrol et
     */
    private function orderExists($user_id, $ozon_order_id) {
        $query = $this->db->query("
            SELECT COUNT(*) AS total FROM " . DB_PREFIX . "user_ozon_orders 
            WHERE user_id = '" . (int)$user_id . "' AND ozon_order_id = '" . $this->db->escape($ozon_order_id) . "'
        ");
        
        return $query->row['total'] > 0;
    }
    
    /**
     * OpenCart kategorisinden Ozon kategori ID'sini bul
     */
    private function getOzonCategoryId($opencart_category_id) {
        // Bu kısım geliştirme sürecinde, gerçek bir mapping yapılmalı
        // Şimdilik varsayılan bir kategori ID'si döndürüyoruz
        return 17033275; // Örnek Ozon kategori ID'si
    }
    
    /**
     * Metin temizleme
     */
    private function sanitizeDescription($description) {
        // HTML etiketlerini temizle
        $text = strip_tags($description);
        // Boşlukları normalleştir
        $text = preg_replace('/\s+/', ' ', $text);
        return trim($text);
    }
    
    /**
     * OpenCart siparişi oluştur
     */
    private function createOrder($order_data) {
        $this->load->model('checkout/order');
        $this->load->model('sale/order');
        
        // OpenCart 3.x kontrolü
        if (method_exists($this->model_checkout_order, 'addOrder')) {
            $order_id = $this->model_checkout_order->addOrder($order_data);
        } elseif (method_exists($this->model_sale_order, 'addOrder')) {
            $order_id = $this->model_sale_order->addOrder($order_data);
        } else {
            return false;
        }
        
        return $order_id;
    }
} 