<?php
/**
 * trendyol_helper.php
 *
 * Amaç: Trendyol API işlemleri ve yardımcı fonksiyonlar.
 *
 * Loglama: Tüm önemli işlemler ve hatalar trendyol_helper.log dosyasına kaydedilir.
 * Log formatı: [YYYY-MM-DD HH:MM:SS] [KULLANICI/ROL] [İŞLEM] [AÇIKLAMA]
 *
 * Geliştirici: Her fonksiyon başında açıklama ve log şablonu bulunmalıdır.
 */
// Trendyol'a ürün gönderme, sipariş çekme gibi fonksiyonlar buraya yazılır

/**
 * Trendyol API'ye bağlantı kurar
 * @return bool Başarı durumu
 */
function trendyol_baglan($api_key, $api_secret) {
    // Bağlantı kodu örneği
    $result = false;
    try {
        // API bağlantı testi
        $url = 'https://api.trendyol.com/sapigw/suppliers/brands';
        $headers = [
            'Authorization: Basic ' . base64_encode($api_key . ':' . $api_secret),
            'Content-Type: application/json'
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            $result = true;
            trendyol_logla('SISTEM', 'BAGLAN', 'Trendyol API bağlantısı başarılı.');
        } else {
            trendyol_logla('SISTEM', 'HATA', 'Bağlantı hatası: HTTP ' . $httpcode);
        }
    } catch (Exception $e) {
        trendyol_logla('SISTEM', 'HATA', 'Bağlantı hatası: ' . $e->getMessage());
    }
    return $result;
}

/**
 * Trendyol'a ürün gönderir
 * @param array $urun Ürün verisi
 * @return bool
 */
function trendyol_urun_gonder($urun, $api_key, $api_secret, $supplier_id) {
    try {
        $url = 'https://api.trendyol.com/sapigw/suppliers/' . $supplier_id . '/products';
        $headers = [
            'Authorization: Basic ' . base64_encode($api_key . ':' . $api_secret),
            'Content-Type: application/json'
        ];
        
        // Ürün verisini hazırla
        $product_data = [
            'items' => [$urun]
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($product_data));
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            trendyol_logla('SISTEM', 'URUN_GONDER', 'Ürün başarıyla gönderildi: ' . json_encode($urun));
            return true;
        } else {
            trendyol_logla('SISTEM', 'HATA', 'Ürün gönderme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return false;
        }
    } catch (Exception $e) {
        trendyol_logla('SISTEM', 'HATA', 'Ürün gönderme hatası: ' . $e->getMessage());
        return false;
    }
}

/**
 * Trendyol'dan sipariş çeker
 * @param string $tarih_araligi
 * @return array
 */
function trendyol_siparis_cek($tarih_araligi, $api_key, $api_secret, $supplier_id) {
    try {
        // Tarih aralığını parçala (format: YYYY-MM-DD,YYYY-MM-DD)
        $dates = explode(',', $tarih_araligi);
        $startDate = isset($dates[0]) ? $dates[0] . 'T00:00:00.000Z' : date('Y-m-d', strtotime('-7 days')) . 'T00:00:00.000Z';
        $endDate = isset($dates[1]) ? $dates[1] . 'T23:59:59.999Z' : date('Y-m-d') . 'T23:59:59.999Z';
        
        $url = 'https://api.trendyol.com/sapigw/suppliers/' . $supplier_id . '/orders';
        $url .= '?startDate=' . urlencode($startDate) . '&endDate=' . urlencode($endDate);
        
        $headers = [
            'Authorization: Basic ' . base64_encode($api_key . ':' . $api_secret),
            'Content-Type: application/json'
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            $siparisler = json_decode($response, true);
            trendyol_logla('SISTEM', 'SIPARIS_CEK', 'Siparişler başarıyla çekildi: ' . $tarih_araligi);
            return $siparisler;
        } else {
            trendyol_logla('SISTEM', 'HATA', 'Sipariş çekme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return array();
        }
    } catch (Exception $e) {
        trendyol_logla('SISTEM', 'HATA', 'Sipariş çekme hatası: ' . $e->getMessage());
        return array();
    }
}

/**
 * Loglama fonksiyonu
 */
function trendyol_logla($user, $action, $message) {
    $log_file = DIR_LOGS . 'trendyol_helper.log';
    $date = date('Y-m-d H:i:s');
    $log = "[$date] [$user] [$action] $message\n";
    file_put_contents($log_file, $log, FILE_APPEND);
}

/**
 * Stok güncelleme fonksiyonu
 * @param array $stok_bilgisi Stok bilgisi (barcode, quantity)
 * @return bool
 */
function trendyol_stok_guncelle($stok_bilgisi, $api_key, $api_secret, $supplier_id) {
    try {
        $url = 'https://api.trendyol.com/sapigw/suppliers/' . $supplier_id . '/products/price-and-inventory';
        $headers = [
            'Authorization: Basic ' . base64_encode($api_key . ':' . $api_secret),
            'Content-Type: application/json'
        ];
        
        // Stok verisini hazırla
        $inventory_data = [
            'items' => [$stok_bilgisi]
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($inventory_data));
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            trendyol_logla('SISTEM', 'STOK_GUNCELLE', 'Stok başarıyla güncellendi: ' . json_encode($stok_bilgisi));
            return true;
        } else {
            trendyol_logla('SISTEM', 'HATA', 'Stok güncelleme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return false;
        }
    } catch (Exception $e) {
        trendyol_logla('SISTEM', 'HATA', 'Stok güncelleme hatası: ' . $e->getMessage());
        return false;
    }
}

/**
 * Fiyat güncelleme fonksiyonu
 * @param array $fiyat_bilgisi Fiyat bilgisi (barcode, price, discountedPrice)
 * @return bool
 */
function trendyol_fiyat_guncelle($fiyat_bilgisi, $api_key, $api_secret, $supplier_id) {
    try {
        $url = 'https://api.trendyol.com/sapigw/suppliers/' . $supplier_id . '/products/price-and-inventory';
        $headers = [
            'Authorization: Basic ' . base64_encode($api_key . ':' . $api_secret),
            'Content-Type: application/json'
        ];
        
        // Fiyat verisini hazırla
        $price_data = [
            'items' => [$fiyat_bilgisi]
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($price_data));
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            trendyol_logla('SISTEM', 'FIYAT_GUNCELLE', 'Fiyat başarıyla güncellendi: ' . json_encode($fiyat_bilgisi));
            return true;
        } else {
            trendyol_logla('SISTEM', 'HATA', 'Fiyat güncelleme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return false;
        }
    } catch (Exception $e) {
        trendyol_logla('SISTEM', 'HATA', 'Fiyat güncelleme hatası: ' . $e->getMessage());
        return false;
    }
}

/**
 * Sipariş durumu güncelleme fonksiyonu
 * @param string $siparis_no Sipariş numarası
 * @param string $durum Yeni durum
 * @return bool
 */
function trendyol_siparis_durum_guncelle($siparis_no, $durum, $api_key, $api_secret, $supplier_id) {
    try {
        $url = 'https://api.trendyol.com/sapigw/suppliers/' . $supplier_id . '/orders';
        $headers = [
            'Authorization: Basic ' . base64_encode($api_key . ':' . $api_secret),
            'Content-Type: application/json'
        ];
        
        // Sipariş durumu verisini hazırla
        $status_data = [
            'orderNumber' => $siparis_no,
            'status' => $durum
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($status_data));
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpcode == 200) {
            trendyol_logla('SISTEM', 'SIPARIS_DURUM', 'Sipariş durumu başarıyla güncellendi: ' . $siparis_no . ' -> ' . $durum);
            return true;
        } else {
            trendyol_logla('SISTEM', 'HATA', 'Sipariş durumu güncelleme hatası: HTTP ' . $httpcode . ' - ' . $response);
            return false;
        }
    } catch (Exception $e) {
        trendyol_logla('SISTEM', 'HATA', 'Sipariş durumu güncelleme hatası: ' . $e->getMessage());
        return false;
    }
}

// ... Yardımcı fonksiyonlar buraya eklenecek ... 

class TrendyolHelper {
    /**
     * Trendyol API'den siparişleri çeker (gerçek API, parametre destekli)
     * @param array $settings (api_key, api_secret, supplier_id, endpoint)
     * @param array $params (opsiyonel, ör: status, size)
     * @return array|false
     */
    public static function getOrders($settings, $params = []) {
        $url = rtrim($settings['endpoint'], '/') . '/suppliers/' . $settings['supplier_id'] . '/orders';
        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }
        $headers = [
            'Authorization: Basic ' . base64_encode($settings['api_key'] . ':' . $settings['api_secret']),
            'Content-Type: application/json'
        ];
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch)) {
            self::writeLog('system', 'API_ERROR', 'Sipariş çekme cURL hatası: ' . curl_error($ch) . ' | Parametreler: ' . json_encode($params));
            curl_close($ch);
            return false;
        }
        curl_close($ch);
        if ($httpcode !== 200) {
            self::writeLog('system', 'API_ERROR', 'Sipariş çekme HTTP hata kodu: ' . $httpcode . ' - Yanıt: ' . $response . ' | Parametreler: ' . json_encode($params));
            return false;
        }
        self::writeLog('system', 'API_CALL', 'Siparişler başarıyla çekildi. Parametreler: ' . json_encode($params));
        return json_decode($response, true);
    }
    /**
     * Trendyol API'den ürünleri çeker (gerçek API)
     * @param array $settings (api_key, api_secret, supplier_id, endpoint)
     * @return array|false
     */
    public static function getProducts($settings) {
        $url = rtrim($settings['endpoint'], '/') . '/suppliers/' . $settings['supplier_id'] . '/products';
        $headers = [
            'Authorization: Basic ' . base64_encode($settings['api_key'] . ':' . $settings['api_secret']),
            'Content-Type: application/json'
        ];
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch)) {
            self::writeLog('system', 'API_ERROR', 'Ürün çekme cURL hatası: ' . curl_error($ch));
            curl_close($ch);
            return false;
        }
        curl_close($ch);
        if ($httpcode !== 200) {
            self::writeLog('system', 'API_ERROR', 'Ürün çekme HTTP hata kodu: ' . $httpcode . ' - Yanıt: ' . $response);
            return false;
        }
        self::writeLog('system', 'API_CALL', 'Ürünler başarıyla çekildi.');
        return json_decode($response, true);
    }
    /**
     * Atomik log fonksiyonu
     * @param string $user
     * @param string $action
     * @param string $message
     */
    public static function writeLog($user, $action, $message) {
        $log_file = DIR_LOGS . 'trendyol_helper.log';
        $date = date('Y-m-d H:i:s');
        $log = "[$date] [$user] [$action] $message\n";
        file_put_contents($log_file, $log, FILE_APPEND);
    }
    
    /**
     * Ürünü OpenCart formatından Trendyol formatına dönüştürür
     * @param array $opencart_product OpenCart ürün verisi
     * @return array Trendyol formatında ürün
     */
    public static function formatProductForTrendyol($opencart_product) {
        // Trendyol gerekli alanları
        $trendyol_product = [
            'barcode' => $opencart_product['sku'],
            'title' => $opencart_product['name'],
            'productMainId' => 'OC' . $opencart_product['product_id'],
            'brandId' => $opencart_product['manufacturer_id'],
            'categoryId' => $opencart_product['trendyol_category_id'] ?? 0,
            'quantity' => $opencart_product['quantity'],
            'stockCode' => $opencart_product['model'],
            'dimensionalWeight' => $opencart_product['weight'],
            'description' => $opencart_product['description'],
            'pricingType' => 'BUY_BOX',
            'price' => $opencart_product['price'],
            'cargoCompanyId' => 1, // Varsayılan kargo şirketi ID'si
        ];
        
        // Ürün resimleri
        $images = [];
        if (!empty($opencart_product['image'])) {
            $images[] = HTTPS_CATALOG . 'image/' . $opencart_product['image'];
        }
        
        // Ek resimler varsa ekle
        if (isset($opencart_product['product_image']) && is_array($opencart_product['product_image'])) {
            foreach ($opencart_product['product_image'] as $image) {
                $images[] = HTTPS_CATALOG . 'image/' . $image['image'];
            }
        }
        
        $trendyol_product['images'] = $images;
        
        // Özellikler/Nitelikler
        $attributes = [];
        if (isset($opencart_product['product_attribute']) && is_array($opencart_product['product_attribute'])) {
            foreach ($opencart_product['product_attribute'] as $attribute) {
                $attributes[] = [
                    'attributeId' => $attribute['trendyol_attribute_id'] ?? 0,
                    'attributeValueId' => $attribute['trendyol_attribute_value_id'] ?? 0
                ];
            }
        }
        
        $trendyol_product['attributes'] = $attributes;
        
        return $trendyol_product;
    }
    
    /**
     * Trendyol API'den markaları çeker
     * @param array $settings API ayarları
     * @return array|false
     */
    public static function getBrands($settings) {
        $url = 'https://api.trendyol.com/sapigw/brands';
        $headers = [
            'Authorization: Basic ' . base64_encode($settings['api_key'] . ':' . $settings['api_secret']),
            'Content-Type: application/json'
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            self::writeLog('system', 'API_ERROR', 'Marka çekme cURL hatası: ' . curl_error($ch));
            curl_close($ch);
            return false;
        }
        
        curl_close($ch);
        
        if ($httpcode !== 200) {
            self::writeLog('system', 'API_ERROR', 'Marka çekme HTTP hata kodu: ' . $httpcode . ' - Yanıt: ' . $response);
            return false;
        }
        
        self::writeLog('system', 'API_CALL', 'Markalar başarıyla çekildi.');
        return json_decode($response, true);
    }
    
    /**
     * Trendyol API'den kategorileri çeker
     * @param array $settings API ayarları
     * @return array|false
     */
    public static function getCategories($settings) {
        $url = 'https://api.trendyol.com/sapigw/product-categories';
        $headers = [
            'Authorization: Basic ' . base64_encode($settings['api_key'] . ':' . $settings['api_secret']),
            'Content-Type: application/json'
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            self::writeLog('system', 'API_ERROR', 'Kategori çekme cURL hatası: ' . curl_error($ch));
            curl_close($ch);
            return false;
        }
        
        curl_close($ch);
        
        if ($httpcode !== 200) {
            self::writeLog('system', 'API_ERROR', 'Kategori çekme HTTP hata kodu: ' . $httpcode . ' - Yanıt: ' . $response);
            return false;
        }
        
        self::writeLog('system', 'API_CALL', 'Kategoriler başarıyla çekildi.');
        return json_decode($response, true);
    }
    
    /**
     * Trendyol API'den kategori özelliklerini çeker
     * @param array $settings API ayarları
     * @param int $category_id Kategori ID
     * @return array|false
     */
    public static function getCategoryAttributes($settings, $category_id) {
        $url = 'https://api.trendyol.com/sapigw/product-categories/' . $category_id . '/attributes';
        $headers = [
            'Authorization: Basic ' . base64_encode($settings['api_key'] . ':' . $settings['api_secret']),
            'Content-Type: application/json'
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            self::writeLog('system', 'API_ERROR', 'Kategori özellikleri çekme cURL hatası: ' . curl_error($ch));
            curl_close($ch);
            return false;
        }
        
        curl_close($ch);
        
        if ($httpcode !== 200) {
            self::writeLog('system', 'API_ERROR', 'Kategori özellikleri çekme HTTP hata kodu: ' . $httpcode . ' - Yanıt: ' . $response);
            return false;
        }
        
        self::writeLog('system', 'API_CALL', 'Kategori özellikleri başarıyla çekildi.');
        return json_decode($response, true);
    }
} 