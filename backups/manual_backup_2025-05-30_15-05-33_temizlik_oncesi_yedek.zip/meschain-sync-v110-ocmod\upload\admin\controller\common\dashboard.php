		// Dashboard Extensions
		$dashboards = array();

		$this->load->model('setting/extension');

		// Get a list of installed modules
		$extensions = $this->model_setting_extension->getInstalled('dashboard');
		
		// Add n11 dashboard widget if module is installed
		if ($this->config->get('module_n11_status')) {
			$dashboards[] = array(
				'code'       => 'n11',
				'width'      => 6,
				'sort_order' => 6
			);
		}
		
		// Add files for each dashboard
		foreach ($extensions as $code) {
			if ($this->config->get('dashboard_' . $code . '_status') && $this->user->hasPermission('access', 'extension/dashboard/' . $code)) {
				$dashboards[] = array(
					'code'       => $code,
					'width'      => $this->config->get('dashboard_' . $code . '_width'),
					'sort_order' => $this->config->get('dashboard_' . $code . '_sort_order')
				);
			}
		} 