<?php
/**
 * index.php
 *
 * Amaç: OpenCart modülünde API yönlendirme giriş noktasıdır. Dış sistemlerle entegrasyon işlemleri buradan başlatılır.
 *
 * Loglama: Tüm API çağrıları ve hatalar api_log_example.log dosyasına kaydedilmelidir.
 * Log formatı: [YYYY-MM-DD HH:MM:SS] [KULLANICI/ROL] [İŞLEM] [AÇIKLAMA]
 */
// API yönlendirme giriş noktası

// ... API yönlendirme kodları buraya eklenecek ... 